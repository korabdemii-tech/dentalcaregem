import { defineConfig, devices } from "@playwright/test";

/**
 * End-to-end tests against a production build and a dedicated database.
 *
 *   E2E_DATABASE_URL=postgres://…/gemdental_e2e npm run build && npm run test:e2e
 *
 * The database is reset and seeded with demo data before the run.
 */
const PORT = Number(process.env.E2E_PORT ?? 3100);
const DB = process.env.E2E_DATABASE_URL ?? "postgres://gemdental:gemdental_dev@localhost:5432/gemdental_e2e";
const executablePath = process.env.PW_CHROMIUM_PATH || undefined;

export default defineConfig({
  testDir: "tests/e2e",
  globalSetup: "./tests/e2e/global-setup.ts",
  fullyParallel: false,
  workers: 1,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  reporter: [["list"]],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: "retain-on-failure",
    launchOptions: { executablePath },
  },
  projects: [
    { name: "desktop", use: { ...devices["Desktop Chrome"], launchOptions: { executablePath } }, grepInvert: /@mobile/ },
    { name: "mobile", use: { ...devices["Pixel 7"], launchOptions: { executablePath } }, grep: /@mobile/ },
  ],
  webServer: {
    command: `npx next start -p ${PORT}`,
    url: `http://localhost:${PORT}/en`,
    reuseExistingServer: true,
    timeout: 120_000,
    env: {
      DATABASE_URL: DB,
      SITE_URL: `http://localhost:${PORT}`,
      APP_SECRET: process.env.APP_SECRET ?? "e2e-secret-e2e-secret-e2e-secret-e2e-secret",
      CRON_SECRET: "e2e-cron",
      EMAIL_PROVIDER: "log",
      SMS_PROVIDER: "log",
      WHATSAPP_PROVIDER: "none",
      LOCALES: "sq,en",
    },
  },
});
