/**
 * Long-running notification worker for self-hosted deployments (VPS, Docker).
 * On serverless platforms use the /api/cron/notifications endpoint instead.
 *
 *   npm run worker
 */
import { processNotificationQueue, scheduleDueReminders } from "@/lib/notifications/queue";

const INTERVAL_MS = Number(process.env.WORKER_INTERVAL_MS ?? 30_000);
let stopping = false;
let wake: (() => void) | null = null;

async function tick() {
  try {
    await scheduleDueReminders();
    const r = await processNotificationQueue({ limit: 50 });
    if (r.processed) console.log(`[worker] processed=${r.processed} sent=${r.sent} failed=${r.failed}`);
  } catch (e) {
    console.error("[worker] error:", e instanceof Error ? e.message : e);
  }
}

async function main() {
  console.log(`[worker] started, every ${INTERVAL_MS / 1000}s`);
  while (!stopping) {
    await tick();
    await new Promise<void>((r) => {
      const t = setTimeout(r, INTERVAL_MS);
      wake = () => {
        clearTimeout(t);
        r();
      };
    });
  }
  console.log("[worker] stopped");
  process.exit(0);
}

for (const sig of ["SIGINT", "SIGTERM"])
  process.on(sig, () => {
    stopping = true; // finish the current batch, then exit
    wake?.();
  });
main();
