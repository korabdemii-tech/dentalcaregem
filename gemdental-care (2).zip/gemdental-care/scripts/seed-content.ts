/**
 * Starter content. IMPORTANT: every treatment below is an EXAMPLE category
 * from the project brief, not a confirmed GemDental service. The normal seed
 * stores them unconfirmed and unpublished. The demo seed publishes them so the
 * booking flow can be tested, and the site shows a "preview" ribbon.
 *
 * Descriptions are general patient information about each treatment and make
 * no claims about GemDental's equipment, techniques, results or prices.
 * Albanian copy should be reviewed by a native speaker before launch.
 */
import type { Localized } from "@/lib/i18n/config";

type ServiceSeed = {
  slug: string;
  name: Localized;
  summary: Localized;
  description: Localized;
  durationMinutes: number;
  bufferMinutes: number;
  isConsultation?: boolean;
  demoPublish: boolean;
};

export const SERVICE_SEEDS: ServiceSeed[] = [
  {
    slug: "consultation",
    isConsultation: true,
    demoPublish: true,
    durationMinutes: 30,
    bufferMinutes: 0,
    name: { en: "Consultation", sq: "Konsultë" },
    summary: {
      en: "Not sure what you need? Start with a conversation and an examination.",
      sq: "Nuk jeni të sigurt çfarë ju duhet? Filloni me një bisedë dhe një ekzaminim.",
    },
    description: {
      en: "A consultation is the right first step when you have a concern, a question or a goal for your smile but are not sure which treatment fits.\n\nThe dentist listens to what you would like to achieve, examines your teeth and gums, and explains the options in plain language, so you can decide on the next step with confidence.",
      sq: "Konsulta është hapi i parë i duhur kur keni një shqetësim, një pyetje ose një dëshirë për buzëqeshjen tuaj, por nuk jeni të sigurt cili trajtim ju përshtatet.\n\nDentisti dëgjon çfarë dëshironi të arrini, kontrollon dhëmbët dhe mishrat dhe ju shpjegon mundësitë me fjalë të thjeshta, që të vendosni për hapin e ardhshëm me siguri.",
    },
  },
  {
    slug: "dental-checkup",
    demoPublish: true,
    durationMinutes: 30,
    bufferMinutes: 0,
    name: { en: "Dental check-up", sq: "Kontroll dentar" },
    summary: {
      en: "A routine examination of your teeth, gums and bite.",
      sq: "Kontroll i rregullt i dhëmbëve, mishrave dhe kafshimit.",
    },
    description: {
      en: "Regular check-ups help find small problems before they become bigger ones. The dentist examines your teeth, gums and existing fillings or restorations, and talks you through anything that needs attention.\n\nIt is also a good moment to ask questions about your daily care at home.",
      sq: "Kontrollet e rregullta ndihmojnë të zbulohen problemet e vogla para se të bëhen më të mëdha. Dentisti kontrollon dhëmbët, mishrat dhe mbushjet ose restaurimet ekzistuese dhe ju shpjegon çdo gjë që kërkon vëmendje.\n\nËshtë gjithashtu një moment i mirë për të bërë pyetje rreth kujdesit tuaj të përditshëm në shtëpi.",
    },
  },
  {
    slug: "dental-cleaning",
    demoPublish: true,
    durationMinutes: 45,
    bufferMinutes: 15,
    name: { en: "Professional cleaning", sq: "Pastrim profesional" },
    summary: {
      en: "Removal of plaque and tartar that daily brushing can't reach.",
      sq: "Heqja e pllakës dhe gurëzave që furçimi i përditshëm nuk i arrin.",
    },
    description: {
      en: "Even with careful brushing, plaque and tartar build up in places that are hard to reach. A professional cleaning removes these deposits and polishes the teeth, which supports healthy gums and a fresher feeling.\n\nYou'll also get practical advice for keeping your teeth clean between visits.",
      sq: "Edhe me furçim të kujdesshëm, pllaka dhe gurëzat grumbullohen në vende që arrihen me vështirësi. Pastrimi profesional i largon këto depozita dhe i lëmon dhëmbët, gjë që ndihmon mishrat e shëndetshëm dhe një ndjesi më të freskët.\n\nDo të merrni edhe këshilla praktike për t'i mbajtur dhëmbët të pastër mes vizitave.",
    },
  },
  {
    slug: "teeth-whitening",
    demoPublish: true,
    durationMinutes: 60,
    bufferMinutes: 15,
    name: { en: "Teeth whitening", sq: "Zbardhimi i dhëmbëve" },
    summary: {
      en: "Lightening the natural shade of your teeth under professional supervision.",
      sq: "Zbardhimi i ngjyrës natyrale të dhëmbëve nën mbikëqyrje profesionale.",
    },
    description: {
      en: "Whitening lightens the natural colour of teeth that have darkened over time. Before treatment, the dentist checks that your teeth and gums are healthy and explains what result is realistic for you.\n\nWhitening does not change the colour of crowns, veneers or fillings, which is worth discussing beforehand.",
      sq: "Zbardhimi e çel ngjyrën natyrale të dhëmbëve që janë errësuar me kalimin e kohës. Para trajtimit, dentisti kontrollon që dhëmbët dhe mishrat të jenë të shëndetshëm dhe ju shpjegon cili rezultat është realist për ju.\n\nZbardhimi nuk e ndryshon ngjyrën e kurorave, faseteve apo mbushjeve, prandaj është mirë të diskutohet paraprakisht.",
    },
  },
  {
    slug: "dental-implants",
    demoPublish: true,
    durationMinutes: 60,
    bufferMinutes: 15,
    name: { en: "Dental implants", sq: "Implantet dentare" },
    summary: {
      en: "A long-term option for replacing one or more missing teeth.",
      sq: "Një zgjidhje afatgjatë për zëvendësimin e një ose më shumë dhëmbëve që mungojnë.",
    },
    description: {
      en: "A dental implant replaces the root of a missing tooth and supports a crown, bridge or denture on top. Treatment happens in stages over several months.\n\nThe first appointment is an assessment: the dentist examines the area, discusses whether an implant is suitable for you, and outlines the steps, timeline and costs involved.",
      sq: "Implanti dentar zëvendëson rrënjën e një dhëmbi që mungon dhe mban sipër një kurorë, urë ose protezë. Trajtimi bëhet në disa faza gjatë disa muajve.\n\nTakimi i parë është një vlerësim: dentisti kontrollon zonën, diskuton nëse implanti është i përshtatshëm për ju dhe ju shpjegon hapat, kohëzgjatjen dhe kostot.",
    },
  },
  {
    slug: "crowns-and-bridges",
    demoPublish: true,
    durationMinutes: 60,
    bufferMinutes: 15,
    name: { en: "Crowns and bridges", sq: "Kurora dhe ura" },
    summary: {
      en: "Restoring damaged teeth and filling gaps with fixed restorations.",
      sq: "Restaurimi i dhëmbëve të dëmtuar dhe mbushja e hapësirave me restaurime fikse.",
    },
    description: {
      en: "A crown covers and protects a tooth that is weakened, heavily filled or broken. A bridge replaces a missing tooth by anchoring to the teeth on either side.\n\nBoth are made to match the shape and shade of your natural teeth and usually take more than one visit.",
      sq: "Kurora mbulon dhe mbron një dhëmb të dobësuar, me mbushje të mëdha ose të thyer. Ura zëvendëson një dhëmb që mungon duke u mbështetur te dhëmbët në të dy anët.\n\nTë dyja punohen që të përputhen me formën dhe ngjyrën e dhëmbëve tuaj natyralë dhe zakonisht kërkojnë më shumë se një vizitë.",
    },
  },
  {
    slug: "veneers",
    demoPublish: true,
    durationMinutes: 60,
    bufferMinutes: 15,
    name: { en: "Veneers", sq: "Fasetat" },
    summary: {
      en: "Thin shells that change the shape, shade or alignment of front teeth.",
      sq: "Shtresa të holla që ndryshojnë formën, ngjyrën ose rreshtimin e dhëmbëve të përparmë.",
    },
    description: {
      en: "Veneers are thin restorations bonded to the front surface of teeth. They can improve the appearance of teeth that are chipped, discoloured, uneven or slightly spaced.\n\nIt starts with a consultation to discuss what you would like to change and whether veneers are the right approach.",
      sq: "Fasetat janë restaurime të holla që ngjiten në sipërfaqen e përparme të dhëmbëve. Ato mund të përmirësojnë pamjen e dhëmbëve të krisur, të njollosur, të parregullt ose me hapësira të vogla.\n\nFillon me një konsultë për të diskutuar çfarë dëshironi të ndryshoni dhe nëse fasetat janë zgjidhja e duhur.",
    },
  },
  {
    slug: "orthodontics",
    demoPublish: true,
    durationMinutes: 45,
    bufferMinutes: 15,
    name: { en: "Orthodontics", sq: "Ortodonci" },
    summary: {
      en: "Straightening teeth and improving the bite.",
      sq: "Drejtimi i dhëmbëve dhe përmirësimi i kafshimit.",
    },
    description: {
      en: "Orthodontic treatment gradually moves teeth into a better position, which can make them easier to clean and improve how they meet when you bite.\n\nAn initial assessment looks at your teeth and bite and explains the available options and how long treatment is likely to take.",
      sq: "Trajtimi ortodontik i zhvendos gradualisht dhëmbët në një pozicion më të mirë, gjë që i bën më të lehtë për t'u pastruar dhe përmirëson mënyrën si takohen kur kafshoni.\n\nVlerësimi fillestar shqyrton dhëmbët dhe kafshimin tuaj dhe ju shpjegon mundësitë dhe sa kohë mund të zgjasë trajtimi.",
    },
  },
  {
    slug: "root-canal-treatment",
    demoPublish: true,
    durationMinutes: 90,
    bufferMinutes: 15,
    name: { en: "Root canal treatment", sq: "Trajtimi i kanalit të rrënjës" },
    summary: {
      en: "Treating infection or inflammation inside a tooth to save it.",
      sq: "Trajtimi i infeksionit ose inflamacionit brenda dhëmbit për ta ruajtur atë.",
    },
    description: {
      en: "When the soft tissue inside a tooth becomes inflamed or infected, root canal treatment cleans and seals the inside of the tooth so it can be kept rather than removed.\n\nThe tooth is numbed during treatment. Afterwards, a filling or crown protects it.",
      sq: "Kur indi i butë brenda dhëmbit inflamohet ose infektohet, trajtimi i kanalit pastron dhe mbyll pjesën e brendshme të dhëmbit, që ai të ruhet në vend që të hiqet.\n\nGjatë trajtimit dhëmbi anestezohet. Më pas, një mbushje ose kurorë e mbron atë.",
    },
  },
  {
    slug: "emergency-consultation",
    demoPublish: true,
    durationMinutes: 30,
    bufferMinutes: 0,
    name: { en: "Emergency consultation", sq: "Konsultë urgjente" },
    summary: {
      en: "For sudden pain, swelling, or a broken or knocked-out tooth.",
      sq: "Për dhimbje të papritur, ënjtje, ose dhëmb të thyer apo të rrëzuar.",
    },
    description: {
      en: "If you have sudden tooth pain, swelling, bleeding, or a broken or knocked-out tooth, book the earliest available time or call the clinic directly.\n\nIf you have difficulty breathing or swallowing, or swelling that is spreading quickly, contact emergency medical services.",
      sq: "Nëse keni dhimbje të papritur të dhëmbit, ënjtje, gjakderdhje, ose një dhëmb të thyer apo të rrëzuar, rezervoni orarin e parë të lirë ose telefononi drejtpërdrejt klinikën.\n\nNëse keni vështirësi në frymëmarrje ose gëlltitje, ose ënjtje që përhapet shpejt, kontaktoni shërbimin e urgjencës mjekësore.",
    },
  },
  {
    slug: "general-dentistry",
    demoPublish: false,
    durationMinutes: 30,
    bufferMinutes: 0,
    name: { en: "General dentistry", sq: "Stomatologji e përgjithshme" },
    summary: {
      en: "Everyday care such as fillings and treatment of tooth decay.",
      sq: "Kujdes i përditshëm si mbushjet dhe trajtimi i kariesit.",
    },
    description: { en: "", sq: "" },
  },
  {
    slug: "cosmetic-dentistry",
    demoPublish: false,
    durationMinutes: 45,
    bufferMinutes: 0,
    name: { en: "Cosmetic dentistry", sq: "Stomatologji estetike" },
    summary: {
      en: "Treatments focused on the appearance of your smile.",
      sq: "Trajtime që fokusohen në pamjen e buzëqeshjes suaj.",
    },
    description: { en: "", sq: "" },
  },
];

type FaqSeed = { topic: string; question: Localized; answer: Localized; verifiedBySystem: boolean };

/**
 * verifiedBySystem = the answer only describes how this website works, so it
 * is true by construction. Clinic-policy answers start unverified and hidden.
 */
export const FAQ_SEEDS: FaqSeed[] = [
  {
    topic: "booking",
    verifiedBySystem: true,
    question: { en: "How do I book an appointment?", sq: "Si mund të rezervoj një termin?" },
    answer: {
      en: "Choose a treatment, pick a day and a time that shows as available, and enter your contact details. The whole process takes a couple of minutes, and you'll receive a reference number at the end.",
      sq: "Zgjidhni trajtimin, një ditë dhe një orë që shfaqet e lirë dhe shkruani të dhënat tuaja të kontaktit. I gjithë procesi zgjat disa minuta dhe në fund merrni një numër reference.",
    },
  },
  {
    topic: "consultations",
    verifiedBySystem: true,
    question: {
      en: "I'm not sure which treatment I need. What should I book?",
      sq: "Nuk jam i sigurt cilin trajtim më duhet. Çfarë duhet të rezervoj?",
    },
    answer: {
      en: "Book a consultation. It's the right choice whenever you're unsure: the dentist will examine your teeth and explain the options before anything else happens.",
      sq: "Rezervoni një konsultë. Është zgjedhja e duhur sa herë që nuk jeni të sigurt: dentisti do t'ju kontrollojë dhe do t'ju shpjegojë mundësitë para çdo hapi tjetër.",
    },
  },
  {
    topic: "confirmation",
    verifiedBySystem: true,
    question: { en: "How will I know my appointment is confirmed?", sq: "Si do ta di që termini im është konfirmuar?" },
    answer: {
      en: "The last step of the booking tells you clearly whether your appointment is confirmed or whether it's a request waiting for the clinic's approval. If it's a request, you'll receive a separate message once it has been confirmed.",
      sq: "Hapi i fundit i rezervimit ju tregon qartë nëse termini juaj është konfirmuar apo nëse është një kërkesë që pret miratimin e klinikës. Nëse është kërkesë, do të merrni një mesazh të veçantë sapo të konfirmohet.",
    },
  },
  {
    topic: "rescheduling",
    verifiedBySystem: false,
    question: { en: "Can I reschedule or cancel my appointment?", sq: "A mund ta ndryshoj ose ta anuloj terminin?" },
    answer: {
      en: "[Clinic to confirm: how patients reschedule or cancel, and any notice period.]",
      sq: "[Klinika duhet të konfirmojë: si e ndryshojnë ose anulojnë pacientët terminin dhe afatin e njoftimit.]",
    },
  },
  {
    topic: "payments",
    verifiedBySystem: false,
    question: { en: "How can I pay?", sq: "Si mund të paguaj?" },
    answer: {
      en: "[Clinic to confirm: accepted payment methods and whether prices are discussed at the consultation.]",
      sq: "[Klinika duhet të konfirmojë: mënyrat e pranuara të pagesës dhe nëse çmimet diskutohen në konsultë.]",
    },
  },
  {
    topic: "location",
    verifiedBySystem: false,
    question: { en: "Where is the clinic and is there parking?", sq: "Ku ndodhet klinika dhe a ka parking?" },
    answer: {
      en: "[Clinic to confirm: address, directions and parking.]",
      sq: "[Klinika duhet të konfirmojë: adresën, udhëzimet dhe parkimin.]",
    },
  },
  {
    topic: "emergency",
    verifiedBySystem: false,
    question: { en: "What should I do in a dental emergency?", sq: "Çfarë duhet të bëj në një urgjencë dentare?" },
    answer: {
      en: "[Clinic to confirm: emergency phone line and same-day availability.]",
      sq: "[Klinika duhet të konfirmojë: linjën telefonike për urgjenca dhe disponueshmërinë brenda ditës.]",
    },
  },
];
