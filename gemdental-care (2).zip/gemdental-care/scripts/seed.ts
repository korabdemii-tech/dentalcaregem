/**
 * Seed the database.
 *
 *   npm run db:seed        Production-safe: clinic settings, the doctor profile
 *                          shell, example treatments and FAQ drafts (all
 *                          unpublished). No accounts, no schedule.
 *   npm run db:seed:demo   Everything above, plus: example treatments published,
 *                          a DEMO working schedule, a demo owner account and a few
 *                          demo appointments, so the booking flow can be tried.
 *                          The public site shows a "preview" ribbon.
 *
 * Safe to re-run: existing rows are left alone.
 */
import { randomBytes } from "node:crypto";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { hashPassword } from "@/lib/auth/password";
import { SERVICE_SEEDS, FAQ_SEEDS } from "./seed-content";
import { addDays, zonedDateKey, zonedToUtc } from "@/lib/time";
import { newReference } from "@/lib/booking/reference";

const demo = process.argv.includes("--demo");

async function main() {
  const d = db();

  await d.insert(schema.clinicSettings).values({ id: 1, previewNotice: true }).onConflictDoNothing();

  // Doctor profile shell. Credentials are intentionally empty until the clinic supplies them.
  await d
    .insert(schema.doctors)
    .values({ slug: "genc-bejtullahu", fullName: "Dr. Genc Bejtullahu", published: true, active: true })
    .onConflictDoNothing();
  const [doctor] = await d.select().from(schema.doctors).where(eq(schema.doctors.slug, "genc-bejtullahu"));

  let order = 0;
  for (const s of SERVICE_SEEDS) {
    await d
      .insert(schema.services)
      .values({
        slug: s.slug,
        name: s.name,
        summary: s.summary,
        description: s.description,
        durationMinutes: s.durationMinutes,
        bufferMinutes: s.bufferMinutes,
        isConsultation: Boolean(s.isConsultation),
        confirmed: demo && s.demoPublish,
        published: demo && s.demoPublish,
        bookable: true,
        sortOrder: order++,
      })
      .onConflictDoNothing();
  }

  order = 0;
  const existingFaqs = await d.select({ id: schema.faqs.id }).from(schema.faqs).limit(1);
  if (!existingFaqs.length) {
    for (const f of FAQ_SEEDS) {
      await d.insert(schema.faqs).values({
        topic: f.topic,
        question: f.question,
        answer: f.answer,
        verified: f.verifiedBySystem,
        published: f.verifiedBySystem,
        sortOrder: order++,
      });
    }
  }

  if (!demo) {
    console.log("✓ Base content seeded (all treatments unpublished until the clinic confirms them).");
    console.log('  Next: npm run admin:create -- --email you@clinic --name "Your Name" --role owner');
    return;
  }

  // DEMO schedule: Mon–Fri 09:00–13:00 & 14:00–18:00, Sat 09:00–13:00.
  const hours = await d.select().from(schema.workingHours).where(eq(schema.workingHours.doctorId, doctor.id));
  if (!hours.length) {
    const rows = [];
    for (const wd of [1, 2, 3, 4, 5]) {
      rows.push({ doctorId: doctor.id, weekday: wd, startMinute: 9 * 60, endMinute: 13 * 60 });
      rows.push({ doctorId: doctor.id, weekday: wd, startMinute: 14 * 60, endMinute: 18 * 60 });
    }
    rows.push({ doctorId: doctor.id, weekday: 6, startMinute: 9 * 60, endMinute: 13 * 60 });
    await d.insert(schema.workingHours).values(rows);
  }

  // Demo owner account.
  const email = "owner@gemdental.local";
  const existing = await d.select().from(schema.adminUsers).where(eq(schema.adminUsers.email, email));
  if (!existing.length) {
    const password = process.env.SEED_ADMIN_PASSWORD || randomBytes(12).toString("base64url");
    await d.insert(schema.adminUsers).values({
      email,
      name: "Demo Owner",
      role: "owner",
      passwordHash: await hashPassword(password),
    });
    console.log(`✓ Demo owner: ${email} / ${process.env.SEED_ADMIN_PASSWORD ? "(SEED_ADMIN_PASSWORD)" : password}`);
  }

  // A few demo appointments over the next days so the dashboard isn't empty.
  const existingAppts = await d.select({ id: schema.appointments.id }).from(schema.appointments).limit(1);
  if (!existingAppts.length) {
    const [settings] = await d.select().from(schema.clinicSettings);
    const tz = settings.timezone;
    const services = await d.select().from(schema.services).where(eq(schema.services.published, true));
    const bySlug = Object.fromEntries(services.map((s) => [s.slug, s]));
    const today = zonedDateKey(new Date(), tz);
    const plan: { day: number; minute: number; slug: string; status: "pending" | "confirmed"; name: string }[] = [
      { day: 1, minute: 9 * 60 + 30, slug: "dental-checkup", status: "confirmed", name: "Demo Patient A" },
      { day: 1, minute: 11 * 60, slug: "consultation", status: "pending", name: "Demo Patient B" },
      { day: 2, minute: 14 * 60 + 30, slug: "dental-cleaning", status: "confirmed", name: "Demo Patient C" },
      { day: 3, minute: 10 * 60, slug: "teeth-whitening", status: "pending", name: "Demo Patient D" },
      { day: 4, minute: 15 * 60, slug: "root-canal-treatment", status: "confirmed", name: "Demo Patient E" },
    ];
    let n = 0;
    for (const p of plan) {
      let day = addDays(today, p.day);
      // skip Sundays in the demo schedule
      const wd = new Date(`${day}T12:00:00Z`).getUTCDay();
      if (wd === 0) day = addDays(day, 1);
      const start = zonedToUtc(day, p.minute, tz);
      const svc = bySlug[p.slug];
      if (!start || !svc) continue;
      n++;
      const [patient] = await d
        .insert(schema.patients)
        .values({
          fullName: p.name,
          phone: `+38344000${String(100 + n)}`,
          email: `demo.patient.${n}@example.com`,
          preferredLocale: "sq",
          privacyAcceptedAt: new Date(),
        })
        .returning();
      const endsAt = new Date(start.getTime() + svc.durationMinutes * 60_000);
      await d.insert(schema.appointments).values({
        reference: newReference(),
        patientId: patient.id,
        doctorId: doctor.id,
        serviceId: svc.id,
        startsAt: start,
        endsAt,
        blockedUntil: new Date(endsAt.getTime() + svc.bufferMinutes * 60_000),
        status: p.status,
        source: "admin",
        patientNote: "Demo data",
        locale: "sq",
        confirmedAt: p.status === "confirmed" ? new Date() : null,
      });
    }
    console.log(`✓ ${n} demo appointments`);
  }
  console.log("✓ Demo content seeded. The public site shows a preview ribbon (Settings → Website).");
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
