/**
 * Daily maintenance: expire sessions, prune rate-limit data, apply the data
 * retention policy. Equivalent to /api/cron/maintenance.
 *
 *   npm run maintenance
 */
import { pruneExpiredSessions } from "@/lib/auth/maintenance";
import { pruneRateLimits } from "@/lib/security/rate-limit";
import { runRetention } from "@/lib/privacy";
import { getSettings } from "@/lib/settings";

async function main() {
  await pruneExpiredSessions();
  await pruneRateLimits();
  const s = await getSettings();
  const r = await runRetention(s.dataRetentionMonths);
  console.log(`✓ Maintenance done. Anonymised ${r.anonymised} patient record(s).`);
  process.exit(0);
}
main().catch((e) => {
  console.error(e);
  process.exit(1);
});
