/**
 * Import GemDental's own photographs (content/photos) into the database:
 * before/after cases, the smile & tooth-gem gallery, and the clinic photos
 * used on the About and Contact pages.
 *
 *   npm run db:import-photos              import and publish
 *   npm run db:import-photos -- --draft   import without publishing
 *
 * The clinic supplied these photos for the website, which is recorded as the
 * consent basis. Before launch, the clinic should add the reference of each
 * signed patient consent form in Dashboard → Content (or unpublish a photo).
 *
 * Safe to re-run: photos that were already imported are skipped.
 */
import { readFile } from "node:fs/promises";
import path from "node:path";
import { and, eq, inArray, isNotNull } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { storeImageBuffer } from "@/lib/admin/media";
import { CASE_DESCRIPTION, CASES, GALLERY, SITE_PHOTOS } from "../content/photos/manifest";

const DIR = path.join(process.cwd(), "content/photos");
const publish = !process.argv.includes("--draft");
const CONSENT = {
  consentObtained: true,
  consentDate: "2026-10-09",
  consentReference: "Supplied by the clinic for publication on the website. Add the signed consent form reference.",
  approvedBy: "GemDental Care",
};

async function mediaFor(key: string, alt: Record<string, string>) {
  const label = `photo:${key}`;
  const [existing] = await db().select({ id: schema.media.id }).from(schema.media).where(eq(schema.media.label, label));
  if (existing) return { id: existing.id, created: false };
  const id = await storeImageBuffer(await readFile(path.join(DIR, `${key}.webp`)), { alt, authentic: true, label });
  return { id, created: true };
}

async function main() {
  const d = db();
  let added = 0;

  for (const [i, c] of CASES.entries()) {
    const before = await mediaFor(`${c.key}-before`, c.beforeAlt);
    const after = await mediaFor(`${c.key}-after`, c.afterAlt);
    const [exists] = await d
      .select({ id: schema.resultCases.id })
      .from(schema.resultCases)
      .where(eq(schema.resultCases.afterMediaId, after.id));
    if (exists) continue;
    await d.insert(schema.resultCases).values({
      title: c.title,
      description: CASE_DESCRIPTION,
      concern: c.concern,
      beforeMediaId: before.id,
      afterMediaId: after.id,
      ...CONSENT,
      published: publish,
      sortOrder: i,
    });
    added++;
  }

  for (const [i, g] of GALLERY.entries()) {
    const m = await mediaFor(g.key, g.alt);
    const [exists] = await d
      .select({ id: schema.galleryPhotos.id })
      .from(schema.galleryPhotos)
      .where(eq(schema.galleryPhotos.mediaId, m.id));
    if (exists) continue;
    await d.insert(schema.galleryPhotos).values({
      mediaId: m.id,
      kind: g.kind,
      caption: g.caption,
      ...CONSENT,
      published: publish,
      sortOrder: i,
    });
    added++;
  }

  for (const p of SITE_PHOTOS) {
    const m = await mediaFor(p.key, p.alt);
    const taken = await d
      .select({ slot: schema.siteImages.slot })
      .from(schema.siteImages)
      .where(and(inArray(schema.siteImages.slot, p.slots), isNotNull(schema.siteImages.mediaId)));
    const takenSlots = new Set(taken.map((t) => t.slot));
    for (const slot of p.slots) {
      if (takenSlots.has(slot)) continue; // never replace a photo the clinic chose in the dashboard
      await d
        .insert(schema.siteImages)
        .values({ slot, mediaId: m.id })
        .onConflictDoUpdate({ target: schema.siteImages.slot, set: { mediaId: m.id, updatedAt: new Date() } });
      added++;
    }
  }

  console.log(`✓ Clinic photos imported (${added} new item${added === 1 ? "" : "s"}${publish ? ", published" : ", as drafts"})`);
}

main()
  .then(() => process.exit(0))
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
