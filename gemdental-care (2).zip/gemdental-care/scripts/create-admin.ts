/**
 * Create (or reset) a dashboard account from the command line.
 *
 *   npm run admin:create -- --email owner@clinic.example --name "Full Name" --role owner
 *
 * You are prompted for the password (not echoed, never stored in shell history).
 */
import { createInterface } from "node:readline";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { hashPassword, passwordProblem } from "@/lib/auth/password";

function arg(name: string) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : undefined;
}

function askHidden(q: string): Promise<string> {
  return new Promise((resolve) => {
    const rl = createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    const out = rl as unknown as { _writeToOutput: (s: string) => void; output: NodeJS.WriteStream };
    out._writeToOutput = (s: string) => {
      if (s.includes(q)) out.output.write(s);
      else out.output.write("*");
    };
    rl.question(q, (a) => {
      rl.close();
      process.stdout.write("\n");
      resolve(a);
    });
  });
}

async function main() {
  const email = arg("email")?.toLowerCase();
  const name = arg("name") ?? "Clinic Owner";
  const role = (arg("role") ?? "owner") as "owner" | "manager" | "staff";
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error("Provide --email");
  if (!["owner", "manager", "staff"].includes(role)) throw new Error("--role must be owner, manager or staff");
  const password = process.env.ADMIN_PASSWORD || (await askHidden("Password (min 12 chars): "));
  const problem = passwordProblem(password);
  if (problem) throw new Error(`Password rejected: ${problem.split(".").pop()}`);
  const hash = await hashPassword(password);
  const existing = await db().select().from(schema.adminUsers).where(eq(schema.adminUsers.email, email));
  if (existing[0]) {
    await db()
      .update(schema.adminUsers)
      .set({ passwordHash: hash, name, role, active: true, failedLogins: 0, lockedUntil: null })
      .where(eq(schema.adminUsers.id, existing[0].id));
    await db().delete(schema.sessions).where(eq(schema.sessions.userId, existing[0].id));
    console.log(`✓ Updated ${email} (${role}); existing sessions signed out.`);
  } else {
    await db().insert(schema.adminUsers).values({ email, name, role, passwordHash: hash });
    console.log(`✓ Created ${email} (${role}). Sign in at /admin/login`);
  }
  process.exit(0);
}

main().catch((e) => {
  console.error("✗", e instanceof Error ? e.message : e);
  process.exit(1);
});
