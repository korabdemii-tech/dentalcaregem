import { Pool } from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import { migrate } from "drizzle-orm/node-postgres/migrator";

export const TEST_DB_URL = process.env.TEST_DATABASE_URL ?? "postgres://gemdental:gemdental_dev@localhost:5432/gemdental_test";

export async function resetTestDatabase() {
  const pool = new Pool({ connectionString: TEST_DB_URL, max: 1 });
  await pool.query("DROP SCHEMA IF EXISTS public CASCADE; DROP SCHEMA IF EXISTS drizzle CASCADE; CREATE SCHEMA public;");
  await migrate(drizzle(pool), { migrationsFolder: "./drizzle" });
  await pool.end();
}
