/**
 * Booking engine against a real PostgreSQL database.
 * Requires TEST_DATABASE_URL (defaults to the local gemdental_test database).
 */
import { beforeAll, beforeEach, describe, expect, it } from "vitest";
import { TEST_DB_URL, resetTestDatabase } from "./helpers";

process.env.DATABASE_URL = TEST_DB_URL;
process.env.EMAIL_PROVIDER = "log";
process.env.SMS_PROVIDER = "none";
process.env.WHATSAPP_PROVIDER = "none";
process.env.SITE_URL = "http://localhost:3000";

const TZ = "Europe/Belgrade";

let mod: {
  db: typeof import("@/lib/db").db;
  schema: typeof import("@/lib/db").schema;
  createBooking: typeof import("@/lib/booking/create").createBooking;
  changeStatus: typeof import("@/lib/booking/manage").changeStatus;
  reschedule: typeof import("@/lib/booking/manage").reschedule;
  getDaySlots: typeof import("@/lib/booking/availability-service").getDaySlots;
  processNotificationQueue: typeof import("@/lib/notifications/queue").processNotificationQueue;
  scheduleDueReminders: typeof import("@/lib/notifications/queue").scheduleDueReminders;
  zonedToUtc: typeof import("@/lib/time").zonedToUtc;
  addDays: typeof import("@/lib/time").addDays;
  zonedDateKey: typeof import("@/lib/time").zonedDateKey;
};

let serviceId = "";
let doctorId = "";
let day = "";

beforeAll(async () => {
  await resetTestDatabase();
  const dbm = await import("@/lib/db");
  mod = {
    db: dbm.db,
    schema: dbm.schema,
    createBooking: (await import("@/lib/booking/create")).createBooking,
    changeStatus: (await import("@/lib/booking/manage")).changeStatus,
    reschedule: (await import("@/lib/booking/manage")).reschedule,
    getDaySlots: (await import("@/lib/booking/availability-service")).getDaySlots,
    processNotificationQueue: (await import("@/lib/notifications/queue")).processNotificationQueue,
    scheduleDueReminders: (await import("@/lib/notifications/queue")).scheduleDueReminders,
    zonedToUtc: (await import("@/lib/time")).zonedToUtc,
    addDays: (await import("@/lib/time")).addDays,
    zonedDateKey: (await import("@/lib/time")).zonedDateKey,
  };
  const { db, schema } = mod;
  await db().insert(schema.clinicSettings).values({ id: 1, timezone: TZ, minNoticeMinutes: 0, horizonDays: 90, slotIntervalMinutes: 30 });
  const [doc] = await db().insert(schema.doctors).values({ slug: "dr-test", fullName: "Dr. Test" }).returning();
  doctorId = doc.id;
  const [svc] = await db()
    .insert(schema.services)
    .values({
      slug: "checkup",
      name: { en: "Check-up", sq: "Kontroll" },
      durationMinutes: 60,
      bufferMinutes: 0,
      confirmed: true,
      published: true,
    })
    .returning();
  serviceId = svc.id;
  await db()
    .insert(schema.workingHours)
    .values([0, 1, 2, 3, 4, 5, 6].map((weekday) => ({ doctorId, weekday, startMinute: 8 * 60, endMinute: 20 * 60 })));
  day = mod.addDays(mod.zonedDateKey(new Date(), TZ), 7);
});

beforeEach(async () => {
  const { db, schema } = mod;
  await db().delete(schema.notifications);
  await db().delete(schema.appointments);
  await db().delete(schema.patients);
  await db().delete(schema.availabilityExceptions);
  await db().update(schema.clinicSettings).set({ autoConfirm: false });
});

const patient = (n: number) => ({
  fullName: `Test Patient ${n}`,
  phone: "+38344123456",
  email: `patient${n}@example.com`,
  privacyAccepted: true,
});

const booking = (start: Date, n: number, extra: Record<string, unknown> = {}) => ({
  serviceId,
  doctorId: "any" as const,
  start,
  locale: "en" as const,
  source: "online" as const,
  idempotencyKey: `key-${n}-${start.getTime()}-${Math.random().toString(36).slice(2)}`,
  patient: patient(n),
  ...extra,
});

describe("booking engine", () => {
  it("creates a pending request by default and queues the 'request received' message", async () => {
    const start = mod.zonedToUtc(day, 10 * 60, TZ)!;
    const res = await mod.createBooking(booking(start, 1));
    expect(res.ok).toBe(true);
    if (!res.ok) return;
    expect(res.status).toBe("pending");
    expect(res.reference).toMatch(/^GD-[A-Z2-9]{6}$/);
    const notes = await mod.db().select().from(mod.schema.notifications);
    expect(notes.map((n) => [n.event, n.channel, n.status])).toEqual([["request_received", "email", "queued"]]);
  });

  it("confirms immediately when auto-confirm is on", async () => {
    await mod.db().update(mod.schema.clinicSettings).set({ autoConfirm: true });
    const res = await mod.createBooking(booking(mod.zonedToUtc(day, 11 * 60, TZ)!, 2));
    expect(res.ok && res.status).toBe("confirmed");
    const notes = await mod.db().select().from(mod.schema.notifications);
    expect(notes[0].event).toBe("confirmed");
  });

  it("allows exactly one of 25 simultaneous requests for the same slot", async () => {
    const start = mod.zonedToUtc(day, 12 * 60, TZ)!;
    const results = await Promise.all(Array.from({ length: 25 }, (_, i) => mod.createBooking(booking(start, 100 + i))));
    const ok = results.filter((r) => r.ok);
    expect(ok).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "SLOT_UNAVAILABLE")).toHaveLength(24);
    const rows = await mod.db().select().from(mod.schema.appointments);
    expect(rows).toHaveLength(1);
  });

  it("prevents overlapping (not identical) simultaneous bookings", async () => {
    const a = mod.zonedToUtc(day, 14 * 60, TZ)!;
    const b = mod.zonedToUtc(day, 14 * 60 + 30, TZ)!;
    const results = await Promise.all([
      ...Array.from({ length: 10 }, (_, i) => mod.createBooking(booking(a, 200 + i))),
      ...Array.from({ length: 10 }, (_, i) => mod.createBooking(booking(b, 300 + i))),
    ]);
    expect(results.filter((r) => r.ok)).toHaveLength(1);
  });

  it("the database itself rejects overlapping active appointments", async () => {
    const start = mod.zonedToUtc(day, 16 * 60, TZ)!;
    const ok = await mod.createBooking(booking(start, 5));
    expect(ok.ok).toBe(true);
    const [p] = await mod.db().select().from(mod.schema.patients).limit(1);
    await expect(
      mod
        .db()
        .insert(mod.schema.appointments)
        .values({
          reference: "GD-RAWINS",
          patientId: p.id,
          doctorId,
          serviceId,
          startsAt: new Date(start.getTime() + 15 * 60_000),
          endsAt: new Date(start.getTime() + 45 * 60_000),
          blockedUntil: new Date(start.getTime() + 45 * 60_000),
          status: "pending",
        }),
    ).rejects.toMatchObject({ cause: { code: "23P01" } });
  });

  it("is idempotent: retrying with the same key returns the same appointment", async () => {
    const start = mod.zonedToUtc(day, 17 * 60, TZ)!;
    const req = booking(start, 6);
    const [r1, r2] = await Promise.all([mod.createBooking(req), mod.createBooking(req)]);
    const r3 = await mod.createBooking(req);
    expect(r1.ok && r2.ok && r3.ok).toBe(true);
    if (r1.ok && r2.ok && r3.ok) {
      expect(new Set([r1.reference, r2.reference, r3.reference]).size).toBe(1);
    }
    expect(await mod.db().select().from(mod.schema.appointments)).toHaveLength(1);
    expect(await mod.db().select().from(mod.schema.notifications)).toHaveLength(1);
  });

  it("refuses slots outside working hours or during time off", async () => {
    const early = await mod.createBooking(booking(mod.zonedToUtc(day, 7 * 60, TZ)!, 7));
    expect(early).toEqual({ ok: false, code: "SLOT_UNAVAILABLE" });
    await mod
      .db()
      .insert(mod.schema.availabilityExceptions)
      .values({
        doctorId,
        kind: "time_off",
        startsAt: mod.zonedToUtc(day, 9 * 60, TZ)!,
        endsAt: mod.zonedToUtc(day, 10 * 60, TZ)!,
      });
    const off = await mod.createBooking(booking(mod.zonedToUtc(day, 9 * 60, TZ)!, 8));
    expect(off).toEqual({ ok: false, code: "SLOT_UNAVAILABLE" });
  });

  it("frees the slot after cancellation and sends a cancellation message", async () => {
    const start = mod.zonedToUtc(day, 13 * 60, TZ)!;
    const r = await mod.createBooking(booking(start, 9));
    if (!r.ok) throw new Error("expected booking");
    const before = await mod.getDaySlots({
      service: (await mod.db().select().from(mod.schema.services))[0],
      doctorIds: [doctorId],
      date: day,
    });
    expect(before.find((s) => s.start === start.toISOString())).toBeUndefined();
    const actor = { id: "00000000-0000-0000-0000-000000000000", label: "test" };
    expect(await mod.changeStatus(r.appointmentId, "cancelled", actor)).toEqual({ ok: true });
    expect(await mod.changeStatus(r.appointmentId, "confirmed", actor)).toEqual({ ok: false, code: "INVALID_TRANSITION" });
    const after = await mod.getDaySlots({
      service: (await mod.db().select().from(mod.schema.services))[0],
      doctorIds: [doctorId],
      date: day,
    });
    expect(after.find((s) => s.start === start.toISOString())).toBeDefined();
    const events = (await mod.db().select().from(mod.schema.notifications)).map((n) => n.event).sort();
    expect(events).toEqual(["cancelled", "request_received"]);
  });

  it("reschedules only into free time", async () => {
    const actor = { id: "00000000-0000-0000-0000-000000000000", label: "test" };
    const a = await mod.createBooking(booking(mod.zonedToUtc(day, 9 * 60, TZ)!, 10));
    const b = await mod.createBooking(booking(mod.zonedToUtc(day, 11 * 60, TZ)!, 11));
    if (!a.ok || !b.ok) throw new Error("expected bookings");
    expect(await mod.reschedule(a.appointmentId, { start: mod.zonedToUtc(day, 11 * 60, TZ)! }, actor)).toEqual({
      ok: false,
      code: "OUTSIDE_AVAILABILITY",
    });
    expect(await mod.reschedule(a.appointmentId, { start: mod.zonedToUtc(day, 11 * 60 + 30, TZ)!, ignoreSchedule: true }, actor)).toEqual({
      ok: false,
      code: "CONFLICT",
    });
    expect(await mod.reschedule(a.appointmentId, { start: mod.zonedToUtc(day, 15 * 60, TZ)! }, actor)).toEqual({ ok: true });
  });

  it("delivers queued messages once, even when the worker runs concurrently", async () => {
    await mod.createBooking(booking(mod.zonedToUtc(day, 18 * 60, TZ)!, 12));
    const runs = await Promise.all([mod.processNotificationQueue(), mod.processNotificationQueue(), mod.processNotificationQueue()]);
    expect(runs.reduce((n, r) => n + r.sent, 0)).toBe(1);
    const [n] = await mod.db().select().from(mod.schema.notifications);
    expect(n.status).toBe("logged");
    expect(n.attempts).toBe(1);
  });

  it("queues each reminder once", async () => {
    await mod.db().update(mod.schema.clinicSettings).set({ autoConfirm: true });
    const soon = new Date(Date.now() + 3 * 60 * 60_000);
    soon.setUTCMinutes(0, 0, 0);
    const r = await mod.createBooking({ ...booking(soon, 13), source: "admin", ignoreSchedule: true });
    if (!r.ok) throw new Error("expected booking");
    // Pretend it was confirmed two days ago.
    await mod
      .db()
      .update(mod.schema.appointments)
      .set({ confirmedAt: new Date(Date.now() - 2 * 86_400_000) });
    await mod.scheduleDueReminders();
    await mod.scheduleDueReminders();
    const reminders = (await mod.db().select().from(mod.schema.notifications)).filter((n) => n.event === "reminder");
    expect(reminders).toHaveLength(1); // 24h rule only (2h rule disabled by default)
  });
});
