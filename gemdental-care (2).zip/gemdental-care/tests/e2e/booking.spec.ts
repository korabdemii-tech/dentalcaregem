import { test, expect, type Page } from "@playwright/test";
import { firstSlot, ipHeader, sql } from "./helpers";

test.use({ extraHTTPHeaders: ipHeader() });
test.beforeAll(async () => {
  await sql().query("update clinic_settings set auto_confirm=false");
});

async function pickServiceAndFirstTime(page: Page, serviceName: RegExp) {
  await page.getByRole("button", { name: serviceName }).click();
  const day = page.locator('table[role=grid] button[aria-disabled="false"]').first();
  await expect(day).toBeVisible();
  await day.click();
  const slot = page.locator('label:has(input[name="slot"])').first();
  await expect(slot).toBeVisible();
  await slot.click();
  await page.getByRole("button", { name: "Continue" }).click();
}

async function fillDetails(page: Page, email: string) {
  await page.fill("#f-fullName", "Elira Gashi");
  await page.fill("#f-phone", "+383 44 555 666");
  await page.fill("#f-email", email);
  await page.check("#f-acceptPrivacy");
  await page.waitForTimeout(2100); // the server rejects submissions faster than a human could type
  await page.getByRole("button", { name: "Continue" }).click();
}

test.describe("booking flow", () => {
  test("validates details before review", async ({ page }) => {
    await page.goto("/en/booking");
    await pickServiceAndFirstTime(page, /Dental check-up/);
    await page.getByRole("button", { name: "Continue" }).click();
    await expect(page.getByText("Please enter your full name.")).toBeVisible();
    await expect(page.locator("#f-fullName")).toBeFocused();
    await page.fill("#f-phone", "12");
    await page.locator("#f-phone").blur();
    await expect(page.getByText("Please enter a valid phone number, including the country code.")).toBeVisible();
    await page.fill("#f-email", "not-an-email");
    await page.locator("#f-email").blur();
    await expect(page.getByText("Please enter a valid email address, like name@example.com.")).toBeVisible();
    await expect(page.getByText("Please accept the privacy policy to continue.")).toBeVisible();
  });

  test("books a request and clearly says it is not yet confirmed", async ({ page }) => {
    await page.goto("/en/booking");
    await pickServiceAndFirstTime(page, /Dental check-up/);
    await fillDetails(page, "elira.pending@example.com");
    await expect(page.getByRole("heading", { name: "Check and confirm" })).toBeVisible();
    await expect(page.getByText("Your booking will be sent to the clinic as a request.").first()).toBeVisible();
    await page.getByRole("button", { name: "Send booking request" }).click();
    await expect(page.getByRole("heading", { name: "Your appointment request has been received." })).toBeVisible();
    const ref = (await page.getByTestId("booking-reference").textContent())!.trim();
    expect(ref).toMatch(/^GD-[A-Z2-9]{6}$/);
    const row = await sql().query("select a.status, p.email from appointments a join patients p on p.id=a.patient_id where reference=$1", [
      ref,
    ]);
    expect(row.rows[0]).toEqual({ status: "pending", email: "elira.pending@example.com" });
    const notes = await sql().query(
      "select n.event, n.channel from notifications n join appointments a on a.id=n.appointment_id where a.reference=$1",
      [ref],
    );
    expect(notes.rows).toEqual([{ event: "request_received", channel: "email" }]);
  });

  test("the booked slot is no longer offered", async ({ request }) => {
    const before = await firstSlot(request, "dental-cleaning");
    const r = await request.get(`/api/booking/session`);
    const { token } = await r.json();
    await new Promise((res) => setTimeout(res, 2100));
    const res = await request.post("/api/booking", {
      headers: { ...ipHeader(), Origin: new URL(r.url()).origin },
      data: {
        serviceId: before.serviceId,
        doctorId: "any",
        start: before.slot.start,
        locale: "en",
        idempotencyKey: `e2e${Date.now()}aaaaaaaaaaaa`,
        sessionToken: token,
        website: "",
        patient: { fullName: "Api Test", phone: "+38344111222", email: "api@example.com", acceptPrivacy: true },
      },
    });
    expect(res.status()).toBe(201);
    const after = await (
      await request.get(`/api/booking/slots?service=${before.serviceId}&doctor=any&date=${before.date}`, { headers: ipHeader() })
    ).json();
    expect(after.slots.map((s: { start: string }) => s.start)).not.toContain(before.slot.start);
  });

  test("if someone else takes the time first, the patient is told and keeps their details", async ({ page, browser }) => {
    await page.goto("/en/booking");
    await pickServiceAndFirstTime(page, /Professional cleaning/);
    await fillDetails(page, "elira.race@example.com");
    // A second visitor books the same time in the meantime.
    const other = await browser.newContext({ extraHTTPHeaders: ipHeader() });
    const p2 = await other.newPage();
    await p2.goto("/en/booking");
    await pickServiceAndFirstTime(p2, /Professional cleaning/);
    await fillDetails(p2, "other.person@example.com");
    await p2.getByRole("button", { name: "Send booking request" }).click();
    await expect(p2.getByRole("heading", { name: /request has been received/ })).toBeVisible();
    await other.close();
    // First visitor now submits.
    await page.getByRole("button", { name: "Send booking request" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "that time was just booked by someone else" })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Choose a day" })).toBeVisible();
    // Pick another time (another day if this one is now full); details are still filled in.
    if (!(await page.locator('label:has(input[name="slot"])').count())) {
      await page.locator('table[role=grid] button[aria-disabled="false"][aria-pressed="false"]').first().click();
    }
    await page.locator('label:has(input[name="slot"])').first().click();
    await page.getByRole("button", { name: "Continue" }).click();
    await expect(page.locator("#f-email")).toHaveValue("elira.race@example.com");
  });

  test("works in Albanian end to end", async ({ page }) => {
    await page.goto("/sq/booking");
    await page
      .getByRole("button", { name: /Konsultë/ })
      .first()
      .click();
    await page.locator('table[role=grid] button[aria-disabled="false"]').first().click();
    await page.locator('label:has(input[name="slot"])').first().click();
    await page.getByRole("button", { name: "Vazhdo" }).click();
    await page.fill("#f-fullName", "Besa Krasniqi");
    await page.fill("#f-phone", "+355 69 123 4567");
    await page.fill("#f-email", "besa@example.com");
    await page.check("#f-acceptPrivacy");
    await page.waitForTimeout(2100);
    await page.getByRole("button", { name: "Vazhdo" }).click();
    await page.getByRole("button", { name: "Dërgo kërkesën për rezervim" }).click();
    await expect(page.getByRole("heading", { name: "Kërkesa juaj për termin u pranua." })).toBeVisible();
  });

  test("calendar is keyboard operable", async ({ page }) => {
    await page.goto("/en/booking?service=dental-checkup");
    const firstAvail = page.locator('table[role=grid] button[aria-disabled="false"]').first();
    await expect(firstAvail).toBeVisible();
    await page.locator('table[role=grid] button[tabindex="0"]').focus();
    await page.keyboard.press("ArrowRight");
    const focused = await page.evaluate(() => document.activeElement?.getAttribute("data-date"));
    expect(focused).toMatch(/^\d{4}-\d{2}-\d{2}$/);
    await firstAvail.focus();
    await page.keyboard.press("Enter");
    await expect(page.locator('label:has(input[name="slot"])').first()).toBeVisible();
  });
});

test.describe("booking API protections", () => {
  async function base(request: import("@playwright/test").APIRequestContext) {
    const s = await firstSlot(request, "teeth-whitening");
    const { token } = await (await request.get("/api/booking/session")).json();
    return {
      s,
      body: {
        serviceId: s.serviceId,
        doctorId: "any",
        start: s.all[s.all.length - 1].start,
        locale: "en",
        idempotencyKey: `idem${Date.now()}${Math.random().toString(36).slice(2, 10)}`,
        sessionToken: token as string,
        website: "",
        patient: { fullName: "Guard Test", phone: "+38344999888", email: `guard${Date.now()}@example.com`, acceptPrivacy: true },
      },
    };
  }
  const origin = "http://localhost:3100";

  test("rejects cross-site requests", async ({ request }) => {
    const { body } = await base(request);
    const res = await request.post("/api/booking", { headers: { ...ipHeader(), Origin: "https://evil.example" }, data: body });
    expect(res.status()).toBe(403);
  });

  test("rejects bots: honeypot and too-fast submissions", async ({ request }) => {
    const { body } = await base(request);
    const fast = await request.post("/api/booking", { headers: { ...ipHeader(), Origin: origin }, data: body });
    expect((await fast.json()).error).toBe("BOT");
    await new Promise((r) => setTimeout(r, 2100));
    const honey = await request.post("/api/booking", {
      headers: { ...ipHeader(), Origin: origin },
      data: { ...body, website: "http://spam" },
    });
    expect((await honey.json()).error).toBe("BOT");
  });

  test("rejects expired or forged session tokens", async ({ request }) => {
    const { body } = await base(request);
    const forged = await request.post("/api/booking", {
      headers: { ...ipHeader(), Origin: origin },
      data: { ...body, sessionToken: "eyJpYXQiOjB9.bad" },
    });
    expect((await forged.json()).error).toBe("SESSION_EXPIRED");
  });

  test("server-side validation", async ({ request }) => {
    const { body } = await base(request);
    await new Promise((r) => setTimeout(r, 2100));
    const res = await request.post("/api/booking", {
      headers: { ...ipHeader(), Origin: origin },
      data: { ...body, patient: { ...body.patient, phone: "123", email: "x" } },
    });
    expect(res.status()).toBe(422);
    const j = await res.json();
    expect(j.fields["patient.phone"]).toBe("errors.phoneInvalid");
    expect(j.fields["patient.email"]).toBe("errors.emailInvalid");
  });

  test("idempotent retries create one appointment", async ({ request }) => {
    const { body } = await base(request);
    await new Promise((r) => setTimeout(r, 2100));
    const h = { ...ipHeader(), Origin: origin };
    const [a, b] = await Promise.all([
      request.post("/api/booking", { headers: h, data: body }),
      request.post("/api/booking", { headers: h, data: body }),
    ]);
    const ja = await a.json();
    const jb = await b.json();
    expect(ja.reference).toBe(jb.reference);
    const n = await sql().query("select count(*)::int as n from appointments where idempotency_key=$1", [body.idempotencyKey]);
    expect(n.rows[0].n).toBe(1);
  });

  test("rate limits repeated attempts from one address", async ({ request }) => {
    const ip = ipHeader();
    let limited = false;
    for (let i = 0; i < 10; i++) {
      const res = await request.post("/api/booking", { headers: { ...ip, Origin: origin }, data: { nope: true } });
      if (res.status() === 429) {
        limited = true;
        expect(res.headers()["retry-after"]).toBeTruthy();
        break;
      }
    }
    expect(limited).toBe(true);
  });

  test("past dates and far-future dates have no slots", async ({ request }) => {
    const { s } = await base(request);
    const past = await (
      await request.get(`/api/booking/slots?service=${s.serviceId}&doctor=any&date=2020-01-06`, { headers: ipHeader() })
    ).json();
    expect(past.slots).toEqual([]);
    const far = await (
      await request.get(`/api/booking/slots?service=${s.serviceId}&doctor=any&date=2030-01-07`, { headers: ipHeader() })
    ).json();
    expect(far.slots).toEqual([]);
  });
});
