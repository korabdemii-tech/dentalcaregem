import { test, expect } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { noHorizontalOverflow } from "./helpers";

const PAGES = ["", "/services", "/services/dental-checkup", "/results", "/about", "/team", "/contact", "/booking", "/privacy", "/terms"];

test.describe("public website", () => {
  test("bare URL redirects to a language", async ({ page }) => {
    await page.goto("/");
    await expect(page).toHaveURL(/\/(sq|en)$/);
  });

  for (const locale of ["sq", "en"] as const) {
    test(`all pages render without errors (${locale})`, async ({ page }) => {
      const errors: string[] = [];
      page.on("pageerror", (e) => errors.push(e.message));
      page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
      for (const p of PAGES) {
        const res = await page.goto(`/${locale}${p}`);
        expect(res?.status(), `${p} status`).toBe(200);
        await expect(page.locator("h1")).toHaveCount(1);
        await expect(page.locator("html")).toHaveAttribute("lang", locale === "sq" ? "sq-AL" : "en-GB");
        await expect(page.locator('link[rel="canonical"]')).toHaveAttribute("href", new RegExp(`/${locale}${p}$`));
        await noHorizontalOverflow(page);
      }
      expect(errors).toEqual([]);
    });
  }

  test("booking is one click from the homepage", async ({ page }) => {
    await page.goto("/en");
    await page.getByRole("link", { name: "Book an appointment" }).first().click();
    await expect(page).toHaveURL(/\/en\/booking$/);
    await expect(page.getByRole("heading", { name: "Book an appointment" })).toBeVisible();
  });

  test("main navigation works and marks the current page", async ({ page }) => {
    await page.goto("/en");
    const nav = page.getByRole("navigation", { name: "Main" }).first();
    await nav.getByRole("link", { name: "Treatments" }).click();
    await expect(page).toHaveURL(/\/en\/services$/);
    await expect(nav.getByRole("link", { name: "Treatments" })).toHaveAttribute("aria-current", "page");
    await nav.getByRole("link", { name: "Our doctor" }).click();
    await expect(page.getByRole("heading", { level: 2, name: "Dr. Genc Bejtullahu" })).toBeVisible();
  });

  test("language switch keeps the current page", async ({ page }) => {
    await page.goto("/en/services");
    await page.getByRole("group", { name: "Language" }).getByRole("link", { name: "sq" }).click();
    await expect(page).toHaveURL(/\/sq\/services$/);
    await expect(page.getByRole("heading", { level: 1 })).toHaveText("Trajtimet");
  });

  test("unknown pages return 404 with a way back", async ({ page }) => {
    const res = await page.goto("/en/does-not-exist");
    expect(res?.status()).toBe(404);
    await expect(page.getByRole("link", { name: /homepage|faqja kryesore/i })).toBeVisible();
  });

  test("unpublished treatments are not public", async ({ page }) => {
    const res = await page.goto("/en/services/general-dentistry");
    expect(res?.status()).toBe(404);
  });

  test("no fabricated details: unconfirmed contact info is shown as 'To be confirmed'", async ({ page }) => {
    await page.goto("/en/contact");
    await expect(page.getByText("To be confirmed").first()).toBeVisible();
    // Reviews and before/after sections stay hidden until genuine content is published.
    await page.goto("/en");
    await expect(page.getByRole("heading", { name: "In our patients' words" })).toHaveCount(0);
    await expect(page.getByRole("heading", { name: "Results" })).toHaveCount(0);
  });

  test("SEO: sitemap, robots and structured data", async ({ page, request }) => {
    const sm = await (await request.get("/sitemap.xml")).text();
    expect(sm).toContain("/sq/services/dental-checkup");
    expect(sm).toContain("/en/booking");
    expect(sm).not.toContain("general-dentistry");
    const robots = await (await request.get("/robots.txt")).text();
    expect(robots).toContain("Disallow: /admin");
    await page.goto("/en");
    const ld = JSON.parse((await page.locator('script[type="application/ld+json"]').first().textContent()) ?? "{}");
    expect(ld["@type"]).toBe("Dentist");
    expect(ld.telephone).toBeUndefined(); // never invented
    await expect(page.locator('link[rel="alternate"][hreflang="sq-AL"]')).toHaveCount(1);
  });

  test("security headers are set", async ({ request }) => {
    const res = await request.get("/en");
    const h = res.headers();
    expect(h["content-security-policy"]).toContain("frame-ancestors 'none'");
    expect(h["x-content-type-options"]).toBe("nosniff");
    expect(h["x-frame-options"]).toBe("DENY");
    expect(h["x-powered-by"]).toBeUndefined();
  });

  for (const p of ["/en", "/en/services/dental-checkup", "/en/booking", "/sq/contact", "/en/results", "/sq/results"]) {
    test(`accessibility: no serious violations on ${p}`, async ({ page }) => {
      // Check the settled page, not scroll-reveal animations mid-fade.
      await page.emulateMedia({ reducedMotion: "reduce" });
      await page.goto(p);
      const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa", "wcag22aa"]).analyze();
      const serious = results.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
      expect(
        serious.map(
          (v) =>
            `${v.id}: ${v.nodes
              .map((n) => n.target.join(" "))
              .slice(0, 3)
              .join(", ")}`,
        ),
      ).toEqual([]);
    });
  }

  test("respects reduced motion", async ({ browser }) => {
    const ctx = await browser.newContext({ reducedMotion: "reduce" });
    const page = await ctx.newPage();
    await page.goto("/en");
    const opacity = await page.locator("h1").evaluate((el) => getComputedStyle(el).opacity);
    expect(opacity).toBe("1");
    await ctx.close();
  });
});

test.describe("mobile @mobile", () => {
  test("mobile menu opens, traps focus and closes with Escape @mobile", async ({ page }) => {
    await page.goto("/en");
    const toggle = page.getByRole("button", { name: "Open menu" });
    await toggle.click();
    const menu = page.locator("#mobile-menu");
    await expect(menu).toBeVisible();
    await expect(menu.getByRole("link", { name: "Treatments" })).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(menu).toBeHidden();
    await expect(page.getByRole("button", { name: "Open menu" })).toBeFocused();
  });

  test("sticky booking bar appears after scrolling @mobile", async ({ page }) => {
    await page.goto("/en");
    await page.mouse.wheel(0, 1500);
    await expect(page.locator("div.fixed.bottom-0").getByRole("link", { name: "Book appointment" })).toBeInViewport();
  });

  for (const width of [320, 375, 390, 430, 768, 1024, 1440]) {
    test(`no horizontal overflow at ${width}px @mobile`, async ({ page }) => {
      await page.setViewportSize({ width, height: 800 });
      for (const p of ["/sq", "/sq/booking", "/sq/services/dental-implants", "/en/contact"]) {
        await page.goto(p);
        await noHorizontalOverflow(page);
      }
    });
  }
});
