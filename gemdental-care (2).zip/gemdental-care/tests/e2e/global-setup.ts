import { execSync } from "node:child_process";
import { Pool } from "pg";

export const E2E_DB = process.env.E2E_DATABASE_URL ?? "postgres://gemdental:gemdental_dev@localhost:5432/gemdental_e2e";
export const OWNER = { email: "owner@gemdental.local", password: "GemDental-Demo-2026!" };
export const STAFF = { email: "staff@gemdental.local", password: "Staff-Test-2026!" };

export default async function globalSetup() {
  const pool = new Pool({ connectionString: E2E_DB, max: 1 });
  await pool.query("DROP SCHEMA IF EXISTS public CASCADE; DROP SCHEMA IF EXISTS drizzle CASCADE; CREATE SCHEMA public;");
  await pool.end();
  const env = { ...process.env, DATABASE_URL: E2E_DB, SEED_ADMIN_PASSWORD: OWNER.password };
  execSync("npx tsx scripts/migrate.ts", { env, stdio: "inherit" });
  execSync("npx tsx --conditions=react-server scripts/seed.ts --demo", { env, stdio: "inherit" });
  execSync("npx tsx --conditions=react-server scripts/import-photos.ts", { env, stdio: "inherit" });
  execSync(`npx tsx --conditions=react-server scripts/create-admin.ts --email ${STAFF.email} --name "Test Staff" --role staff`, {
    env: { ...env, ADMIN_PASSWORD: STAFF.password },
    stdio: "inherit",
  });
}
