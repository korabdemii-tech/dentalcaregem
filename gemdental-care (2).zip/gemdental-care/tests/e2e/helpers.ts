import { expect, type Page, type APIRequestContext } from "@playwright/test";
import { Pool } from "pg";
import { E2E_DB, OWNER } from "./global-setup";

let pool: Pool | null = null;
export function sql() {
  pool ??= new Pool({ connectionString: E2E_DB, max: 2 });
  return pool;
}

export async function login(page: Page, who = OWNER) {
  // A fresh client address per sign-in keeps the login rate limiter out of the way.
  await page.setExtraHTTPHeaders(ipHeader());
  await page.goto("/admin/login");
  await page.fill("#email", who.email);
  await page.fill("#password", who.password);
  await page.click("button[type=submit]");
  await page.waitForURL("**/admin");
}

/** Each test uses its own fake client IP so rate limits don't interfere. */
export function ipHeader() {
  const ip = `10.${rand()}.${rand()}.${rand()}`;
  return { "x-real-ip": ip, "x-forwarded-for": ip };
}
function rand() {
  return Math.floor(Math.random() * 250) + 1;
}

export async function serviceId(slug: string) {
  const r = await sql().query("select id from services where slug=$1", [slug]);
  return r.rows[0].id as string;
}

/** First bookable slot for a service, via the public API. */
export async function firstSlot(request: APIRequestContext, slug: string) {
  const id = await serviceId(slug);
  const now = new Date();
  for (let i = 0; i < 3; i++) {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + i, 1));
    const month = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
    const m = await (
      await request.get(`/api/booking/availability?service=${id}&doctor=any&month=${month}`, { headers: ipHeader() })
    ).json();
    for (const date of m.available as string[]) {
      const s = await (await request.get(`/api/booking/slots?service=${id}&doctor=any&date=${date}`, { headers: ipHeader() })).json();
      if (s.slots.length) return { serviceId: id, date, slot: s.slots[0] as { start: string }, all: s.slots as { start: string }[] };
    }
  }
  throw new Error("No slots available");
}

export async function noHorizontalOverflow(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(overflow, "page should not scroll horizontally").toBeLessThanOrEqual(1);
}
