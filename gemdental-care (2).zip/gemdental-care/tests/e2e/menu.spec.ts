import { test, expect } from "@playwright/test";
test("mobile menu close button stays reachable below the preview ribbon @mobile", async ({ page }) => {
  await page.goto("/sq");
  await page.getByRole("button", { name: "Hap menunë" }).click();
  await expect(page.locator("#mobile-menu")).toBeVisible();
  await page.getByRole("button", { name: "Mbyll menunë" }).click();
  await expect(page.locator("#mobile-menu")).toBeHidden();
});
