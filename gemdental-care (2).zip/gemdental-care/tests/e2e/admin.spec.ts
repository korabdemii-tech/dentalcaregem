import { test, expect } from "@playwright/test";
import sharp from "sharp";
import { firstSlot, ipHeader, login, sql } from "./helpers";
import { STAFF } from "./global-setup";

test.use({ extraHTTPHeaders: ipHeader() });

test.describe("dashboard security", () => {
  test("is not reachable without signing in", async ({ page, request }) => {
    await page.goto("/admin/appointments");
    await expect(page).toHaveURL(/\/admin\/login$/);
    // A forged cookie is not enough either: sessions are checked in the database.
    await page.context().addCookies([{ name: "gd_admin_session", value: "forged-token-value", url: "http://localhost:3100" }]);
    await page.goto("/admin/appointments");
    await expect(page).toHaveURL(/\/admin\/login$/);
    const res = await request.get("/admin/settings", { maxRedirects: 0 });
    expect([302, 303, 307, 308]).toContain(res.status());
  });

  test("wrong password shows a generic error", async ({ page }) => {
    await page.goto("/admin/login");
    await page.fill("#email", "owner@gemdental.local");
    await page.fill("#password", "wrong-password-123");
    await page.click("button[type=submit]");
    await expect(
      page.getByRole("alert").filter({ hasText: /Email or password is incorrect|Emaili ose fjalëkalimi është i pasaktë/ }),
    ).toBeVisible();
  });

  test("staff role cannot open settings or manage accounts", async ({ page }) => {
    await login(page, STAFF);
    await expect(page.getByRole("link", { name: /Cilësimet e klinikës|Clinic settings/ })).toHaveCount(0);
    // With streaming (loading.tsx) the HTTP status may already be 200 when the
    // permission check runs; what matters is that no protected content renders.
    await page.goto("/admin/settings");
    await expect(page.getByRole("heading", { name: /Nuk keni leje|Permission denied/ })).toBeVisible();
    await expect(page.locator('input[name="clinicName"]')).toHaveCount(0);
    await page.goto("/admin/users");
    await expect(page.getByRole("heading", { name: /Nuk keni leje|Permission denied/ })).toBeVisible();
    await expect(page.locator('input[name="password"]')).toHaveCount(0);
    // ...but can work with appointments.
    expect((await page.goto("/admin/appointments"))?.status()).toBe(200);
  });

  test("sign out ends the session", async ({ page }) => {
    await login(page);
    await page
      .getByRole("button", { name: /Dil|Sign out/ })
      .first()
      .click({ force: true });
    await expect(page).toHaveURL(/\/admin\/login$/);
    await page.goto("/admin");
    await expect(page).toHaveURL(/\/admin\/login$/);
  });
});

test.describe("appointment management", () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
    // Use English for stable selectors.
    await page.getByRole("button", { name: "English" }).first().click({ force: true });
    await page.waitForLoadState("networkidle");
  });

  test("overview shows real counts and pending requests", async ({ page }) => {
    await page.goto("/admin");
    const pending = await sql().query("select count(*)::int n from appointments where status='pending' and starts_at > now()");
    await expect(page.getByRole("link", { name: new RegExp(`Pending requests\\s*${pending.rows[0].n}`) })).toBeVisible();
  });

  test("confirming a request queues the confirmation message", async ({ page }) => {
    const r = await sql().query("select id, reference from appointments where status='pending' order by starts_at limit 1");
    const { id, reference } = r.rows[0];
    await page.goto(`/admin/appointments/${id}`);
    await page.getByRole("button", { name: "Confirm appointment" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Appointment confirmed" })).toBeVisible();
    await expect(page.getByText("Confirmed", { exact: true }).first()).toBeVisible();
    const st = await sql().query("select status from appointments where reference=$1", [reference]);
    expect(st.rows[0].status).toBe("confirmed");
    await expect
      .poll(
        async () =>
          (await sql().query("select status from notifications where appointment_id=$1 and event='confirmed'", [id])).rows[0]?.status,
      )
      .toBe("logged");
  });

  test("moving an appointment onto another refuses the overlap", async ({ page }) => {
    const rows = await sql().query(
      "select id, starts_at from appointments where status in ('pending','confirmed') and starts_at > now() order by starts_at limit 2",
    );
    const [a, b] = rows.rows;
    const tz = "Europe/Belgrade";
    const fmt = (d: Date) =>
      new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" }).format(d);
    const hm = (d: Date) =>
      new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(d);
    await page.goto(`/admin/appointments/${a.id}`);
    await page.fill("#mv-date", fmt(b.starts_at));
    await page.fill("#mv-time", hm(b.starts_at));
    await page.getByLabel("Allow outside regular hours").check();
    await page.getByRole("button", { name: "Move appointment" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "overlaps another appointment" })).toBeVisible();
  });

  test("blocking time removes it from online booking", async ({ page, request }) => {
    const s = await firstSlot(request, "consultation");
    await page.goto("/admin/availability");
    await page.fill("#fld-startDate", s.date);
    await page.fill("#fld-endDate", s.date);
    await page.getByLabel("All day").check();
    await page.getByRole("button", { name: "Block this time" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Time blocked" })).toBeVisible();
    const after = await (
      await request.get(`/api/booking/slots?service=${s.serviceId}&doctor=any&date=${s.date}`, { headers: ipHeader() })
    ).json();
    expect(after.slots).toEqual([]);
    // Clean up
    await page.getByRole("button", { name: "Remove" }).first().click();
  });

  test("staff can create an appointment by phone", async ({ page }) => {
    await page.goto("/admin/appointments/new");
    await page.fill("#fld-fullName", "Phone Booking");
    await page.fill("#fld-phone", "+38349123123");
    await page.fill("#fld-email", "phone.booking@example.com");
    const next = new Date(Date.now() + 20 * 86_400_000);
    const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Belgrade", year: "numeric", month: "2-digit", day: "2-digit" }).format(
      next,
    );
    await page.fill("#fld-date", day);
    await page.fill("#fld-time", "07:15");
    await page.getByLabel("Allow outside regular hours").check();
    await page.getByRole("button", { name: "Create appointment" }).click();
    await expect(page).toHaveURL(/\/admin\/appointments\/[0-9a-f-]{36}\?created=1/);
    await expect(page.getByText("Phone Booking").first()).toBeVisible();
  });

  test("calendar views render appointments", async ({ page }) => {
    for (const v of ["day", "week", "month"]) {
      const res = await page.goto(`/admin/calendar?view=${v}`);
      expect(res?.status()).toBe(200);
    }
    const r = await sql().query(
      "select starts_at from appointments where status<>'cancelled' and starts_at > now() order by starts_at limit 1",
    );
    const day = new Intl.DateTimeFormat("en-CA", { timeZone: "Europe/Belgrade", year: "numeric", month: "2-digit", day: "2-digit" }).format(
      r.rows[0].starts_at,
    );
    await page.goto(`/admin/calendar?view=week&date=${day}`);
    await expect(page.locator('a[href^="/admin/appointments/"]').first()).toBeVisible();
  });
});

test.describe("clinic management", () => {
  test.afterEach(async () => {
    // Never leave global settings changed for the next test, even when a test fails.
    await sql().query("update clinic_settings set auto_confirm=false, phone=null, timezone='Europe/Belgrade'");
  });
  test.beforeEach(async ({ page }) => {
    await login(page);
    await page.getByRole("button", { name: "English" }).first().click({ force: true });
    await page.waitForLoadState("networkidle");
  });

  test("auto-confirm setting changes what patients are told", async ({ page, browser }) => {
    test.info().annotations.push({ type: "cleanup", description: "auto_confirm reset in afterEach" });
    await page.goto("/admin/settings");
    await page.getByLabel("Confirm online bookings automatically").check();
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Settings saved" })).toBeVisible();

    const ctx = await browser.newContext({ extraHTTPHeaders: ipHeader() });
    const p = await ctx.newPage();
    await p.goto("/en/booking?service=veneers");
    await p.locator('table[role=grid] button[aria-disabled="false"]').first().click();
    await p.locator('label:has(input[name="slot"])').first().click();
    await p.getByRole("button", { name: "Continue" }).click();
    await p.fill("#f-fullName", "Auto Confirm");
    await p.fill("#f-phone", "+38344777888");
    await p.fill("#f-email", "auto@example.com");
    await p.check("#f-acceptPrivacy");
    await p.waitForTimeout(2100);
    await p.getByRole("button", { name: "Continue" }).click();
    await p.getByRole("button", { name: "Confirm booking" }).click();
    await expect(p.getByRole("heading", { name: "Your appointment is confirmed." })).toBeVisible();
    await expect(p.getByRole("link", { name: "Add to calendar" })).toBeVisible();
    await ctx.close();

    await page.goto("/admin/settings");
    await page.getByLabel("Confirm online bookings automatically").uncheck();
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Settings saved" })).toBeVisible();
  });

  test("contact details entered by the clinic appear on the website", async ({ page }) => {
    await page.goto("/admin/settings");
    await page.fill("#fld-phone", "+383 44 000 000");
    await page.fill("#fld-timezone", "Not/AZone");
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "Check the highlighted fields" })).toBeVisible();
    await page.fill("#fld-timezone", "Europe/Belgrade");
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Settings saved" })).toBeVisible();
    await page.goto("/en/contact");
    await expect(page.getByRole("link", { name: "+383 44 000 000" }).first()).toHaveAttribute("href", "tel:+38344000000");
    await expect(page.getByRole("link", { name: "Call" }).first()).toBeVisible();
    // revert
    await page.goto("/admin/settings");
    await page.fill("#fld-phone", "");
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Settings saved" })).toBeVisible();
  });

  test("a treatment cannot be published before the clinic confirms it", async ({ page }) => {
    const r = await sql().query("select id from services where slug='cosmetic-dentistry'");
    await page.goto(`/admin/services/${r.rows[0].id}`);
    await page.getByLabel("Published on website").check();
    await page.getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "must be confirmed by the clinic" })).toBeVisible();
  });

  test("uploaded clinic photo replaces the placeholder", async ({ page }) => {
    const png = await sharp({ create: { width: 1200, height: 900, channels: 3, background: { r: 120, g: 100, b: 110 } } })
      .png()
      .toBuffer();
    await page.goto("/admin/content?tab=images");
    await page.locator("#file-about").setInputFiles({ name: "about.png", mimeType: "image/png", buffer: png });
    await page.locator("form:has(#file-about)").getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Image uploaded" })).toBeVisible();
    await page.goto("/en");
    await expect(page.locator('main img[src*="/_next/image"]').first()).toBeVisible();
    // A non-image is rejected.
    await page.goto("/admin/content?tab=images");
    await page.locator("#file-contact").setInputFiles({ name: "x.png", mimeType: "image/png", buffer: Buffer.from("not an image") });
    await page.locator("form:has(#file-contact)").getByRole("button", { name: "Save changes" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "Upload a JPEG, PNG or WebP image" })).toBeVisible();
  });

  test("an unverified review cannot be published; a verified one appears", async ({ page }) => {
    await page.goto("/admin/content?tab=reviews");
    const form = page
      .locator("form")
      .filter({ has: page.locator('input[name="authorName"]') })
      .last();
    await form.locator('input[name="authorName"]').fill("A. K.");
    await form.locator('textarea[name="body"]').fill("Very clear explanations and a calm visit.");
    await form.locator('input[name="source"]').fill("In-clinic feedback form");
    await form.getByLabel("Published").check();
    await form.getByRole("button", { name: "Add review" }).click();
    await expect(page.getByRole("alert").filter({ hasText: "Confirm the review is genuine" })).toBeVisible();
    await form.getByLabel("Genuine review, author agreed to publication").check();
    await form.getByRole("button", { name: "Add review" }).click();
    await expect(page.getByRole("status").filter({ hasText: "Review saved" })).toBeVisible();
    await page.goto("/en");
    await expect(page.getByText("Very clear explanations and a calm visit.")).toBeVisible();
    // tidy up
    await sql().query("delete from testimonials");
  });

  test("activity log records changes", async ({ page }) => {
    await page.goto("/admin/audit");
    await expect(page.getByText("settings.updated").first()).toBeVisible();
    await expect(page.getByText("appointment.confirmed").first()).toBeVisible();
  });

  test("notification templates can be edited and restored", async ({ page }) => {
    await page.goto("/admin/notifications");
    await page.locator("summary", { hasText: /^Appointment confirmed$/ }).click();
    const form = page
      .locator("form")
      .filter({ has: page.locator('input[name="event"][value="confirmed"]') })
      .filter({ has: page.locator('input[name="locale"][value="en"]') })
      .filter({ has: page.locator('input[name="channel"][value="email"]') });
    await form.locator('input[name="subject"]').fill("Confirmed: see you soon");
    await form.getByRole("button", { name: "Save changes" }).click();
    await expect(form.getByText("Customised")).toBeVisible();
    await form.getByRole("button", { name: "Restore default" }).click();
    await expect(form.getByText("Default")).toBeVisible();
  });
});
