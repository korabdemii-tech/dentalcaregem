import { test, expect } from "@playwright/test";
import { login, sql } from "./helpers";

test.describe("results gallery", () => {
  test("homepage showcase: drag-to-compare, thumbnails and full-screen viewer", async ({ page }) => {
    await page.goto("/en");
    const showcase = page.locator("#results");
    await expect(showcase.getByRole("heading", { level: 2 })).toHaveText("Real smiles, transformed here");

    // keyboard-operable comparison
    const slider = showcase.getByRole("slider").first();
    await slider.focus();
    await page.keyboard.press("Home");
    await expect(slider).toHaveValue("0");

    // thumbnails switch the featured case
    const first = await showcase.getByRole("heading", { level: 3 }).textContent();
    await showcase.getByRole("button", { name: "Gaps between the front teeth closed" }).click();
    await expect(showcase.getByRole("heading", { level: 3 })).toHaveText("Gaps between the front teeth closed");
    expect(first).not.toBe("Gaps between the front teeth closed");

    // filters
    await showcase.getByRole("button", { name: /Missing teeth/ }).click();
    await expect(showcase.getByRole("listitem")).toHaveCount(2);

    // the hero card jumps to the showcase
    await expect(page.getByRole("link", { name: /See before & after/ })).toHaveAttribute("href", "#results");
  });

  test("results page: filters, viewer keyboard navigation and Escape", async ({ page }) => {
    await page.goto("/en/results");
    await expect(page.locator("article")).toHaveCount(11);
    await page.getByRole("button", { name: /Colour & stains/ }).click();
    await expect(page.locator("article")).toHaveCount(3);
    await page.getByRole("button", { name: /^All/ }).click();
    await expect(page.locator("article")).toHaveCount(11);

    await page.getByRole("button", { name: "View full screen: A full smile again after missing teeth" }).click();
    const dialog = page.getByRole("dialog", { name: "Photo viewer" });
    await expect(dialog).toBeVisible();
    await expect(dialog.getByRole("button", { name: "Close", exact: true })).toBeFocused();
    await expect(dialog.getByText(/^1 of \d+$/)).toBeVisible();
    await page.keyboard.press("ArrowRight");
    await expect(dialog.getByText(/^2 of \d+$/)).toBeVisible();

    // arrows inside the comparison move the divider, not the slide
    const slider = dialog.getByRole("slider");
    await slider.focus();
    await page.keyboard.press("ArrowLeft");
    await expect(dialog.getByText(/^2 of \d+$/)).toBeVisible();
    await expect(slider).toHaveValue("48");

    await page.keyboard.press("Escape");
    await expect(dialog).toBeHidden();
  });

  test("tooth gems and finished smiles are shown with captions", async ({ page }) => {
    await page.goto("/sq/results");
    await expect(page.getByRole("heading", { name: "Gurë dekorues për dhëmbë" })).toBeVisible();
    await expect(page.getByRole("heading", { name: "Buzëqeshje të përfunduara" })).toBeVisible();
    await page.getByRole("button", { name: /formë luleje/ }).click();
    await expect(page.getByRole("dialog")).toBeVisible();
    await expect(page.getByRole("dialog").getByText("Lule")).toBeVisible();
  });

  test("unpublished photos never appear, and the nav link hides when nothing is published", async ({ page }) => {
    const db = sql();
    try {
      await db.query("UPDATE result_cases SET published = false WHERE title->>'en' = 'Chipped front teeth restored'");
      await page.goto("/en/results");
      await expect(page.locator("article")).toHaveCount(10);
      await expect(page.getByText("Chipped front teeth restored")).toHaveCount(0);

      await db.query("UPDATE result_cases SET published = false");
      await db.query("UPDATE gallery_photos SET published = false");
      await page.goto("/en");
      await expect(page.locator("#results")).toHaveCount(0);
      await expect(page.getByRole("navigation", { name: "Main" }).first().getByRole("link", { name: "Results" })).toHaveCount(0);
    } finally {
      await db.query("UPDATE result_cases SET published = true");
      await db.query("UPDATE gallery_photos SET published = true");
    }
  });

  test("the database refuses to publish a gallery photo without consent", async () => {
    const db = sql();
    await expect(
      db.query("UPDATE gallery_photos SET consent_obtained = false WHERE id = (SELECT id FROM gallery_photos LIMIT 1)"),
    ).rejects.toThrow(/gallery_photos_publish_requires_consent/);
  });

  test("admin: a gallery photo can't be published without consent", async ({ page }) => {
    await login(page);
    await page.goto("/admin/content?tab=gallery");
    await page.locator("main details summary").first().click();
    const form = page.locator("main details[open] form");
    await form.getByRole("checkbox", { name: /consent|pëlqimi/i }).uncheck();
    await form
      .getByRole("button", { name: /save|ruaj/i })
      .first()
      .click();
    await expect(form.getByText(/Record the patient's consent|Regjistroni pëlqimin e pacientit/).first()).toBeVisible();
  });
});

test.describe("results gallery on phones @mobile", () => {
  test("results page fits the screen and the filter row scrolls", async ({ page }) => {
    await page.goto("/sq/results");
    const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
    expect(overflow).toBeLessThanOrEqual(1);
    await expect(page.locator("article").first()).toBeVisible();
  });
});
