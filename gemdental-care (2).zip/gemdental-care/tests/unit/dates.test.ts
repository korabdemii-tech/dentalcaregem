import { describe, expect, it } from "vitest";
import { formatClock, formatDateKey, formatInstant, formatMonthYear } from "@/lib/i18n/dates";
import en from "@/lib/i18n/dictionaries/en";
import sq from "@/lib/i18n/dictionaries/sq";

const TZ = "Europe/Belgrade";

describe("browser-safe date formatting", () => {
  it("formats in Albanian without relying on browser locale data", () => {
    expect(formatInstant("2026-10-09T08:15:00Z", TZ, sq.dates)).toBe("e premte, 9 tetor 2026");
    expect(formatDateKey("2026-10-12", sq.dates)).toBe("e hënë, 12 tetor");
    expect(formatMonthYear(2026, 12, sq.dates)).toBe("dhjetor 2026");
  });
  it("formats in English", () => {
    expect(formatInstant("2026-10-09T08:15:00Z", TZ, en.dates)).toBe("Friday 9 October 2026");
    expect(formatDateKey("2026-03-29", en.dates)).toBe("Sunday 29 March");
  });
  it("uses the clinic timezone, not the browser's", () => {
    // 23:30 UTC on the 9th is already the 10th in Belgrade (summer time)
    expect(formatInstant("2026-10-09T23:30:00Z", TZ, en.dates)).toBe("Saturday 10 October 2026");
    expect(formatClock("2026-10-09T23:30:00Z", TZ)).toBe("01:30");
  });
});
