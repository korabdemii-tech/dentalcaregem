import { describe, expect, it } from "vitest";
import { addDays, isValidDateKey, weekdayOf, zonedDateKey, zonedMinutes, zonedToUtc, startOfZonedDay } from "@/lib/time";

const TZ = "Europe/Belgrade";

describe("zonedToUtc", () => {
  it("converts winter wall time (UTC+1)", () => {
    expect(zonedToUtc("2026-01-15", 9 * 60, TZ)?.toISOString()).toBe("2026-01-15T08:00:00.000Z");
  });
  it("converts summer wall time (UTC+2)", () => {
    expect(zonedToUtc("2026-07-15", 9 * 60, TZ)?.toISOString()).toBe("2026-07-15T07:00:00.000Z");
  });
  it("returns null for a time skipped by the spring DST change", () => {
    // 29 March 2026: clocks go from 02:00 to 03:00 in Central Europe
    expect(zonedToUtc("2026-03-29", 2 * 60 + 30, TZ)).toBeNull();
    expect(zonedToUtc("2026-03-29", 3 * 60, TZ)?.toISOString()).toBe("2026-03-29T01:00:00.000Z");
  });
  it("handles the autumn DST change", () => {
    // 25 October 2026: 03:00 → 02:00. 09:00 is UTC+1.
    expect(zonedToUtc("2026-10-25", 9 * 60, TZ)?.toISOString()).toBe("2026-10-25T08:00:00.000Z");
  });
  it("works for other zones", () => {
    expect(zonedToUtc("2026-07-15", 9 * 60, "America/New_York")?.toISOString()).toBe("2026-07-15T13:00:00.000Z");
    expect(zonedToUtc("2026-07-15", 9 * 60, "UTC")?.toISOString()).toBe("2026-07-15T09:00:00.000Z");
  });
});

describe("zoned helpers", () => {
  it("round-trips date keys and minutes", () => {
    const d = zonedToUtc("2026-10-08", 17 * 60 + 45, TZ)!;
    expect(zonedDateKey(d, TZ)).toBe("2026-10-08");
    expect(zonedMinutes(d, TZ)).toBe(17 * 60 + 45);
  });
  it("finds the local start of day", () => {
    expect(startOfZonedDay("2026-10-08", TZ).toISOString()).toBe("2026-10-07T22:00:00.000Z");
  });
  it("adds days across month and year ends", () => {
    expect(addDays("2026-12-31", 1)).toBe("2027-01-01");
    expect(addDays("2028-02-28", 1)).toBe("2028-02-29");
    expect(addDays("2026-03-01", -1)).toBe("2026-02-28");
  });
  it("weekday and validation", () => {
    expect(weekdayOf("2026-10-08")).toBe(4); // Thursday
    expect(isValidDateKey("2026-02-30")).toBe(false);
    expect(isValidDateKey("2026-02-28")).toBe(true);
  });
});
