import { describe, expect, it } from "vitest";
import { computeSlots, type AvailabilityInput } from "@/lib/availability";
import { zonedToUtc } from "@/lib/time";

const TZ = "Europe/Belgrade";
const at = (date: string, hhmm: string) => {
  const [h, m] = hhmm.split(":").map(Number);
  return zonedToUtc(date, h * 60 + m, TZ)!;
};
const times = (slots: { start: Date }[]) =>
  slots.map((s) => new Intl.DateTimeFormat("en-GB", { timeZone: TZ, hour: "2-digit", minute: "2-digit" }).format(s.start));

// Thursday 2026-10-15
const DAY = "2026-10-15";
const base: AvailabilityInput = {
  date: DAY,
  timezone: TZ,
  workingHours: [
    { weekday: 4, startMinute: 9 * 60, endMinute: 12 * 60 },
    { weekday: 4, startMinute: 13 * 60, endMinute: 15 * 60 },
  ],
  durationMinutes: 60,
  bufferMinutes: 0,
  slotIntervalMinutes: 30,
  busy: [],
  exceptions: [],
  now: new Date("2026-10-08T10:00:00Z"),
  minNoticeMinutes: 120,
  horizonDays: 60,
};

describe("computeSlots", () => {
  it("offers slots inside working hours and respects breaks", () => {
    expect(times(computeSlots(base))).toEqual(["09:00", "09:30", "10:00", "10:30", "11:00", "13:00", "13:30", "14:00"]);
  });

  it("returns nothing on a day without working hours", () => {
    expect(computeSlots({ ...base, date: "2026-10-18" })).toEqual([]); // Sunday
  });

  it("removes slots that overlap existing appointments", () => {
    const busy = [{ start: at(DAY, "10:00"), end: at(DAY, "11:00") }];
    expect(times(computeSlots({ ...base, busy }))).toEqual(["09:00", "11:00", "13:00", "13:30", "14:00"]);
  });

  it("applies the service buffer after the new appointment", () => {
    const busy = [{ start: at(DAY, "11:00"), end: at(DAY, "11:30") }];
    // 60 min + 15 min buffer: a 10:00 start would block until 11:15 and collide.
    const slots = computeSlots({ ...base, busy, bufferMinutes: 15 });
    expect(times(slots)).toEqual(["09:00", "09:30", "13:00", "13:30", "14:00"]);
    expect(slots[0].blockedUntil.getTime() - slots[0].end.getTime()).toBe(15 * 60_000);
  });

  it("respects holidays, time off and blocks", () => {
    const exceptions = [{ start: at(DAY, "13:00"), end: at(DAY, "18:00") }];
    expect(times(computeSlots({ ...base, exceptions }))).toEqual(["09:00", "09:30", "10:00", "10:30", "11:00"]);
    const allDay = [{ start: at(DAY, "00:00"), end: at("2026-10-16", "00:00") }];
    expect(computeSlots({ ...base, exceptions: allDay })).toEqual([]);
  });

  it("respects minimum notice", () => {
    const now = at(DAY, "08:30");
    expect(times(computeSlots({ ...base, now, minNoticeMinutes: 120 }))).toEqual(["10:30", "11:00", "13:00", "13:30", "14:00"]);
  });

  it("never offers past times", () => {
    const now = at(DAY, "13:10");
    expect(times(computeSlots({ ...base, now, minNoticeMinutes: 0 }))).toEqual(["13:30", "14:00"]);
  });

  it("respects the booking horizon", () => {
    expect(computeSlots({ ...base, horizonDays: 5 })).toEqual([]);
    expect(computeSlots({ ...base, date: "2026-10-01" })).toEqual([]); // past day
  });

  it("aligns start times to the slot grid", () => {
    const wh = [{ weekday: 4, startMinute: 9 * 60 + 10, endMinute: 11 * 60 }];
    expect(times(computeSlots({ ...base, workingHours: wh }))).toEqual(["09:30", "10:00"]);
  });

  it("skips wall times that don't exist on DST day", () => {
    // Sunday 2026-03-29, imaginary night shift 01:00–05:00
    const input: AvailabilityInput = {
      ...base,
      date: "2026-03-29",
      workingHours: [{ weekday: 0, startMinute: 60, endMinute: 300 }],
      durationMinutes: 30,
      now: new Date("2026-03-20T00:00:00Z"),
    };
    const t = times(computeSlots(input));
    expect(t).not.toContain("02:00");
    expect(t).not.toContain("02:30");
    expect(t).toContain("01:00");
    expect(t).toContain("03:00");
  });
});
