# GemDental Care — website, online booking & clinic dashboard

A bilingual (Albanian / English) website for **GemDental Care** with a real appointment-booking engine and a protected clinic dashboard.

- **Public site** — homepage, treatments (list + detail pages), about, doctor profile, contact, privacy, terms. Luxury-boutique design built on the official plum/champagne identity.
- **Online booking** — a 4–5 step flow (treatment → doctor → date & time → details → review) that only shows times that are genuinely free, re-checks the time on the server, and can never double-book (enforced by PostgreSQL).
- **Clinic dashboard** (`/admin`) — overview, day/week/month calendar, confirm/cancel/move appointments, phone bookings, blocked time, treatments, doctor schedules, website content, notification templates, settings, staff accounts and an activity log.
- **Automatic messages** — booking received, confirmed, reminders, cancelled, moved. Email (Resend), SMS (Twilio) and WhatsApp Business (Meta Cloud API) adapters, delivered through a retrying outbox queue.

> **Status:** the software is complete and tested. It is running with **sample content** until the clinic confirms its treatments, hours, contact details and doctor profile. See [`docs/CLINIC_INFO_NEEDED.md`](docs/CLINIC_INFO_NEEDED.md).

---

## Quick start (local)

Requirements: Node.js 20.9+ (22 recommended), PostgreSQL 14+.

```bash
npm install
cp .env.example .env.local          # then edit DATABASE_URL and APP_SECRET
createdb gemdental                  # or create it in your Postgres tool
npm run db:migrate                  # creates tables + double-booking constraint
npm run db:seed:demo                # sample treatments, demo schedule, demo owner account
npm run db:import-photos            # GemDental's before & after cases and clinic photos
npm run dev                         # http://localhost:3000
```

The demo seed prints the owner login (`owner@gemdental.local`, password from `SEED_ADMIN_PASSWORD` or a random one). Sign in at `http://localhost:3000/admin/login`.

For a real launch use `npm run db:seed` (no demo data, nothing published) and create accounts with:

```bash
npm run admin:create -- --email owner@your-clinic.example --name "Full Name" --role owner
```

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` / `build` / `start` | Next.js development server, production build, production server |
| `npm run db:migrate` | Apply SQL migrations in `drizzle/` |
| `npm run db:seed` | Safe base content: settings, doctor profile shell, **unpublished** example treatments, FAQ drafts |
| `npm run db:seed:demo` | Base content + published sample treatments, demo schedule, demo owner, demo appointments |
| `npm run db:import-photos` | Import the clinic's own photos from `content/photos` (before & after cases, smiles, tooth gems, clinic photos). `-- --draft` imports them unpublished |
| `npm run admin:create -- --email … --name … --role owner\|manager\|staff` | Create or reset a dashboard account (prompts for the password) |
| `npm run worker` | Long-running notification worker (self-hosting). On Vercel the cron endpoints are used instead |
| `npm run maintenance` | Expire sessions, prune rate-limit data, apply the data-retention policy |
| `npm test` | Unit + integration tests (Vitest, needs the `gemdental_test` database) |
| `npm run test:e2e` | End-to-end tests (Playwright) against a production build and the `gemdental_e2e` database |
| `npm run check` / `format` | Type check + formatting |

## Project structure

```
src/
  app/
    [locale]/            public pages (sq, en) — home, services, about, team, contact, booking, legal
    admin/               dashboard (login, (app)/… pages, server actions)
    api/booking/…        availability, slots, session token, create booking
    api/cron/…           notifications + maintenance jobs (Bearer CRON_SECRET)
    media/[id]           clinic photos stored in Postgres
    sitemap.ts robots.ts icon.svg apple-icon.png
  components/            site/, booking/, admin/, brand/
  lib/
    availability.ts      pure slot engine (schedule, breaks, buffers, notice, horizon, DST)
    booking/             DB-backed availability, create (transaction + locks), manage (confirm/cancel/move)
    notifications/       templates, providers (Resend/Twilio/Meta), outbox queue + reminders
    auth/                Argon2id passwords, DB sessions, role permissions
    security/            rate limiting, signed tokens, same-origin checks, Turnstile
    i18n/                dictionaries (public + dashboard, sq + en), date names, legal drafts
    db/schema.ts         Drizzle schema
drizzle/                 SQL migrations (0001 adds the no-overlap exclusion constraint)
scripts/                 migrate, seed, create-admin, worker, maintenance
tests/unit|integration|e2e
docs/                    deployment, integrations, admin guide, brand, security, testing, open items
```

## Documentation

- [Deployment guide](docs/DEPLOYMENT.md) — hosting, database, environment, cron, backups
- [Integrations](docs/INTEGRATIONS.md) — email, SMS, WhatsApp, bot protection
- [Admin guide](docs/ADMIN_GUIDE.md) — for clinic staff
- [Brand & design system](docs/BRAND.md)
- [Security & privacy](docs/SECURITY_PRIVACY.md)
- [Testing](docs/TESTING.md) — what is tested and how
- [Clinic information still needed](docs/CLINIC_INFO_NEEDED.md)
- [Known limitations](docs/KNOWN_LIMITATIONS.md)

## Stack

Next.js 16 (App Router, TypeScript) · React 19 · Tailwind CSS 4 with CSS-variable design tokens · PostgreSQL + Drizzle ORM · Argon2id · Zod · libphonenumber-js · sharp · Vitest · Playwright + axe-core. No UI framework, animation library or analytics; self-hosted fonts (Jost, Cormorant Garamond).
