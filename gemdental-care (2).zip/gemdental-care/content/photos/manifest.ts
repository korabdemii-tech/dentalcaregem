/**
 * GemDental's own photographs, supplied by the clinic for the website
 * (October 2026). Before/after collages were split into aligned pairs so they
 * work with the drag-to-compare slider; nothing in the pictures was retouched.
 *
 * Titles describe what is visible in the photos only. They deliberately do not
 * name a specific procedure; the clinic can add that in the dashboard.
 *
 * Imported with `npm run db:import-photos`. See docs/ADMIN_GUIDE.md.
 */
import type { Localized } from "@/lib/i18n/config";
import type { GalleryKind, ResultConcern } from "@/lib/db/schema";

type Alt = Localized;

export type CasePhoto = {
  key: string;
  concern: ResultConcern;
  title: Localized;
  beforeAlt: Alt;
  afterAlt: Alt;
};

export const CASE_DESCRIPTION: Localized = {
  en: "Treated at GemDental Care. Photos shared with the patient’s consent; results differ from person to person.",
  sq: "Trajtuar në GemDental Care. Fotografitë publikohen me pëlqimin e pacientit; rezultatet ndryshojnë nga personi te personi.",
};

export const CASES: CasePhoto[] = [
  {
    key: "case-full-arch",
    concern: "missing",
    title: { en: "A full smile again after missing teeth", sq: "Sërish buzëqeshje e plotë pas dhëmbëve që mungonin" },
    beforeAlt: { en: "Before: smile with several missing front teeth", sq: "Para: buzëqeshje me disa dhëmbë të përparmë që mungojnë" },
    afterAlt: { en: "After: a complete, even row of teeth", sq: "Pas: një rresht i plotë dhe i rregullt dhëmbësh" },
  },
  {
    key: "case-gaps-smile",
    concern: "spacing",
    title: { en: "Gaps between the front teeth closed", sq: "Hapësirat mes dhëmbëve të përparmë, të mbyllura" },
    beforeAlt: { en: "Before: wide gaps between the upper front teeth", sq: "Para: hapësira të gjera mes dhëmbëve të sipërm të përparmë" },
    afterAlt: { en: "After: an even, closed smile line", sq: "Pas: vijë e buzëqeshjes e rregullt, pa hapësira" },
  },
  {
    key: "case-stains",
    concern: "colour",
    title: { en: "From heavy staining to a bright, even smile", sq: "Nga njollat e rënda te një buzëqeshje e ndritshme" },
    beforeAlt: { en: "Before: heavily stained, uneven teeth", sq: "Para: dhëmbë me njolla të rënda dhe të parregullt" },
    afterAlt: { en: "After: bright, evenly shaped teeth", sq: "Pas: dhëmbë të ndritshëm me formë të rregullt" },
  },
  {
    key: "case-yellow-crowded",
    concern: "colour",
    title: { en: "Yellow, uneven teeth to a clean, even smile", sq: "Nga dhëmbët e verdhë e të parregullt te një buzëqeshje e rregullt" },
    beforeAlt: { en: "Before: yellowed, uneven teeth", sq: "Para: dhëmbë të zverdhur dhe të parregullt" },
    afterAlt: { en: "After: white, evenly aligned teeth", sq: "Pas: dhëmbë të bardhë dhe të rreshtuar" },
  },
  {
    key: "case-crowns-front",
    concern: "shape",
    title: { en: "Worn, uneven front teeth rebuilt", sq: "Dhëmbët e përparmë të konsumuar, të rindërtuar" },
    beforeAlt: {
      en: "Before: worn, uneven upper front teeth with a gap",
      sq: "Para: dhëmbë të sipërm të përparmë të konsumuar, me hapësirë",
    },
    afterAlt: {
      en: "After: upper front teeth restored in a natural shade",
      sq: "Pas: dhëmbët e sipërm të përparmë të restauruar në ngjyrë natyrale",
    },
  },
  {
    key: "case-chipped-front",
    concern: "shape",
    title: { en: "Chipped front teeth restored", sq: "Dhëmbët e përparmë të thyer, të restauruar" },
    beforeAlt: { en: "Before: chipped and broken front teeth", sq: "Para: dhëmbë të përparmë të ciflosur dhe të thyer" },
    afterAlt: { en: "After: complete, even front teeth", sq: "Pas: dhëmbë të përparmë të plotë dhe të rregullt" },
  },
  {
    key: "case-yellow-smile",
    concern: "colour",
    title: { en: "A brighter, more even smile", sq: "Një buzëqeshje më e ndritshme dhe më e rregullt" },
    beforeAlt: { en: "Before: yellowed, uneven front teeth", sq: "Para: dhëmbë të përparmë të zverdhur dhe të parregullt" },
    afterAlt: { en: "After: white, even front teeth", sq: "Pas: dhëmbë të përparmë të bardhë dhe të rregullt" },
  },
  {
    key: "case-worn-smile",
    concern: "shape",
    title: { en: "Worn, darkened teeth to a fresh smile", sq: "Nga dhëmbët e konsumuar te një buzëqeshje e freskët" },
    beforeAlt: { en: "Before: worn, darkened teeth with gaps", sq: "Para: dhëmbë të konsumuar dhe të errësuar, me hapësira" },
    afterAlt: { en: "After: a fresh, even smile", sq: "Pas: një buzëqeshje e freskët dhe e rregullt" },
  },
  {
    key: "case-uneven-arch",
    concern: "shape",
    title: { en: "Uneven teeth to a harmonious arch", sq: "Nga dhëmbët e parregullt te një hark harmonik" },
    beforeAlt: { en: "Before: uneven, worn teeth", sq: "Para: dhëmbë të parregullt dhe të konsumuar" },
    afterAlt: { en: "After: a harmonious, even arch", sq: "Pas: një hark harmonik dhe i rregullt" },
  },
  {
    key: "case-missing-side",
    concern: "missing",
    title: { en: "A complete smile after missing and damaged teeth", sq: "Buzëqeshje e plotë pas dhëmbëve që mungonin dhe të dëmtuar" },
    beforeAlt: { en: "Before: missing and damaged teeth", sq: "Para: dhëmbë që mungojnë dhe të dëmtuar" },
    afterAlt: { en: "After: a complete, even row of teeth", sq: "Pas: një rresht i plotë dhe i rregullt dhëmbësh" },
  },
  {
    key: "case-crowding",
    concern: "spacing",
    title: { en: "Crowded, gappy teeth to an even arch", sq: "Nga dhëmbët e shtrembër e me hapësira te një hark i rregullt" },
    beforeAlt: { en: "Before: crowded teeth with gaps", sq: "Para: dhëmbë të shtrembër me hapësira" },
    afterAlt: { en: "After: an even, complete arch", sq: "Pas: një hark i plotë dhe i rregullt" },
  },
];

export type GalleryPhoto = { key: string; kind: GalleryKind; caption: Localized; alt: Alt };

export const GALLERY: GalleryPhoto[] = [
  {
    key: "smile-gem",
    kind: "smile",
    caption: { en: "A finished smile, with a small decorative gem", sq: "Buzëqeshje e përfunduar, me një gur të vogël dekorues" },
    alt: {
      en: "Close-up of a bright smile with a small gem on one tooth",
      sq: "Buzëqeshje e ndritshme nga afër, me një gur të vogël në një dhëmb",
    },
  },
  {
    key: "smile-full-arch",
    kind: "smile",
    caption: { en: "A complete, even smile", sq: "Një buzëqeshje e plotë dhe e rregullt" },
    alt: { en: "Close-up of a man smiling with a full, even row of teeth", sq: "Burrë që buzëqesh nga afër, me rresht të plotë dhëmbësh" },
  },
  {
    key: "smile-front",
    kind: "smile",
    caption: { en: "Natural-looking front teeth", sq: "Dhëmbë të përparmë me pamje natyrale" },
    alt: {
      en: "Close-up of a bearded man smiling with natural-looking front teeth",
      sq: "Burrë me mjekër që buzëqesh, me dhëmbë të përparmë natyralë",
    },
  },
  {
    key: "gem-triangle",
    kind: "gems",
    caption: { en: "Triangle", sq: "Trekëndësh" },
    alt: { en: "A small triangle-shaped gem on a front tooth", sq: "Gur i vogël në formë trekëndëshi mbi një dhëmb të përparmë" },
  },
  {
    key: "gem-flower",
    kind: "gems",
    caption: { en: "Flower", sq: "Lule" },
    alt: { en: "A small flower-shaped gem on a front tooth", sq: "Gur i vogël në formë luleje mbi një dhëmb të përparmë" },
  },
  {
    key: "gem-butterfly",
    kind: "gems",
    caption: { en: "Butterfly", sq: "Flutur" },
    alt: { en: "A small butterfly-shaped gem on a front tooth", sq: "Gur i vogël në formë fluture mbi një dhëmb të përparmë" },
  },
];

export const SITE_PHOTOS: { key: string; slots: ("about" | "about-secondary" | "contact")[]; alt: Alt }[] = [
  {
    key: "clinic-scanner",
    slots: ["about", "contact"],
    alt: {
      en: "Inside GemDental Care: a dentist at work beside the treatment chair",
      sq: "Brenda GemDental Care: dentisti në punë pranë karriges së trajtimit",
    },
  },
  {
    key: "clinic-treatment",
    slots: ["about-secondary"],
    alt: {
      en: "A dentist and an assistant treating a patient at GemDental Care",
      sq: "Dentisti dhe asistentja duke trajtuar një pacient në GemDental Care",
    },
  },
];
