-- Double-booking protection enforced by PostgreSQL itself.
-- Two active appointments for the same doctor can never overlap in time,
-- regardless of how many requests arrive at once.
CREATE EXTENSION IF NOT EXISTS btree_gist;
--> statement-breakpoint
ALTER TABLE "appointments"
  ADD CONSTRAINT "appointments_no_overlap"
  EXCLUDE USING gist (
    "doctor_id" WITH =,
    tstzrange("starts_at", "blocked_until", '[)') WITH &&
  ) WHERE ("status" IN ('pending', 'confirmed', 'reschedule_requested'));
--> statement-breakpoint
ALTER TABLE "appointments" ADD CONSTRAINT "appointments_time_order" CHECK ("starts_at" < "ends_at" AND "ends_at" <= "blocked_until");
--> statement-breakpoint
ALTER TABLE "availability_exceptions" ADD CONSTRAINT "availability_exceptions_time_order" CHECK ("starts_at" < "ends_at");
--> statement-breakpoint
ALTER TABLE "working_hours" ADD CONSTRAINT "working_hours_valid" CHECK ("weekday" BETWEEN 0 AND 6 AND "start_minute" >= 0 AND "end_minute" <= 1440 AND "start_minute" < "end_minute");
--> statement-breakpoint
ALTER TABLE "services" ADD CONSTRAINT "services_publish_requires_confirmation" CHECK (NOT "published" OR "confirmed");
--> statement-breakpoint
ALTER TABLE "faqs" ADD CONSTRAINT "faqs_publish_requires_verification" CHECK (NOT "published" OR "verified");
--> statement-breakpoint
ALTER TABLE "testimonials" ADD CONSTRAINT "testimonials_publish_requires_verification" CHECK (NOT "published" OR "verified");
--> statement-breakpoint
ALTER TABLE "result_cases" ADD CONSTRAINT "result_cases_publish_requires_consent" CHECK (NOT "published" OR ("consent_obtained" AND "before_media_id" IS NOT NULL AND "after_media_id" IS NOT NULL));
--> statement-breakpoint
ALTER TABLE "clinic_settings" ADD CONSTRAINT "clinic_settings_singleton" CHECK ("id" = 1);
