CREATE TABLE "gallery_photos" (
	"id" uuid PRIMARY KEY DEFAULT gen_random_uuid() NOT NULL,
	"media_id" uuid NOT NULL,
	"kind" text DEFAULT 'smile' NOT NULL,
	"caption" jsonb DEFAULT '{}'::jsonb NOT NULL,
	"consent_obtained" boolean DEFAULT false NOT NULL,
	"consent_date" text,
	"consent_reference" text,
	"approved_by" text,
	"published" boolean DEFAULT false NOT NULL,
	"sort_order" integer DEFAULT 0 NOT NULL,
	"created_at" timestamp with time zone DEFAULT now() NOT NULL
);
--> statement-breakpoint
ALTER TABLE "result_cases" ADD COLUMN "concern" text;--> statement-breakpoint
ALTER TABLE "gallery_photos" ADD CONSTRAINT "gallery_photos_media_id_media_id_fk" FOREIGN KEY ("media_id") REFERENCES "public"."media"("id") ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE "gallery_photos" ADD CONSTRAINT "gallery_photos_kind_check" CHECK ("kind" IN ('smile', 'gems'));--> statement-breakpoint
ALTER TABLE "gallery_photos" ADD CONSTRAINT "gallery_photos_publish_requires_consent" CHECK (NOT "published" OR "consent_obtained");--> statement-breakpoint
ALTER TABLE "result_cases" ADD CONSTRAINT "result_cases_concern_check" CHECK ("concern" IS NULL OR "concern" IN ('missing', 'spacing', 'colour', 'shape'));--> statement-breakpoint
CREATE INDEX "gallery_photos_published_idx" ON "gallery_photos" ("published", "sort_order");
