# Brand & design system

## Logo

Source: the supplied brand board (screenshot). The lockup and mark were **vector-traced** from it for development, so they are crisp at any size and the wordmark is unchanged — but they are a trace, not the master files.

**Action for launch:** send the original vector logo (SVG/AI/EPS/PDF) and replace these files with identical names:

| File | Use |
|---|---|
| `public/brand/gemdental-logo-plum.svg` | header on light backgrounds |
| `public/brand/gemdental-logo-white.svg` | footer, dashboard, plum surfaces |
| `public/brand/gemdental-mark-plum.svg` / `-white.svg` | tooth-and-diamond mark |
| `public/brand/gemdental-mark-outline-champagne.svg` / `-plum.svg` | hairline outline used as the oversized background device (as on the brand board) |
| `src/app/icon.svg`, `src/app/apple-icon.png`, `public/brand/og-default.png` | favicon, home-screen icon, social preview |

Rules applied: logo never redrawn, recoloured only to the brand's white or plum, never stretched (aspect ratio fixed in `components/brand/Logo.tsx`).

## Colour tokens (`src/app/globals.css`)

Plum and champagne were sampled from the logo artwork (they differ slightly from the brief's provisional values).

| Token | Hex | Use |
|---|---|---|
| `--gd-plum` | `#4F3F4A` | primary brand colour, headlines, primary buttons (9.3:1 on ivory) |
| `--gd-plum-deep` | `#382A35` | body text, footer, dashboard sidebar |
| `--gd-champagne` | `#DFCBAF` | accents, lines, buttons on plum (6.2:1 text on plum) |
| `--gd-champagne-soft` | `#EFE4D5` | tints |
| `--gd-champagne-ink` | `#7A5C3B` | champagne-toned text on light surfaces (≥4.9:1) |
| `--gd-mauve` | `#887580` | decorative only (4.0:1, not for small text) |
| `--gd-mauve-light` | `#C9B8C2` | text on plum (5.2:1) |
| `--gd-ivory` | `#FAF8F6` | page background |
| `--gd-cream` | `#F3EEEB` | alternate sections |
| `--gd-ink-muted` | `#6E5D68` | secondary text (5.8:1) |

Distribution follows the brief: mostly ivory/white, plum for brand moments (hero placeholder, final call to action, footer), champagne as the accent.

## Typography

- **Jost** (variable, self-hosted) — UI and body. A geometric sans in the Futura family, chosen to echo the GemDental wordmark.
- **Cormorant Garamond** 500/600 (self-hosted) — editorial display headings only. Never used for forms, medical information or small text.
- Fluid type scale: `text-xs` … `text-4xl` defined with `clamp()` in `@theme`.

## Motifs

- **The facet**: one clipped top-right corner on images and cards, taken from the diamond in the mark (`.facet`, `.facet-lg`).
- **The outline**: the oversized hairline outline of the mark from the brand board, behind the hero, page headers and the final call to action.
- **Diamond markers** for steps and list points instead of generic bullets.

## Hero animation

The homepage hero shows a looping 3D tooth with a transparent background (`components/site/HeroTooth.tsx`). Browsers can't play transparent MP4s, and transparent WebM doesn't work on iPhone, so the files in `public/hero/` are "stacked": colour on top, the transparency mask (as grey) below, combined in the browser by a small WebGL shader. It pauses when scrolled out of view, and visitors who prefer reduced motion see the still `tooth-poster.webp` instead.

| File | Use |
|---|---|
| `public/hero/tooth-stacked.mp4` | H.264, 600×1440, 10 s loop (Safari, iPhone, Chrome, Edge) |
| `public/hero/tooth-stacked.webm` | VP9 fallback for browsers without H.264 |
| `public/hero/tooth-poster.webp` | transparent still: loading state, reduced motion, no WebGL |

Made from the supplied green-screen clip: colour key for the green part, AI cut-out for the grey studio part, edges cleaned of background colour, soft fade at the left/right crop edges and a short fade at the end so the loop restarts cleanly. To use a different clip, produce the same stacked layout (colour above, alpha below) and replace the files.

## Motion & interaction

- Homepage hero entrance (text rise + looping tooth), and a floating glass card with a tiny looping before/after wipe that jumps to the results.
- **Scroll reveals** — sections rise, fade, zoom or unveil as they enter the screen (`data-reveal`, `data-reveal="fade|zoom|unveil"`, stagger with `style="--i: n"`).
- **Pointer effects** (mouse only) — a champagne light follows the cursor across cards (`data-spotlight`), photos tilt slightly toward it (`data-tilt`), and the About photos move in layers (`data-parallax` + `data-depth`). One delegated listener in `src/lib/interactions`.
- **Before & after** — drag (mouse, finger or pen), click to jump, or use the keyboard (it is a real slider for screen readers). On the Results page the divider follows the mouse. The homepage case sweeps once when first seen to show it can be dragged.
- **Full-screen viewer** — native `<dialog>`: arrow keys, swipe on photos, thumbnails, Escape to close, focus kept inside.
- Tooth gems have a magnifying loupe; the smiles strip drifts endlessly and pauses on hover; hovering a smile shows its "before".
- A thin reading-progress line under the header (CSS scroll-driven animation), and a light sweep across primary buttons.
- Page changes cross-fade via React `<ViewTransition>`.

Content is never hidden without JavaScript, and under `prefers-reduced-motion` nothing moves: reveals are off, the strip becomes a normal scrollable row, and the comparison doesn't sweep.

## Components

Buttons (`.btn-primary`, `-secondary`, `-champagne`, `-ghost-light`, `-danger`, `.btn-sm`), inputs (`.input`, `.checkbox`, `.field-label/hint/error`), links (`.link-underline`, `.link-quiet`), layout (`.container-gd`, `.section-y`, `.measure`). Component classes live in `@layer components`, so Tailwind utilities can always override them.

## Photography

The clinic's own photos (October 2026) are in `content/photos` and imported with `npm run db:import-photos`: before & after collages were split into aligned pairs for the comparison slider (no retouching), plus finished smiles, tooth-gem close-ups and two clinic photos (About and Contact image slots). Positions still without a photo, such as the doctor's portrait, show a labelled, on-brand placeholder ("Clinic photography to be supplied"). Upload authentic photos in the dashboard (Website content → Images, and per treatment/doctor). Recommended: warm natural light, consistent colour grading, interiors and equipment, real team portraits. Never stock or AI images presented as GemDental patients or staff.
