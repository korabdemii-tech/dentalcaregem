# Clinic information still needed

Everything below shows as **"To be confirmed"** or is unpublished on the site. None of it was invented. Each item can be entered in the dashboard unless noted.

## Brand
- [ ] Original vector logo files (SVG/AI/EPS/PDF) to replace the traced development version — *send to the developer*.
- [ ] Authentic photography: clinic interior/exterior, treatment rooms, equipment, team portraits (Website content → Images; Treatments; Doctors).

## Contact & location (Clinic settings)
- [ ] Phone number, WhatsApp number, email address
- [ ] Street address, city, postal code, country code, map link (or coordinates)
- [ ] Opening hours shown on the website
- [ ] Social media links
- [ ] Legal entity name and privacy contact email (used in the privacy policy)

## Booking rules (Clinic settings)
- [ ] Confirm automatically or approve each request? (currently: approve)
- [ ] Minimum notice (currently 2 h), how far ahead (60 days), start-time grid (15 min)
- [ ] Confirm the timezone (currently Europe/Belgrade, which also covers Kosovo)
- [ ] Reminder timing (currently 24 h before; 2 h available)

## Doctor (Doctors & schedules)
- [ ] Dr. Genc Bejtullahu: professional title, biography, education, areas of focus, experience, languages, qualifications/memberships, portrait — only as supplied and verified
- [ ] Real weekly schedule (the demo uses Mon–Fri 09:00–13:00 & 14:00–18:00, Sat 09:00–13:00)
- [ ] Holidays / planned closures (Block time)
- [ ] Any other dentists or hygienists

## Treatments (Treatments)
For each example treatment: does the clinic offer it? Then confirm the wording, duration, buffer, whether to show a price, and tick *Confirmed* → *Published*. Examples seeded: consultation, check-up, professional cleaning, whitening, implants, crowns & bridges, veneers, orthodontics, root canal treatment, emergency consultation (+ drafts: general dentistry, cosmetic dentistry).

## Website copy
- [ ] Approve the brand copy on the homepage and About page (approach, "what a visit feels like")
- [ ] FAQ answers for rescheduling/cancellation, payments, location/parking, emergencies (drafts exist, unpublished)
- [ ] Review all Albanian text with a native speaker
- [ ] Clinic history/facilities for the About page

## Legal
- [ ] Privacy policy and booking terms are **drafts** — review with legal advice for the clinic's jurisdiction (cancellation policy, late/no-show fees, data processors, retention)
- [ ] Confirm consent forms for before/after photos and testimonials before publishing any
- [ ] **Supplied photos (October 2026):** 11 before & after cases, 3 finished smiles, 3 tooth-gem close-ups and 2 clinic photos are published. For each, add the signed consent reference in Dashboard → Website content (Before & after / Smiles & gems), or unpublish it. The staff in the clinic photos should also agree to appear on the website
- [ ] Two supplied photos were deliberately **not** used: the photo of a young child in the chair (a minor; use only with a parent's written consent), and the gap close-up collage whose two halves look the same (please say which is before and which is after)
- [ ] Optional: name the treatment for each case (e.g. veneers, crowns, implants) — titles currently describe only what is visible

## Accounts & integrations
- [ ] Domain name; hosting choice (DEPLOYMENT.md)
- [ ] Email provider (Resend) with a verified sending domain
- [ ] Optional: Twilio (SMS), WhatsApp Business (Meta) with approved templates, Cloudflare Turnstile
- [ ] Staff who need dashboard accounts and their roles
- [ ] Genuine reviews the clinic has permission to publish (optional)
