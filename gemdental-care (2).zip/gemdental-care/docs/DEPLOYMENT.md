# Deployment guide

The app is a standard Next.js server plus PostgreSQL. Two proven setups:

| | **A. Vercel + managed Postgres** | **B. Your own server (VPS)** |
|---|---|---|
| Web app | Vercel project | Node 22 + `npm start` behind Nginx/Caddy |
| Database | Neon, Supabase, AWS RDS, … (PostgreSQL 14+) | PostgreSQL on the same or another server |
| Scheduled jobs | `vercel.json` crons (included) | `npm run worker` (systemd/pm2) + daily `npm run maintenance` |
| HTTPS | automatic | Let's Encrypt via Caddy/Certbot |

Choose a database region close to the clinic and the web app (for GDPR-style requirements prefer an EU region; confirm what applies to the clinic, see SECURITY_PRIVACY.md).

## 1. Database

1. Create an empty PostgreSQL 14+ database and a role that owns it.
2. The first migration runs `CREATE EXTENSION IF NOT EXISTS btree_gist`. On managed providers this extension is available; if your role cannot create extensions, run that line once as an admin.
3. Apply migrations from your machine or CI:
   ```bash
   DATABASE_URL="postgres://…?sslmode=require" npm run db:migrate
   DATABASE_URL="…" npm run db:seed          # safe base content, nothing published
   DATABASE_URL="…" npm run db:import-photos # GemDental's own photos: results gallery + clinic photos
   DATABASE_URL="…" npm run admin:create -- --email owner@clinic.example --name "Owner Name" --role owner
   ```
   Re-run `npm run db:migrate` on every deploy that adds migrations (it is idempotent). `db:import-photos` is safe to re-run too; add `-- --draft` to import the photos unpublished.

## 2. Environment variables

Copy `.env.example` and fill in values in your host's settings. Required in production:

| Variable | Notes |
|---|---|
| `SITE_URL` | `https://www.your-domain` — used for canonical URLs, sitemap, links in messages |
| `DATABASE_URL` | include `?sslmode=require` for managed databases |
| `APP_SECRET` | ≥32 random characters: `openssl rand -base64 48` |
| `CRON_SECRET` | random string; Vercel sends it automatically to cron routes |
| `LOCALES` | `sq,en` — first one is the launch language |
| `EMAIL_PROVIDER` + `RESEND_API_KEY` + `EMAIL_FROM` | see INTEGRATIONS.md. Until set, use `none` (messages are recorded as "not sent") |
| `SMS_PROVIDER`, `WHATSAPP_PROVIDER` + credentials | optional |
| `NEXT_PUBLIC_TURNSTILE_SITE_KEY`, `TURNSTILE_SECRET_KEY` | recommended bot protection |

Never set `EMAIL_PROVIDER=log` in production: it writes message content to server logs.

## 3A. Vercel

1. Import the repository in Vercel (framework: Next.js). Build command `npm run build`.
2. Add the environment variables above for Production (and Preview with a separate database).
3. Deploy. `vercel.json` registers two cron jobs:
   - `/api/cron/notifications` every 5 minutes — queues due reminders and delivers messages. *Vercel Hobby only allows daily crons; use Pro, or call this URL every 5 minutes from any external scheduler with `Authorization: Bearer $CRON_SECRET`.*
   - `/api/cron/maintenance` daily.
4. Add your domain; HTTPS is automatic. Vercel sets `x-real-ip`/`x-forwarded-for` correctly, which the rate limiter relies on.

## 3B. Own server

```bash
npm ci && npm run build
npm run db:migrate
PORT=3000 npm start                   # run under systemd or pm2
npm run worker                        # second long-running process
# cron: 17 3 * * *  cd /srv/gemdental && npm run maintenance
```

Nginx in front (must overwrite client-supplied IP headers):

```nginx
server {
  listen 443 ssl http2;
  server_name www.your-domain;
  client_max_body_size 10m;            # photo uploads (8 MB limit in the app)
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_set_header X-Forwarded-Host $host;
  }
}
```

If the app is reachable without this proxy, clients could spoof their IP and weaken rate limiting.

## 4. After the first deploy

1. Sign in at `/admin/login` with the owner account; create staff accounts under **Staff accounts**.
2. **Clinic settings**: phone, WhatsApp, email, address, country code, opening hours, timezone, booking policy (auto-confirm or approval), privacy contact.
3. **Doctors & schedules**: verify Dr. Genc Bejtullahu's profile and set the real weekly schedule.
4. **Treatments**: review each one, set durations, tick *Confirmed by the clinic*, then *Published*.
5. **Website content**: upload authentic photos; verify FAQ answers.
6. Make a real test booking and check the email arrives. Then turn off the preview ribbon (Settings → Website).
7. Submit `https://your-domain/sitemap.xml` in Google Search Console and create/verify the Google Business Profile with the same name, address and phone.

## 5. Backups

- Managed Postgres: enable daily automated backups with point-in-time recovery (Neon/Supabase/RDS all support it); keep at least 7–30 days.
- Own server: nightly `pg_dump -Fc gemdental > /backups/gemdental-$(date +%F).dump`, encrypt, copy off-site, keep 30 days, and **test a restore** each quarter: `pg_restore -d gemdental_restore file.dump`.
- Photos are stored in the database, so a database backup contains everything.

## Content Security Policy

`next.config.ts` sends a strict CSP (no third-party scripts except optional Turnstile, `frame-ancestors 'none'`). Scripts allow `'unsafe-inline'` because Next.js injects inline bootstrap code; to tighten further, switch to nonce-based CSP via `proxy.ts` (see the Next.js "Content Security Policy" guide).
