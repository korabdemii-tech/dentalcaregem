# Security & privacy

## Booking integrity

- **No double booking.** PostgreSQL exclusion constraint `appointments_no_overlap` (`btree_gist`): two active appointments (pending, confirmed, needs-rescheduling) for the same doctor can never overlap, including the buffer time. On top of that, bookings for a doctor are serialised with a transaction-scoped advisory lock and the slot is re-validated against live data inside the transaction. Tested with 25 simultaneous requests for one slot: exactly one succeeds.
- **Idempotency.** Each booking attempt carries a client-generated key (unique in the database). Retries or double-clicks return the original appointment.
- **Authoritative status.** The server decides *confirmed* vs *pending* from clinic settings; the browser only displays what the server returned.

## Public endpoints

- Server-side validation of every field (Zod; phone numbers via libphonenumber).
- Same-origin check on `POST /api/booking` (CSRF), JSON content-type required, 20 KB body limit.
- Bot protection: honeypot, signed session token (min 2 s, max 45 min), optional Cloudflare Turnstile.
- Postgres-backed rate limits (work across server instances). IPs are stored only as keyed hashes.
- Security headers: CSP, `X-Frame-Options: DENY`, `nosniff`, strict referrer policy, permissions policy, HSTS in production, no `X-Powered-By`.

## Dashboard

- Passwords hashed with **Argon2id** (OWASP parameters); 12+ characters with letters and numbers/symbols.
- Database-backed sessions: random 256-bit token in an HttpOnly, SameSite=Lax (Secure in production) cookie; only its SHA-256 hash is stored. 12 h sliding expiry; password changes and deactivation end all sessions.
- Login: per-IP rate limit, account lock after 5 failures, timing-equalised responses for unknown emails, generic error text.
- Every page and server action re-checks the session **and role permission on the server** (`requireUser(permission)`); hiding menu items is only cosmetic. Server Actions additionally get Next.js's built-in Origin check.
- `/admin` is `noindex`, `no-store`, and excluded in robots.txt.
- Activity log of all changes without personal data in the log entries.
- Uploads: decoded and re-encoded with sharp (rejects non-images regardless of the claimed type), EXIF/GPS stripped, max 8 MB, served with `nosniff` and a sandbox CSP.

## Data minimisation & retention

- The booking form asks only for name, phone, email, optional note and optional "first visit?" — no medical history (the note field says so).
- Nothing personal is stored in the browser (no localStorage/sessionStorage of patient data). Cookies: language preference and the staff session only — no analytics or tracking.
- Message bodies are cleared 90 days after sending.
- Patients with no appointment in the retention period (default 36 months, configurable) are anonymised by the daily maintenance job. Owners can erase a patient on request.
- Logs never contain full contact details (recipients are masked).

## Jurisdiction — to confirm

Which law applies depends on where the clinic and its patients are. If the clinic is in Kosovo, the Law on Protection of Personal Data (Law No. 06/L-082, modelled on the GDPR) and health-records rules are likely relevant; for patients in the EU the GDPR may apply. **This has not been verified** — the clinic should confirm with a lawyer, then finalise the privacy policy and terms (currently clearly marked drafts on the website), the retention period, and the hosting region. Also decide whether a data processing agreement is needed with each provider (hosting, database, Resend, Twilio, Meta).

## Operational checklist

- HTTPS only (automatic on Vercel; Caddy/Certbot on a VPS).
- Secrets only in the host's environment settings; `.env*` files are git-ignored.
- Rotate `APP_SECRET` if leaked (invalidates in-flight booking sessions only). Rotate provider keys at the provider.
- Daily backups with tested restores (DEPLOYMENT.md).
- Keep dependencies updated (`npm audit`, Dependabot).
