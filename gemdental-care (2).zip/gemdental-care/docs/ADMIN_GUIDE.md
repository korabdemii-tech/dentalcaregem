# Clinic dashboard — staff guide

Sign in at **your-domain/admin**. The dashboard is available in Albanian and English (switch at the bottom of the menu). Your session lasts 12 hours of activity; after 5 wrong passwords an account is locked for 15 minutes.

## Roles

| | Staff | Manager | Owner |
|---|:-:|:-:|:-:|
| Appointments, calendar, phone bookings, block time | ✓ | ✓ | ✓ |
| Treatments, doctors & schedules, website content, notifications, clinic settings, activity log | | ✓ | ✓ |
| Staff accounts, erase patient data | | | ✓ |

## Daily work

**Overview** shows today's appointments, requests waiting for approval, upcoming and confirmed counts, cancellations in the last 30 days and open slots today. A red banner appears if any message failed to send.

**Requests.** When "Confirm online bookings automatically" is off (Settings), online bookings arrive as *Pending*. The time is held for the patient. Open the request and choose **Confirm appointment** — the patient receives the confirmation automatically. If the time doesn't work, use **Move appointment** (the patient is told the new time) or **Cancel appointment**.

**Statuses.** Pending → Confirmed → Completed / No-show. *Needs rescheduling* marks an appointment you still have to arrange. Cancelled appointments free the time immediately.

**Phone or walk-in bookings.** *New appointment*: patient name, phone (with country code), email, treatment, doctor, date and time. Tick *Allow outside regular hours* only when you deliberately book outside the schedule; overlapping another appointment is always refused. Untick *Send the patient a message* if you don't want an automatic email.

**Calendar.** Day, week and month views. Click an appointment to open it; click an empty half-hour in day/week view to start a booking at that time. Hatched areas are blocked time.

**Block time.** Holidays, clinic closures, time off or one-off blocks, for one doctor or the whole clinic. Online booking stops offering those times. Existing appointments inside the period are *not* cancelled — the confirmation message tells you how many there are so you can contact those patients.

## Setup (managers/owners)

- **Clinic settings** — contact details, address, map link, opening hours shown on the website, social links, booking rules (auto-confirm, minimum notice, how far ahead, start-time grid), timezone, privacy contact and data-retention period, and the website "preview" ribbon.
- **Doctors & schedules** — profile (bio, education, areas of focus, languages, qualifications, portrait) in both languages, and the weekly schedule. Two time ranges on one day create a break. Only publish credentials the doctor has supplied.
- **Treatments** — name, summary and description in both languages, duration, buffer (clean-up time that also blocks the chair), optional price text, image, which doctors perform it. A treatment can only be published after ticking *Confirmed by the clinic*. *Can be booked online* controls whether it appears in the booking flow.
- **Website content** — clinic photos (only authentic GemDental photos of people), FAQ (only verified answers can be published), reviews (only genuine reviews with the author's permission), before & after cases (only with written consent recorded and both photos uploaded; pick *What the patient came in with* so the case shows under the right filter), and **Smiles & gems**: single photos of finished smiles and tooth gems for the Results page (same consent rule). The photos the clinic supplied in October 2026 were imported with `npm run db:import-photos`; their consent field says *Supplied by the clinic for publication* — replace that with the reference of each signed consent form, or untick *Published* for any photo without one.
- **Notifications** — channels on/off and connection status, reminder timing (e.g. 24 h and 2 h before), WhatsApp template names, editable message wording per language (placeholders like `{firstName}`, `{date}` are filled in automatically; *Restore default* reverts), failed messages with Retry, and the delivery log.
- **Staff accounts** (owner) — add people with a temporary password (12+ characters), change roles, deactivate, reset passwords. The clinic always keeps at least one active owner. Everyone can change their own password by clicking their name in the menu.
- **Activity log** — who confirmed, cancelled, moved or changed what, and when.

## Privacy

Only record what's needed to manage appointments; don't type medical history into notes. For an erasure request, an owner opens one of the patient's appointments and uses **Erase patient data** (keeps anonymous dates/treatments for statistics, cannot be undone). Old records are anonymised automatically after the retention period set in Settings.
