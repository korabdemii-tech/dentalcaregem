# Integrations: email, SMS, WhatsApp, bot protection

All messages go through one **outbox** (`notifications` table). A booking or staff action writes the message rows **in the same database transaction** as the change, so a message is never queued for something that didn't happen. A worker (cron endpoint or `npm run worker`) delivers them.

What the dashboard shows for each message:

| Status | Meaning |
|---|---|
| Queued / Sending | waiting or in progress (retries with back-off: 2, 4, 8 … minutes, up to 6 attempts) |
| Sent | accepted by the provider (Resend / Twilio / Meta). Not the same as "read" |
| Failed | gave up; visible under Notifications → Failed messages with a **Retry** button |
| Not sent | intentionally skipped: channel off, provider not configured, no WhatsApp template, or reminder no longer relevant (e.g. cancelled) |
| Logged (dev) | development mode, written to the server log only — nothing delivered |

A message is only created for SMS/WhatsApp when the patient ticked the matching opt-in box. Email is used for booking updates the patient requested.

**Duplicates are prevented** by a unique key per logical message (e.g. one "confirmed" email per appointment, one 24 h reminder per appointment time). Rows are claimed with `FOR UPDATE SKIP LOCKED`, so parallel workers never send the same row. Resend also receives an `Idempotency-Key`. *Edge case:* if a server crashes after the provider accepted a message but before the database is updated, that one message may be retried; Resend deduplicates it, Twilio/Meta do not.

## Email — Resend (recommended)

1. Create an account at resend.com, add and verify your sending domain (DNS: SPF, DKIM; add DMARC).
2. Set `EMAIL_PROVIDER=resend`, `RESEND_API_KEY=…`, `EMAIL_FROM="GemDental Care <appointments@your-domain>"`, optionally `EMAIL_REPLY_TO=clinic@your-domain`.
3. Dashboard → Notifications shows **Email: Connected**.

Another provider (Postmark, SES, SMTP) can be added in `src/lib/notifications/providers.ts` — one function.

## SMS — Twilio

1. Twilio account, buy a number or create a Messaging Service that can send to the clinic's country (check sender-ID rules for Kosovo/Albania/your market).
2. `SMS_PROVIDER=twilio`, `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM_NUMBER` **or** `TWILIO_MESSAGING_SERVICE_SID`.
3. Turn on SMS under Notifications → Channels.

## WhatsApp — Meta WhatsApp Business Cloud API

WhatsApp only allows business-initiated messages through **pre-approved templates**.

1. Meta Business Manager → WhatsApp → add the clinic's phone number; get the *Phone number ID* and a *permanent access token* (System User).
2. Create templates (category *Utility*) in each language, with five body variables in this order: `{{1}}` first name, `{{2}}` treatment, `{{3}}` date, `{{4}}` time, `{{5}}` reference. Example (`appointment_confirmed`, sq): `Përshëndetje {{1}}, termini juaj për {{2}} më {{3}} në orën {{4}} është konfirmuar. Referenca: {{5}}. GemDental Care`.
3. Set `WHATSAPP_PROVIDER=meta`, `WHATSAPP_PHONE_NUMBER_ID`, `WHATSAPP_ACCESS_TOKEN`, and the template language codes `WHATSAPP_TEMPLATE_LANGUAGE_SQ` / `_EN` exactly as approved.
4. Dashboard → Notifications → WhatsApp templates: enter each approved template name. Messages for events without a template are recorded as "Not sent".
5. "Sent" means Meta accepted it. Delivery/read receipts require a webhook (not included; see KNOWN_LIMITATIONS.md).

The website also has one-tap WhatsApp links (`wa.me`) once the clinic's WhatsApp number is set in Settings — that is a normal chat link, not an automated message.

## Bot protection — Cloudflare Turnstile (recommended)

Always on: honeypot field, a signed booking-session token (rejects submissions under 2 seconds or older than 45 minutes), same-origin check, rate limits (8 booking attempts per 10 min per IP, 5 per hour per email, 120 availability lookups per minute per IP, 10 logins per 15 min per IP, account lock after 5 wrong passwords).

Turnstile adds an invisible/managed challenge on the review step: create a widget at Cloudflare, set `NEXT_PUBLIC_TURNSTILE_SITE_KEY` and `TURNSTILE_SECRET_KEY`, rebuild. The CSP is extended automatically.
