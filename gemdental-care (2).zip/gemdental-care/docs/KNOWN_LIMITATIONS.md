# Known limitations

- **Content is sample content** until the clinic confirms it (CLINIC_INFO_NEEDED.md). The preview ribbon says so on every page.
- **Logo is a vector trace** of the supplied screenshot. Visually faithful, but should be replaced with the original vector master.
- **No real message delivery was performed** in development: providers need accounts and credentials. The pipeline was tested end to end with the development log provider; the Resend/Twilio/Meta adapters follow the providers' public APIs but have not been exercised against live accounts.
- **WhatsApp delivery/read receipts** and SMS status callbacks are not processed (no webhooks yet). "Sent" means the provider accepted the message.
- **Patients can't self-cancel or reschedule online**; they contact the clinic (FAQ draft explains this once the clinic confirms the policy). A signed "manage my booking" link can be added later.
- **One timezone per clinic**, not per doctor.
- **Legal pages are drafts** and must be reviewed for the clinic's jurisdiction.
- **Maps**: a directions link is used instead of an embedded map (no third-party scripts/cookies). An embed can be added once the address exists, with a cookie notice if required.
- **Albanian copy** was written carefully but has not been reviewed by a native speaker.
- **Browser date names** come from the site's own dictionaries (some Chromium builds lack Albanian date data), so dates read correctly everywhere.
- **Tested environments**: Chromium (desktop + Pixel 7 emulation) via Playwright. Safari/iOS and Firefox were not run here; the code uses no browser-specific features beyond those with broad support, but a manual check on a real iPhone is recommended before launch.
- **Docker** files are not provided; Vercel and VPS setups are documented.
