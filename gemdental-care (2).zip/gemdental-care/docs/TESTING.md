# Testing

Last full run (8 October 2026): **33 unit/integration tests and 55 end-to-end tests, all passing**, plus a clean `tsc` type check, Prettier check and production build.

## How to run

```bash
# one-time: databases
createdb gemdental_test && psql -d gemdental_test -c 'CREATE EXTENSION btree_gist'
createdb gemdental_e2e  && psql -d gemdental_e2e  -c 'CREATE EXTENSION btree_gist'

npm test                       # unit + integration (resets gemdental_test)
npm run build && npm run test:e2e   # E2E on a production build (resets gemdental_e2e, seeds demo data)
```

Override with `TEST_DATABASE_URL`, `E2E_DATABASE_URL`, `E2E_PORT`; `PW_CHROMIUM_PATH` points Playwright at a specific Chromium.

## Unit (Vitest) — `tests/unit`

- **Timezones**: winter/summer offsets, the spring-forward gap (02:30 doesn't exist) and autumn change, other zones, date-key arithmetic across months/years/leap days.
- **Availability engine**: working hours with breaks, days off, existing appointments, service buffer time, holidays/time off/all-day closures, minimum notice, past times, booking horizon, slot-grid alignment, DST-day slots.
- **Browser date formatting** in Albanian and English, in the clinic timezone.

## Integration (Vitest + real PostgreSQL) — `tests/integration`

- Pending vs confirmed status from the clinic setting, with the right message queued.
- **25 simultaneous requests for one slot → exactly 1 succeeds**; overlapping (not identical) simultaneous requests → 1 succeeds.
- The database itself rejects an overlapping insert (exclusion constraint).
- Idempotent retries (concurrent and sequential) → one appointment, one message.
- Outside working hours and during time off → refused.
- Cancellation frees the slot and queues a cancellation message; invalid status changes refused.
- Rescheduling only into free time; overlap refused even with "outside hours" override.
- Three concurrent queue workers deliver a message exactly once.
- Reminders are queued once even when the job runs repeatedly.

## End-to-end (Playwright, production build) — `tests/e2e`

**Public site** — every page in both languages returns 200 with one `h1`, correct `lang` and canonical URL, no console errors and no horizontal scroll; booking reachable in one click; navigation + current-page marking; language switch keeps the page; localized 404; unpublished treatments are not public; unconfirmed details show "To be confirmed" and review/results sections stay hidden; sitemap/robots/JSON-LD (no invented phone); security headers; **axe-core WCAG 2.2 A/AA scan with no serious/critical issues** on home, treatment, booking and contact pages; reduced-motion respected.

**Mobile (Pixel 7 emulation)** — custom menu opens, closes with Escape and returns focus; sticky booking bar; no horizontal overflow at 320, 375, 390, 430, 768, 1024 and 1440 px.

**Booking** — field validation messages and focus; full request booking stored as *pending* with the "received" message queued and the clear "not yet confirmed" wording; booked time disappears from availability; **two visitors racing for one time: the second is told, sent back to choose another time, and keeps their details**; complete Albanian flow; keyboard-operable calendar.

**Booking API protections** — cross-site POST rejected, honeypot and too-fast submissions rejected, forged/expired session token rejected, server-side validation errors, concurrent idempotent requests produce one appointment, rate limiting with `Retry-After`, no slots for past or beyond-horizon dates.

**Dashboard** — unreachable without signing in (also with a forged cookie); generic wrong-password error; staff role cannot see settings/accounts; sign-out ends the session; overview counts match the database; confirming a request sends the confirmation; moving onto another appointment is refused; blocking a day removes it from online booking; phone booking creation; day/week/month calendar; **auto-confirm setting changes what patients see ("Your appointment is confirmed." + calendar file)**; clinic contact details appear on the site and invalid timezone is rejected without losing typed input; unconfirmed treatments can't be published; photo upload replaces the placeholder and non-images are rejected; unverified reviews can't be published, verified ones appear; activity log; notification templates edit/restore.

Login and booking rate limits are real during tests; each test uses its own simulated client address.

## Bugs found and fixed by these tests

- Component CSS overrode Tailwind's `hidden` utility, causing horizontal scroll on phones → moved component classes into `@layer components`.
- Mobile menu panel collapsed to zero height because the header's backdrop blur became its containing block → menu rendered outside the header.
- React reset dashboard forms after a failed save, wiping what staff had typed → forms now submit without automatic reset.
- Status buttons disappeared before their success message could show → status changes now confirm on the page.
- Albanian dates showed in English in Chromium builds without Albanian locale data → dictionary-based date names.
- Low-contrast champagne text and an unlabeled decorative image (axe) → darker champagne text token, decorative placeholders hidden from assistive tech.
- Success heading lost its heading role → fixed.

## Not covered here

Real email/SMS/WhatsApp delivery (needs provider accounts), Safari/iOS and Firefox (Chromium only in this environment), load testing beyond the concurrency tests above, and a manual screen-reader pass (axe automated checks only). Recommended before launch: one manual test on an iPhone and an Android phone, and a VoiceOver/TalkBack walkthrough of the booking flow.
