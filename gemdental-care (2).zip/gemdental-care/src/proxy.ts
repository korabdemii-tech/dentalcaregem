import { NextResponse, type NextRequest } from "next/server";
import { enabledLocales, defaultLocale, isLocale } from "@/lib/i18n/config";

const ADMIN_COOKIE = "gd_admin_session";

/** Pick a language from Accept-Language among the enabled locales. */
function negotiate(header: string | null) {
  const enabled = enabledLocales();
  if (header) {
    const prefs = header
      .split(",")
      .map((p) => {
        const [tag, q] = p.trim().split(";q=");
        return { lang: tag.toLowerCase().split("-")[0], q: q ? Number(q) : 1 };
      })
      .sort((a, b) => b.q - a.q);
    for (const p of prefs) if (isLocale(p.lang) && enabled.includes(p.lang)) return p.lang;
  }
  return defaultLocale();
}

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl;

  // Admin: cheap presence check only. Every admin page and action verifies the
  // session against the database (src/lib/auth/session.ts).
  if (pathname.startsWith("/admin")) {
    if (pathname === "/admin/login") return NextResponse.next();
    if (!req.cookies.get(ADMIN_COOKIE)?.value) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      url.search = "";
      return NextResponse.redirect(url);
    }
    return NextResponse.next();
  }

  // Public site: every page lives under /{locale}. Redirect bare paths.
  const first = pathname.split("/")[1];
  if (isLocale(first)) return NextResponse.next();
  const saved = req.cookies.get("gd_locale")?.value;
  const locale = saved && isLocale(saved) && enabledLocales().includes(saved) ? saved : negotiate(req.headers.get("accept-language"));
  const url = req.nextUrl.clone();
  url.pathname = `/${locale}${pathname === "/" ? "" : pathname}`;
  return NextResponse.redirect(url);
}

export const config = {
  // Skip API routes, media, Next internals and files with an extension.
  matcher: ["/((?!api|media|_next|brand|icon|apple-icon|favicon|robots.txt|sitemap.xml|.*\\.[\\w]+$).*)"],
};
