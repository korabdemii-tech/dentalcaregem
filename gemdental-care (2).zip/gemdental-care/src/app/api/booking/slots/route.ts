import { getDaySlots } from "@/lib/booking/availability-service";
import { json, resolveServiceAndDoctors } from "@/lib/booking/api-helpers";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp } from "@/lib/security/request";
import { isValidDateKey } from "@/lib/time";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Bookable start times on one day. Recomputed from live data on every request. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const rl = await rateLimit("availability", clientIp(req.headers), 120, 60);
  if (!rl.ok)
    return json({ error: "RATE_LIMITED", retryAfter: rl.retryAfterSeconds }, 429, { "Retry-After": String(rl.retryAfterSeconds) });

  const date = url.searchParams.get("date") ?? "";
  if (!isValidDateKey(date)) return json({ error: "BAD_REQUEST" }, 400);
  const resolved = await resolveServiceAndDoctors(url.searchParams.get("service"), url.searchParams.get("doctor"));
  if (!resolved) return json({ error: "SERVICE_UNAVAILABLE" }, 404);
  const settings = await getSettings();
  if (!settings.onlineBookingEnabled) return json({ error: "BOOKING_DISABLED" }, 503);

  const slots = await getDaySlots({ service: resolved.service, doctorIds: resolved.doctorIds, date, settings });
  return json({ date, timezone: settings.timezone, slots });
}
