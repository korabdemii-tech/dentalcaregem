import { after } from "next/server";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { createBooking } from "@/lib/booking/create";
import { json, BOOKING_SESSION_MAX_AGE_MS, BOOKING_SESSION_MIN_AGE_MS } from "@/lib/booking/api-helpers";
import { bookingRequestSchema, fieldErrors } from "@/lib/validation";
import { getSettings } from "@/lib/settings";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp, isSameOrigin } from "@/lib/security/request";
import { verifyToken } from "@/lib/security/token";
import { verifyTurnstile } from "@/lib/security/turnstile";
import { processNotificationQueue } from "@/lib/notifications/queue";

export const dynamic = "force-dynamic";

/**
 * Create a booking. The server is the authority: it re-validates every field,
 * re-checks the slot against live availability inside a locked transaction,
 * and returns the definitive status ("confirmed" or "pending").
 */
export async function POST(req: Request) {
  if (!isSameOrigin(req)) return json({ error: "FORBIDDEN" }, 403);
  if (!(req.headers.get("content-type") ?? "").includes("application/json")) return json({ error: "BAD_REQUEST" }, 415);

  const ip = clientIp(req.headers);
  const ipLimit = await rateLimit("booking:ip", ip, 8, 600);
  if (!ipLimit.ok)
    return json({ error: "RATE_LIMITED", retryAfter: ipLimit.retryAfterSeconds }, 429, {
      "Retry-After": String(ipLimit.retryAfterSeconds),
    });

  let body: unknown;
  try {
    const text = await req.text();
    if (text.length > 20_000) return json({ error: "BAD_REQUEST" }, 413);
    body = JSON.parse(text);
  } catch {
    return json({ error: "BAD_REQUEST" }, 400);
  }

  const settings = await getSettings();
  if (!settings.onlineBookingEnabled) return json({ error: "BOOKING_DISABLED" }, 503);

  const parsed = bookingRequestSchema(settings.country).safeParse(body);
  if (!parsed.success) {
    const fields = fieldErrors(parsed.error);
    // A filled honeypot is a bot. Answer vaguely.
    if (fields.website) return json({ error: "BOT" }, 400);
    return json({ error: "VALIDATION", fields }, 422);
  }
  const data = parsed.data;

  const session = verifyToken<{ iat: number }>(data.sessionToken);
  if (!session || typeof session.iat !== "number") return json({ error: "SESSION_EXPIRED" }, 400);
  const age = Date.now() - session.iat;
  if (age > BOOKING_SESSION_MAX_AGE_MS) return json({ error: "SESSION_EXPIRED" }, 400);
  if (age < BOOKING_SESSION_MIN_AGE_MS) return json({ error: "BOT" }, 400);

  if (!(await verifyTurnstile(data.turnstileToken, ip))) return json({ error: "BOT" }, 400);

  const emailLimit = await rateLimit("booking:email", data.patient.email.toLowerCase(), 5, 3600);
  if (!emailLimit.ok)
    return json({ error: "RATE_LIMITED", retryAfter: emailLimit.retryAfterSeconds }, 429, {
      "Retry-After": String(emailLimit.retryAfterSeconds),
    });

  let result: Awaited<ReturnType<typeof createBooking>>;
  try {
    result = await createBooking(
      {
        serviceId: data.serviceId,
        doctorId: data.doctorId,
        start: new Date(data.start),
        locale: data.locale,
        idempotencyKey: data.idempotencyKey,
        source: "online",
        patient: {
          fullName: data.patient.fullName,
          phone: data.patient.phone,
          email: data.patient.email,
          note: data.patient.note,
          isReturning: data.patient.isReturning,
          consentSms: data.patient.consentSms,
          consentWhatsapp: data.patient.consentWhatsapp,
          privacyAccepted: data.patient.acceptPrivacy,
        },
      },
      settings,
    );
  } catch (err) {
    // Log without personal data; the patient gets a clear "not booked" answer.
    console.error("[booking] create failed:", err instanceof Error ? err.message : err);
    return json({ error: "SERVER_ERROR" }, 500);
  }

  if (!result.ok) {
    const status = { SLOT_UNAVAILABLE: 409, SERVICE_UNAVAILABLE: 409, DOCTOR_UNAVAILABLE: 409, BOOKING_DISABLED: 503 }[result.code];
    return json({ error: result.code }, status);
  }

  // Deliver the "received"/"confirmed" message right after responding.
  after(() => processNotificationQueue({ appointmentId: result.appointmentId }).catch((e) => console.error("[notifications]", e)));

  const [doctor] = await db().select({ name: schema.doctors.fullName }).from(schema.doctors).where(eq(schema.doctors.id, result.doctorId));
  return json(
    {
      status: result.status,
      reference: result.reference,
      startsAt: result.startsAt,
      endsAt: result.endsAt,
      doctorName: doctor?.name ?? null,
      replayed: result.replayed,
    },
    result.replayed ? 200 : 201,
  );
}
