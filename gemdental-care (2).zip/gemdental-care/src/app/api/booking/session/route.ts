import { signToken } from "@/lib/security/token";
import { json, BOOKING_SESSION_MAX_AGE_MS } from "@/lib/booking/api-helpers";

export const dynamic = "force-dynamic";

/** Issue a short-lived, signed booking-session token (anti-bot timing + session expiry). */
export async function GET() {
  return json({ token: signToken({ iat: Date.now(), v: 1 }), maxAgeMs: BOOKING_SESSION_MAX_AGE_MS });
}
