import { getMonthAvailability } from "@/lib/booking/availability-service";
import { json, resolveServiceAndDoctors } from "@/lib/booking/api-helpers";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp } from "@/lib/security/request";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";

/** Days in a month that have at least one bookable slot. */
export async function GET(req: Request) {
  const url = new URL(req.url);
  const rl = await rateLimit("availability", clientIp(req.headers), 120, 60);
  if (!rl.ok)
    return json({ error: "RATE_LIMITED", retryAfter: rl.retryAfterSeconds }, 429, { "Retry-After": String(rl.retryAfterSeconds) });

  const month = url.searchParams.get("month") ?? "";
  const m = /^(\d{4})-(\d{2})$/.exec(month);
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12) return json({ error: "BAD_REQUEST" }, 400);
  const resolved = await resolveServiceAndDoctors(url.searchParams.get("service"), url.searchParams.get("doctor"));
  if (!resolved) return json({ error: "SERVICE_UNAVAILABLE" }, 404);
  const settings = await getSettings();
  if (!settings.onlineBookingEnabled) return json({ error: "BOOKING_DISABLED" }, 503);

  const result = await getMonthAvailability({
    service: resolved.service,
    doctorIds: resolved.doctorIds,
    year: Number(m[1]),
    month: Number(m[2]),
  });
  return json({ ...result, timezone: settings.timezone });
}
