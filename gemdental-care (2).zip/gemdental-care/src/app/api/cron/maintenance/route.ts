import { isCronAuthorized } from "@/lib/security/cron";
import { json } from "@/lib/booking/api-helpers";
import { pruneExpiredSessions } from "@/lib/auth/maintenance";
import { pruneRateLimits } from "@/lib/security/rate-limit";
import { runRetention } from "@/lib/privacy";
import { getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Run daily: expire sessions, prune rate-limit windows, apply data retention. */
async function run(req: Request) {
  if (!isCronAuthorized(req)) return json({ error: "UNAUTHORIZED" }, 401);
  await pruneExpiredSessions();
  await pruneRateLimits();
  const settings = await getSettings();
  const retention = await runRetention(settings.dataRetentionMonths);
  return json({ ok: true, ...retention });
}
export const GET = run;
export const POST = run;
