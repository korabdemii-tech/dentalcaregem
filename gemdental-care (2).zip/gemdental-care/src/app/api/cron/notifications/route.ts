import { isCronAuthorized } from "@/lib/security/cron";
import { processNotificationQueue, scheduleDueReminders } from "@/lib/notifications/queue";
import { json } from "@/lib/booking/api-helpers";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Run every 5 minutes: queue due reminders, then deliver queued messages. */
async function run(req: Request) {
  if (!isCronAuthorized(req)) return json({ error: "UNAUTHORIZED" }, 401);
  const reminders = await scheduleDueReminders();
  let processed = 0;
  let sent = 0;
  let failed = 0;
  for (let i = 0; i < 5; i++) {
    const r = await processNotificationQueue({ limit: 25 });
    processed += r.processed;
    sent += r.sent;
    failed += r.failed;
    if (r.processed < 25) break;
  }
  return json({ ok: true, reminders: reminders.checked, processed, sent, failed });
}
export const GET = run;
export const POST = run;
