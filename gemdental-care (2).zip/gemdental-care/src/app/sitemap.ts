import type { MetadataRoute } from "next";
import { env } from "@/lib/env";
import { enabledLocales, LOCALE_TAG } from "@/lib/i18n/config";
import { getPublishedServices } from "@/lib/content";

export const dynamic = "force-dynamic";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const site = env.siteUrl;
  const locales = enabledLocales();
  let slugs: string[] = [];
  try {
    slugs = (await getPublishedServices()).map((s) => s.slug);
  } catch {
    // Database unavailable: still return the static pages.
  }
  const paths = [
    "",
    "/services",
    "/results",
    "/about",
    "/team",
    "/booking",
    "/contact",
    "/privacy",
    "/terms",
    ...slugs.map((s) => `/services/${s}`),
  ];
  return paths.flatMap((path) =>
    locales.map((l) => ({
      url: `${site}/${l}${path}`,
      changeFrequency: path === "" || path === "/booking" ? ("weekly" as const) : ("monthly" as const),
      priority: path === "" ? 1 : path === "/booking" ? 0.9 : path.startsWith("/services") ? 0.8 : 0.5,
      alternates: { languages: Object.fromEntries(locales.map((x) => [LOCALE_TAG[x], `${site}/${x}${path}`])) },
    })),
  );
}
