import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { Logo } from "@/components/brand/Logo";
import { MarkOutline } from "@/components/brand/Logo";
import { LoginForm } from "./LoginForm";

export default async function LoginPage() {
  if (await getCurrentAdmin()) redirect("/admin");
  const { a } = await getAdminDict();
  return (
    <main className="grid min-h-dvh lg:grid-cols-2">
      <div className="on-dark bg-plum relative hidden overflow-hidden lg:block">
        <MarkOutline className="absolute top-1/2 left-1/2 h-[120%] w-auto max-w-none -translate-x-1/2 -translate-y-1/2 opacity-40" />
        <div className="absolute bottom-10 left-10">
          <Logo tone="white" height={48} />
        </div>
      </div>
      <div className="bg-ivory flex items-center justify-center px-6 py-16">
        <div className="w-full max-w-sm">
          <div className="lg:hidden">
            <Logo height={40} />
          </div>
          <h1 className="font-display text-plum mt-10 text-3xl lg:mt-0">{a.login.title}</h1>
          <p className="text-ink-muted mt-2 text-sm">{a.login.lead}</p>
          <LoginForm strings={a.login} />
        </div>
      </div>
    </main>
  );
}
