"use client";

import { useActionState } from "react";
import { login } from "../actions/auth";
import type { AdminDictionary } from "@/lib/i18n/dictionaries/admin-en";

export function LoginForm({ strings }: { strings: AdminDictionary["login"] }) {
  const [state, action, pending] = useActionState(login, {});
  return (
    <form action={action} className="mt-8 space-y-5">
      <div>
        <label htmlFor="email" className="field-label">
          {strings.email}
        </label>
        <input id="email" name="email" type="email" autoComplete="username" required className="input" aria-invalid={state.ok === false} />
      </div>
      <div>
        <label htmlFor="password" className="field-label">
          {strings.password}
        </label>
        <input
          id="password"
          name="password"
          type="password"
          autoComplete="current-password"
          required
          className="input"
          aria-invalid={state.ok === false}
        />
      </div>
      {state.message && (
        <p key={state.at} role="alert" className="bg-error-bg text-error rounded-md px-3 py-2 text-sm">
          {state.message}
        </p>
      )}
      <button type="submit" disabled={pending} className="btn btn-primary w-full">
        {pending && <span className="spinner" aria-hidden />}
        {pending ? strings.submitting : strings.submit}
      </button>
    </form>
  );
}
