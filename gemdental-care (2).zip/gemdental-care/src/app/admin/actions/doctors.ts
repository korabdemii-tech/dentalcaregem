"use server";

import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { adminAction, bool, int, lines, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";
import { hhmmToMinutes } from "@/lib/time";
import { storeImageUpload } from "@/lib/admin/media";

function slugify(name: string) {
  return name
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/^dr\.?\s+/, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 60);
}

export const saveDoctor = adminAction("doctors.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  const isNew = !UUID_RE.test(id);
  const fullName = str(form, "fullName", 120);
  if (fullName.length < 2) return { ok: false, message: a.services.invalid, errors: { fullName: a.common.required } };
  let photoMediaId: string | null | undefined;
  const upload = form.get("photo");
  if (upload && typeof upload !== "string" && upload.size > 0) {
    const res = await storeImageUpload(upload, { alt: { sq: fullName, en: fullName }, authentic: true, label: `doctor:${fullName}` });
    if (!res.ok) return { ok: false, message: res.reason === "size" ? a.content.images.tooLarge : a.content.images.invalidType };
    photoMediaId = res.id;
  }
  if (bool(form, "removePhoto")) photoMediaId = null;
  const values = {
    fullName,
    title: { sq: str(form, "titleSq", 120), en: str(form, "titleEn", 120) },
    bio: { sq: str(form, "bioSq", 4000), en: str(form, "bioEn", 4000) },
    experience: { sq: str(form, "experienceSq", 1000), en: str(form, "experienceEn", 1000) },
    education: { sq: lines(form, "educationSq"), en: lines(form, "educationEn") },
    specialties: { sq: lines(form, "specialtiesSq"), en: lines(form, "specialtiesEn") },
    languages: { sq: lines(form, "languagesSq"), en: lines(form, "languagesEn") },
    qualifications: { sq: lines(form, "qualificationsSq"), en: lines(form, "qualificationsEn") },
    active: bool(form, "active"),
    published: bool(form, "published"),
    sortOrder: int(form, "sortOrder", 0, 999) ?? 0,
    ...(photoMediaId !== undefined ? { photoMediaId } : {}),
  };
  if (isNew) {
    let slug = slugify(fullName) || "doctor";
    const taken = await db().select({ id: schema.doctors.id }).from(schema.doctors).where(eq(schema.doctors.slug, slug));
    if (taken.length) slug = `${slug}-${Date.now().toString(36).slice(-4)}`;
    const [row] = await db()
      .insert(schema.doctors)
      .values({ ...values, slug })
      .returning({ id: schema.doctors.id });
    await audit({ actorId: user.id, actorLabel: user.email, action: "doctor.created", entityType: "doctor", entityId: row.id });
    redirect(`/admin/doctors/${row.id}?saved=1`);
  }
  await db().update(schema.doctors).set(values).where(eq(schema.doctors.id, id));
  await audit({ actorId: user.id, actorLabel: user.email, action: "doctor.updated", entityType: "doctor", entityId: id });
  return { ok: true, message: a.doctors.saved };
});

export const saveSchedule = adminAction("doctors.manage", async ({ user, a, form }) => {
  const doctorId = str(form, "doctorId");
  if (!UUID_RE.test(doctorId)) return { ok: false, message: a.common.serverError };
  const rows: { doctorId: string; weekday: number; startMinute: number; endMinute: number }[] = [];
  const errors: Record<string, string> = {};
  for (let wd = 0; wd < 7; wd++) {
    const ranges: [number, number][] = [];
    for (const n of [1, 2]) {
      const f = str(form, `d${wd}_from${n}`);
      const u = str(form, `d${wd}_until${n}`);
      if (!f && !u) continue;
      const fm = hhmmToMinutes(f);
      const um = hhmmToMinutes(u);
      if (fm === null || um === null || um <= fm) {
        errors[`d${wd}_until${n}`] = a.doctors.invalidSchedule;
        continue;
      }
      ranges.push([fm, um]);
    }
    ranges.sort((x, y) => x[0] - y[0]);
    if (ranges.length === 2 && ranges[1][0] < ranges[0][1]) errors[`d${wd}_from2`] = a.doctors.invalidSchedule;
    for (const [s, e] of ranges) rows.push({ doctorId, weekday: wd, startMinute: s, endMinute: e });
  }
  if (Object.keys(errors).length) return { ok: false, message: a.doctors.invalidSchedule, errors };
  await db().transaction(async (tx) => {
    await tx.delete(schema.workingHours).where(eq(schema.workingHours.doctorId, doctorId));
    if (rows.length) await tx.insert(schema.workingHours).values(rows);
    await audit(
      {
        actorId: user.id,
        actorLabel: user.email,
        action: "doctor.schedule_updated",
        entityType: "doctor",
        entityId: doctorId,
        details: { blocks: rows.length },
      },
      tx,
    );
  });
  return { ok: true, message: a.doctors.scheduleSaved };
});
