"use server";

import { redirect } from "next/navigation";
import { and, count, eq, ne } from "drizzle-orm";
import { adminAction, bool, int, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";
import { storeImageUpload } from "@/lib/admin/media";

const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export const saveService = adminAction("services.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  const isNew = !UUID_RE.test(id);
  const errors: Record<string, string> = {};
  const slug = str(form, "slug", 80).toLowerCase();
  const nameSq = str(form, "nameSq", 120);
  const nameEn = str(form, "nameEn", 120);
  const duration = int(form, "durationMinutes", 5, 600);
  const buffer = int(form, "bufferMinutes", 0, 240);
  const sortOrder = int(form, "sortOrder", 0, 999) ?? 0;
  if (!SLUG_RE.test(slug)) errors.slug = a.services.slugHint;
  if (!nameSq && !nameEn) errors.nameSq = a.common.required;
  if (duration === null) errors.durationMinutes = a.common.required;
  if (buffer === null) errors.bufferMinutes = a.common.required;
  const confirmed = bool(form, "confirmed");
  const published = bool(form, "published");
  if (published && !confirmed) errors.published = a.services.publishNeedsConfirm;
  const clash = await db()
    .select({ id: schema.services.id })
    .from(schema.services)
    .where(and(eq(schema.services.slug, slug), isNew ? undefined : ne(schema.services.id, id)));
  if (clash.length) errors.slug = a.services.slugTaken;
  if (Object.keys(errors).length) return { ok: false, message: errors.published ?? a.services.invalid, errors };

  let imageMediaId: string | null | undefined;
  const upload = form.get("image");
  if (upload && typeof upload !== "string" && upload.size > 0) {
    const res = await storeImageUpload(upload, {
      alt: { sq: nameSq, en: nameEn },
      authentic: bool(form, "imageAuthentic"),
      label: `service:${slug}`,
    });
    if (!res.ok)
      return {
        ok: false,
        message: res.reason === "size" ? a.content.images.tooLarge : a.content.images.invalidType,
        errors: { image: a.content.images.invalidType },
      };
    imageMediaId = res.id;
  }
  if (bool(form, "removeImage")) imageMediaId = null;

  const values = {
    slug,
    name: { sq: nameSq, en: nameEn },
    summary: { sq: str(form, "summarySq", 300), en: str(form, "summaryEn", 300) },
    description: { sq: str(form, "descriptionSq", 4000), en: str(form, "descriptionEn", 4000) },
    durationMinutes: duration!,
    bufferMinutes: buffer!,
    price: { sq: str(form, "priceSq", 80), en: str(form, "priceEn", 80) },
    priceVisible: bool(form, "priceVisible"),
    durationVisible: bool(form, "durationVisible"),
    confirmed,
    published,
    bookable: bool(form, "bookable"),
    isConsultation: bool(form, "isConsultation"),
    sortOrder,
    updatedAt: new Date(),
    ...(imageMediaId !== undefined ? { imageMediaId } : {}),
  };
  const doctorIds = form
    .getAll("doctorIds")
    .map(String)
    .filter((x) => UUID_RE.test(x));

  const savedId = await db().transaction(async (tx) => {
    let sid = id;
    if (isNew) [{ id: sid }] = await tx.insert(schema.services).values(values).returning({ id: schema.services.id });
    else await tx.update(schema.services).set(values).where(eq(schema.services.id, id));
    await tx.delete(schema.doctorServices).where(eq(schema.doctorServices.serviceId, sid));
    if (doctorIds.length) await tx.insert(schema.doctorServices).values(doctorIds.map((doctorId) => ({ doctorId, serviceId: sid })));
    await audit(
      {
        actorId: user.id,
        actorLabel: user.email,
        action: isNew ? "service.created" : "service.updated",
        entityType: "service",
        entityId: sid,
        details: { slug, published, confirmed },
      },
      tx,
    );
    return sid;
  });
  if (isNew) redirect(`/admin/services/${savedId}?saved=1`);
  return { ok: true, message: a.services.saved };
});

export const deleteService = adminAction("services.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (!UUID_RE.test(id)) return { ok: false, message: a.common.serverError };
  const [{ n }] = await db().select({ n: count() }).from(schema.appointments).where(eq(schema.appointments.serviceId, id));
  if (n > 0) return { ok: false, message: a.services.deleteBlocked };
  await db().delete(schema.services).where(eq(schema.services.id, id));
  await audit({ actorId: user.id, actorLabel: user.email, action: "service.deleted", entityType: "service", entityId: id });
  redirect("/admin/services");
});
