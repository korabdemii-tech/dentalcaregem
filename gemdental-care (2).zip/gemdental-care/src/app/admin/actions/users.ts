"use server";

import { and, eq, ne } from "drizzle-orm";
import { adminAction, bool, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";
import { hashPassword, passwordProblem, verifyPassword } from "@/lib/auth/password";
import { destroyAllSessionsFor, createSession } from "@/lib/auth/session";
import { lookup } from "@/lib/i18n/format";
import type { Role } from "@/lib/auth/permissions";

const ROLES: Role[] = ["owner", "manager", "staff"];

export const createUser = adminAction("users.manage", async ({ user, a, form }) => {
  const email = str(form, "email", 200).toLowerCase();
  const name = str(form, "name", 120);
  const role = str(form, "role") as Role;
  const password = str(form, "password", 200);
  const errors: Record<string, string> = {};
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.email = a.newAppointment.invalidEmail;
  if (name.length < 2) errors.name = a.common.required;
  if (!ROLES.includes(role)) errors.role = a.common.required;
  const pw = passwordProblem(password);
  if (pw) errors.password = lookup({ admin: a }, pw);
  const taken = await db().select({ id: schema.adminUsers.id }).from(schema.adminUsers).where(eq(schema.adminUsers.email, email));
  if (taken.length) errors.email = a.users.emailTaken;
  if (Object.keys(errors).length) return { ok: false, message: a.services.invalid, errors };
  const [row] = await db()
    .insert(schema.adminUsers)
    .values({ email, name, role, passwordHash: await hashPassword(password) })
    .returning({ id: schema.adminUsers.id });
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "user.created",
    entityType: "admin_user",
    entityId: row.id,
    details: { role },
  });
  return { ok: true, message: a.users.created };
});

export const updateUser = adminAction("users.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  const role = str(form, "role") as Role;
  const active = bool(form, "active");
  if (!UUID_RE.test(id) || !ROLES.includes(role)) return { ok: false, message: a.common.serverError };
  if (id === user.id && (role !== "owner" || !active)) return { ok: false, message: a.users.cannotDemoteSelf };
  const newPassword = str(form, "newPassword", 200);
  const set: Partial<typeof schema.adminUsers.$inferInsert> = { role, active };
  if (newPassword) {
    const pw = passwordProblem(newPassword);
    if (pw) return { ok: false, message: lookup({ admin: a }, pw), errors: { newPassword: lookup({ admin: a }, pw) } };
    set.passwordHash = await hashPassword(newPassword);
    set.failedLogins = 0;
    set.lockedUntil = null;
  }
  // Never leave the clinic without an active owner.
  if (role !== "owner" || !active) {
    const owners = await db()
      .select({ id: schema.adminUsers.id })
      .from(schema.adminUsers)
      .where(and(eq(schema.adminUsers.role, "owner"), eq(schema.adminUsers.active, true), ne(schema.adminUsers.id, id)));
    if (!owners.length) return { ok: false, message: a.users.cannotDemoteSelf };
  }
  await db().update(schema.adminUsers).set(set).where(eq(schema.adminUsers.id, id));
  if (newPassword || !active) await destroyAllSessionsFor(id);
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: newPassword ? "user.password_reset" : "user.updated",
    entityType: "admin_user",
    entityId: id,
    details: { role, active },
  });
  return { ok: true, message: newPassword ? a.users.passwordReset : a.users.updated };
});

/** Any signed-in staff member can change their own password. */
export const changeOwnPassword = adminAction("appointments.view", async ({ user, a, form }) => {
  const current = str(form, "currentPassword", 200);
  const next = str(form, "newPassword", 200);
  const [row] = await db().select().from(schema.adminUsers).where(eq(schema.adminUsers.id, user.id));
  if (!row || !(await verifyPassword(row.passwordHash, current)))
    return { ok: false, message: a.users.wrongPassword, errors: { currentPassword: a.users.wrongPassword } };
  const pw = passwordProblem(next);
  if (pw) return { ok: false, message: lookup({ admin: a }, pw), errors: { newPassword: lookup({ admin: a }, pw) } };
  await db()
    .update(schema.adminUsers)
    .set({ passwordHash: await hashPassword(next) })
    .where(eq(schema.adminUsers.id, user.id));
  await destroyAllSessionsFor(user.id);
  await createSession(user.id); // keep this device signed in
  await audit({ actorId: user.id, actorLabel: user.email, action: "user.password_changed", entityType: "admin_user", entityId: user.id });
  return { ok: true, message: a.common.saved };
});
