"use server";

import { and, eq } from "drizzle-orm";
import { adminAction, bool, int, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";
import { NOTIFICATION_EVENTS, type NotificationEvent } from "@/lib/notifications/templates";
import { processNotificationQueue, scheduleDueReminders } from "@/lib/notifications/queue";
import { fmt } from "@/lib/i18n/format";

export const saveChannels = adminAction("notifications.manage", async ({ user, a, form }) => {
  const reminders: { key: string; minutesBefore: number; enabled: boolean }[] = [];
  for (let i = 0; i < 4; i++) {
    const hours = int(form, `rem${i}_hours`, 1, 336);
    if (hours === null) continue;
    reminders.push({ key: `${hours}h`, minutesBefore: hours * 60, enabled: bool(form, `rem${i}_enabled`) });
  }
  const dedup = [...new Map(reminders.map((r) => [r.key, r])).values()];
  const whatsappTemplates: Record<string, string> = {};
  for (const e of NOTIFICATION_EVENTS) {
    const v = str(form, `wa_${e}`, 120);
    if (v && /^[a-z0-9_]+$/.test(v)) whatsappTemplates[e] = v;
  }
  await db()
    .update(schema.clinicSettings)
    .set({
      channelsEnabled: { email: bool(form, "ch_email"), sms: bool(form, "ch_sms"), whatsapp: bool(form, "ch_whatsapp") },
      reminders: dedup,
      whatsappTemplates,
      updatedAt: new Date(),
    })
    .where(eq(schema.clinicSettings.id, 1));
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "notifications.settings_updated",
    entityType: "settings",
    entityId: "1",
  });
  return { ok: true, message: a.notifications.saved };
});

export const saveTemplate = adminAction("notifications.manage", async ({ user, a, form }) => {
  const event = str(form, "event") as NotificationEvent;
  const channel = str(form, "channel") as "email" | "sms";
  const locale = str(form, "locale");
  if (!NOTIFICATION_EVENTS.includes(event) || !["email", "sms"].includes(channel) || !["sq", "en"].includes(locale))
    return { ok: false, message: a.common.serverError };
  const where = and(
    eq(schema.notificationTemplates.event, event),
    eq(schema.notificationTemplates.channel, channel),
    eq(schema.notificationTemplates.locale, locale),
  );
  if (bool(form, "reset")) {
    await db().delete(schema.notificationTemplates).where(where);
  } else {
    const body = str(form, "body", 3000);
    if (!body) return { ok: false, message: a.services.invalid, errors: { body: a.common.required } };
    await db()
      .insert(schema.notificationTemplates)
      .values({
        event,
        channel,
        locale,
        subject: channel === "email" ? str(form, "subject", 200) : null,
        body,
        enabled: bool(form, "enabled"),
        updatedBy: user.id,
      })
      .onConflictDoUpdate({
        target: [schema.notificationTemplates.event, schema.notificationTemplates.channel, schema.notificationTemplates.locale],
        set: {
          subject: channel === "email" ? str(form, "subject", 200) : null,
          body,
          enabled: bool(form, "enabled"),
          updatedBy: user.id,
          updatedAt: new Date(),
        },
      });
  }
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "notifications.template_updated",
    entityType: "template",
    entityId: `${event}:${channel}:${locale}`,
  });
  return { ok: true, message: a.common.saved };
});

export const retryNotification = adminAction("notifications.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (!UUID_RE.test(id)) return { ok: false, message: a.common.serverError };
  await db()
    .update(schema.notifications)
    .set({ status: "queued", attempts: 0, nextAttemptAt: new Date(), lastError: null, updatedAt: new Date() })
    .where(and(eq(schema.notifications.id, id), eq(schema.notifications.status, "failed")));
  await audit({ actorId: user.id, actorLabel: user.email, action: "notifications.retry", entityType: "notification", entityId: id });
  await processNotificationQueue({ limit: 5 });
  return { ok: true, message: a.notifications.retried };
});

export const runQueue = adminAction("notifications.manage", async ({ a }) => {
  await scheduleDueReminders();
  const r = await processNotificationQueue({ limit: 50 });
  return { ok: true, message: fmt(a.notifications.queueRan, { n: r.processed }) };
});
