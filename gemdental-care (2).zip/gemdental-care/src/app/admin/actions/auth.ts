"use server";

import { headers, cookies } from "next/headers";
import { redirect } from "next/navigation";
import { refresh } from "next/cache";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { createSession, destroySession, getCurrentAdmin } from "@/lib/auth/session";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { rateLimit } from "@/lib/security/rate-limit";
import { clientIp } from "@/lib/security/request";
import { audit } from "@/lib/audit";
import { getAdminDict, ADMIN_LOCALE_COOKIE } from "@/lib/admin/i18n";
import { isLocale } from "@/lib/i18n/config";
import type { ActionState } from "@/lib/admin/action";

const MAX_FAILED = 5;
const LOCK_MINUTES = 15;
let dummyHash: Promise<string> | null = null;

export async function login(_prev: ActionState, form: FormData): Promise<ActionState> {
  const { a } = await getAdminDict();
  const email = String(form.get("email") ?? "")
    .trim()
    .toLowerCase()
    .slice(0, 200);
  const password = String(form.get("password") ?? "").slice(0, 200);
  const ip = clientIp(await headers());

  const rl = await rateLimit("login:ip", ip, 10, 900);
  if (!rl.ok) return { ok: false, message: a.login.rateLimited, at: Date.now() };

  const rows = email ? await db().select().from(schema.adminUsers).where(eq(schema.adminUsers.email, email)) : [];
  const user = rows[0];
  if (!user || !user.active) {
    // Spend the same time as a real check so response time doesn't reveal which emails exist.
    dummyHash ??= hashPassword("timing-equaliser-not-a-real-password");
    await verifyPassword(await dummyHash, password);
    await audit({
      actorLabel: "anonymous",
      action: "auth.login_failed",
      entityType: "admin_user",
      details: { reason: "unknown_or_inactive" },
    });
    return { ok: false, message: a.login.invalid, at: Date.now() };
  }
  if (user.lockedUntil && user.lockedUntil > new Date()) return { ok: false, message: a.login.locked, at: Date.now() };

  const valid = await verifyPassword(user.passwordHash, password);
  if (!valid) {
    const failed = user.failedLogins + 1;
    const lock = failed >= MAX_FAILED;
    await db()
      .update(schema.adminUsers)
      .set({ failedLogins: lock ? 0 : failed, lockedUntil: lock ? new Date(Date.now() + LOCK_MINUTES * 60_000) : user.lockedUntil })
      .where(eq(schema.adminUsers.id, user.id));
    await audit({
      actorId: user.id,
      actorLabel: user.email,
      action: lock ? "auth.locked" : "auth.login_failed",
      entityType: "admin_user",
      entityId: user.id,
    });
    return { ok: false, message: lock ? a.login.locked : a.login.invalid, at: Date.now() };
  }

  await db()
    .update(schema.adminUsers)
    .set({ failedLogins: 0, lockedUntil: null, lastLoginAt: new Date() })
    .where(eq(schema.adminUsers.id, user.id));
  await createSession(user.id);
  await audit({ actorId: user.id, actorLabel: user.email, action: "auth.login", entityType: "admin_user", entityId: user.id });
  redirect("/admin");
}

export async function logout() {
  const user = await getCurrentAdmin();
  await destroySession();
  if (user) await audit({ actorId: user.id, actorLabel: user.email, action: "auth.logout", entityType: "admin_user", entityId: user.id });
  redirect("/admin/login");
}

export async function setAdminLanguage(form: FormData) {
  const locale = String(form.get("locale") ?? "");
  if (!isLocale(locale)) return;
  (await cookies()).set(ADMIN_LOCALE_COOKIE, locale, { path: "/admin", httpOnly: true, sameSite: "lax", maxAge: 31536000 });
  const user = await getCurrentAdmin();
  if (user) await db().update(schema.adminUsers).set({ locale }).where(eq(schema.adminUsers.id, user.id));
  refresh();
}
