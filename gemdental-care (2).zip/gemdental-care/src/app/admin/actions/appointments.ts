"use server";

import { after } from "next/server";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { adminAction, bool, str, UUID_RE } from "@/lib/admin/action";
import { changeStatus, reschedule, updateAdminNotes } from "@/lib/booking/manage";
import { createBooking } from "@/lib/booking/create";
import { processNotificationQueue } from "@/lib/notifications/queue";
import { getSettings } from "@/lib/settings";
import { hhmmToMinutes, isValidDateKey, zonedToUtc } from "@/lib/time";
import { normalizePhone } from "@/lib/validation";
import { db, schema } from "@/lib/db";

const flush = (appointmentId: string) =>
  after(() => processNotificationQueue({ appointmentId }).catch((e) => console.error("[notifications]", e)));

const STATUS_TARGETS = ["confirmed", "cancelled", "completed", "no_show", "reschedule_requested"] as const;

export const updateStatus = adminAction("appointments.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  const to = str(form, "to") as (typeof STATUS_TARGETS)[number];
  if (!UUID_RE.test(id) || !STATUS_TARGETS.includes(to)) return { ok: false, message: a.common.serverError };
  const res = await changeStatus(id, to, { id: user.id, label: user.email }, { reason: str(form, "reason", 500) });
  if (!res.ok) {
    const msg =
      res.code === "CONFLICT"
        ? a.appointment.conflict
        : res.code === "NOT_FOUND"
          ? a.appointment.notFound
          : a.appointment.invalidTransition;
    return { ok: false, message: msg };
  }
  flush(id);
  // The button that triggered this disappears with the new status, so confirm on the page itself.
  redirect(`/admin/appointments/${id}?done=${to}`);
});

export const saveNotes = adminAction("appointments.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (!UUID_RE.test(id)) return { ok: false, message: a.common.serverError };
  await updateAdminNotes(id, str(form, "adminNotes", 4000), { id: user.id, label: user.email });
  return { ok: true, message: a.common.saved };
});

export const moveAppointment = adminAction("appointments.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  const date = str(form, "date");
  const minutes = hhmmToMinutes(str(form, "time"));
  const doctorId = str(form, "doctorId");
  if (!UUID_RE.test(id) || !isValidDateKey(date) || minutes === null)
    return { ok: false, message: a.newAppointment.invalidTime, errors: { time: a.newAppointment.invalidTime } };
  const settings = await getSettings();
  const start = zonedToUtc(date, minutes, settings.timezone);
  if (!start) return { ok: false, message: a.newAppointment.invalidTime };
  const res = await reschedule(
    id,
    {
      start,
      doctorId: UUID_RE.test(doctorId) ? doctorId : undefined,
      ignoreSchedule: bool(form, "override"),
      notify: bool(form, "notify"),
    },
    { id: user.id, label: user.email },
  );
  if (!res.ok) {
    const msg =
      res.code === "CONFLICT"
        ? a.appointment.conflict
        : res.code === "OUTSIDE_AVAILABILITY"
          ? a.appointment.outsideAvailability
          : res.code === "NOT_FOUND"
            ? a.appointment.notFound
            : a.appointment.invalidTransition;
    return { ok: false, message: msg };
  }
  flush(id);
  return { ok: true, message: a.appointment.rescheduled };
});

export const createManual = adminAction("appointments.manage", async ({ user, a, form }) => {
  const settings = await getSettings();
  const errors: Record<string, string> = {};
  const fullName = str(form, "fullName", 120);
  const phoneRaw = str(form, "phone", 32);
  const email = str(form, "email", 200);
  const serviceId = str(form, "serviceId");
  const doctorId = str(form, "doctorId");
  const date = str(form, "date");
  const minutes = hhmmToMinutes(str(form, "time"));
  const locale = str(form, "locale") === "en" ? "en" : "sq";
  if (fullName.length < 2) errors.fullName = a.common.required;
  if (!normalizePhone(phoneRaw, settings.country)) errors.phone = a.newAppointment.invalidPhone;
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.email = a.newAppointment.invalidEmail;
  if (!UUID_RE.test(serviceId)) errors.serviceId = a.common.required;
  if (!UUID_RE.test(doctorId)) errors.doctorId = a.common.required;
  if (!isValidDateKey(date)) errors.date = a.newAppointment.invalidTime;
  if (minutes === null) errors.time = a.newAppointment.invalidTime;
  if (Object.keys(errors).length) return { ok: false, message: a.services.invalid, errors };
  const start = zonedToUtc(date, minutes!, settings.timezone);
  if (!start) return { ok: false, message: a.newAppointment.invalidTime, errors: { time: a.newAppointment.invalidTime } };

  const override = bool(form, "override");
  const res = await createBooking(
    {
      serviceId,
      doctorId,
      start,
      locale,
      source: "admin",
      forceStatus: str(form, "status") === "pending" ? "pending" : "confirmed",
      actor: { id: user.id, label: user.email },
      ignoreSchedule: override,
      patient: { fullName, phone: phoneRaw, email, note: str(form, "note", 1000) },
    },
    settings,
  );
  if (!res.ok) {
    const msg =
      res.code === "SLOT_UNAVAILABLE" ? (override ? a.appointment.conflict : a.appointment.outsideAvailability) : a.common.serverError;
    return { ok: false, message: msg };
  }
  // Staff may choose not to message the patient (e.g. booked in person).
  if (!bool(form, "notify")) {
    await db()
      .update(schema.notifications)
      .set({ status: "skipped", lastError: "Not sent: staff chose not to notify" })
      .where(eq(schema.notifications.appointmentId, res.appointmentId));
  } else flush(res.appointmentId);
  redirect(`/admin/appointments/${res.appointmentId}?created=1`);
});

export const erasePatient = adminAction("patients.erase", async ({ user, a, form }) => {
  const patientId = str(form, "patientId");
  if (!UUID_RE.test(patientId)) return { ok: false, message: a.common.serverError };
  const { anonymisePatient } = await import("@/lib/privacy");
  await anonymisePatient(patientId, { id: user.id, label: user.email });
  return { ok: true, message: a.appointment.patientErased };
});
