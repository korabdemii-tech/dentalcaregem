"use server";

import { eq } from "drizzle-orm";
import { adminAction, bool, int, str } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import type { OpeningHoursRow } from "@/lib/db/schema";
import { audit } from "@/lib/audit";
import { normalizePhone } from "@/lib/validation";
import { hhmmToMinutes } from "@/lib/time";

function validTimezone(tz: string) {
  try {
    new Intl.DateTimeFormat("en", { timeZone: tz });
    return /\//.test(tz) || tz === "UTC";
  } catch {
    return false;
  }
}

export const saveSettings = adminAction("settings.manage", async ({ user, a, form }) => {
  const s = a.settings;
  const errors: Record<string, string> = {};
  const country = str(form, "country", 2).toUpperCase();
  if (country && !/^[A-Z]{2}$/.test(country)) errors.country = s.countryHint;
  const phoneRaw = str(form, "phone", 40);
  const waRaw = str(form, "whatsapp", 40);
  const phone = phoneRaw ? normalizePhone(phoneRaw, country || null) : null;
  const whatsapp = waRaw ? normalizePhone(waRaw, country || null) : null;
  if (phoneRaw && !phone) errors.phone = a.newAppointment.invalidPhone;
  if (waRaw && !whatsapp) errors.whatsapp = a.newAppointment.invalidPhone;
  const email = str(form, "email", 200);
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) errors.email = a.newAppointment.invalidEmail;
  const privacyEmail = str(form, "privacyContactEmail", 200);
  if (privacyEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(privacyEmail)) errors.privacyContactEmail = a.newAppointment.invalidEmail;
  const timezone = str(form, "timezone", 64);
  if (!validTimezone(timezone)) errors.timezone = s.invalidTimezone;
  const minNoticeHours = int(form, "minNoticeHours", 0, 720);
  const horizonDays = int(form, "horizonDays", 1, 365);
  const slotInterval = int(form, "slotIntervalMinutes", 5, 120);
  const retention = int(form, "dataRetentionMonths", 1, 240);
  if (minNoticeHours === null) errors.minNoticeHours = a.common.required;
  if (horizonDays === null) errors.horizonDays = a.common.required;
  if (slotInterval === null) errors.slotIntervalMinutes = a.common.required;
  if (retention === null) errors.dataRetentionMonths = a.common.required;
  const urls: Record<string, string> = {};
  for (const k of ["mapsUrl", "instagram", "facebook", "tiktok", "linkedin"]) {
    const v = str(form, k, 500);
    if (v && !/^https:\/\/[^\s]+$/.test(v)) errors[k] = "https://…";
    else if (v) urls[k] = v;
  }
  const lat = str(form, "latitude", 20);
  const lng = str(form, "longitude", 20);
  if (lat && !/^-?\d{1,2}(\.\d+)?$/.test(lat)) errors.latitude = a.services.invalid;
  if (lng && !/^-?\d{1,3}(\.\d+)?$/.test(lng)) errors.longitude = a.services.invalid;

  const openingHours: OpeningHoursRow[] = [];
  for (let d = 0; d < 7; d++) {
    const o = str(form, `oh${d}_open`);
    const c = str(form, `oh${d}_close`);
    if (!o && !c) continue;
    const om = hhmmToMinutes(o);
    const cm = hhmmToMinutes(c);
    if (om === null || cm === null || cm <= om) {
      errors[`oh${d}_close`] = a.doctors.invalidSchedule;
      continue;
    }
    openingHours.push({ day: d, open: o, close: c });
  }
  if (Object.keys(errors).length) return { ok: false, message: s.invalid, errors };

  await db()
    .update(schema.clinicSettings)
    .set({
      clinicName: str(form, "clinicName", 120) || "GemDental Care",
      phone,
      whatsapp,
      email: email || null,
      addressLine: { sq: str(form, "addressSq", 200), en: str(form, "addressEn", 200) },
      city: str(form, "city", 80) || null,
      postalCode: str(form, "postalCode", 20) || null,
      country: country || null,
      mapsUrl: urls.mapsUrl ?? null,
      latitude: lat || null,
      longitude: lng || null,
      openingHours: openingHours.length ? openingHours : null,
      social: { instagram: urls.instagram, facebook: urls.facebook, tiktok: urls.tiktok, linkedin: urls.linkedin },
      timezone,
      onlineBookingEnabled: bool(form, "onlineBookingEnabled"),
      autoConfirm: bool(form, "autoConfirm"),
      minNoticeMinutes: minNoticeHours! * 60,
      horizonDays: horizonDays!,
      slotIntervalMinutes: slotInterval!,
      legalEntityName: str(form, "legalEntityName", 200) || null,
      privacyContactEmail: privacyEmail || null,
      dataRetentionMonths: retention!,
      previewNotice: bool(form, "previewNotice"),
      updatedAt: new Date(),
    })
    .where(eq(schema.clinicSettings.id, 1));
  await audit({ actorId: user.id, actorLabel: user.email, action: "settings.updated", entityType: "settings", entityId: "1" });
  return { ok: true, message: s.saved };
});
