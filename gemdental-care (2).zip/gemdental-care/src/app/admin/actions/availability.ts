"use server";

import { and, eq, gt, inArray, lt } from "drizzle-orm";
import { adminAction, bool, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { BLOCKING_STATUSES } from "@/lib/db/schema";
import { getSettings } from "@/lib/settings";
import { addDays, hhmmToMinutes, isValidDateKey, startOfZonedDay, zonedToUtc } from "@/lib/time";
import { audit } from "@/lib/audit";
import { fmt } from "@/lib/i18n/format";

const KINDS = ["closure", "holiday", "time_off", "block"] as const;

export const addException = adminAction("schedule.block", async ({ user, a, form }) => {
  const settings = await getSettings();
  const tz = settings.timezone;
  const doctorId = str(form, "doctorId");
  const kind = str(form, "kind") as (typeof KINDS)[number];
  const startDate = str(form, "startDate");
  const endDate = str(form, "endDate") || startDate;
  const allDay = bool(form, "allDay");
  if (!KINDS.includes(kind) || !isValidDateKey(startDate) || !isValidDateKey(endDate))
    return { ok: false, message: a.availability.invalidRange, errors: { startDate: a.availability.invalidRange } };
  let startsAt: Date | null;
  let endsAt: Date | null;
  if (allDay) {
    startsAt = startOfZonedDay(startDate, tz);
    endsAt = startOfZonedDay(addDays(endDate, 1), tz);
  } else {
    const sm = hhmmToMinutes(str(form, "startTime"));
    const em = hhmmToMinutes(str(form, "endTime"));
    startsAt = sm === null ? null : zonedToUtc(startDate, sm, tz);
    endsAt = em === null ? null : em === 1440 ? startOfZonedDay(addDays(endDate, 1), tz) : zonedToUtc(endDate, em, tz);
  }
  if (!startsAt || !endsAt || endsAt <= startsAt)
    return { ok: false, message: a.availability.invalidRange, errors: { endDate: a.availability.invalidRange } };
  const targetDoctor = UUID_RE.test(doctorId) ? doctorId : null;
  const [row] = await db()
    .insert(schema.availabilityExceptions)
    .values({
      doctorId: kind === "closure" ? null : targetDoctor,
      kind,
      startsAt,
      endsAt,
      reason: str(form, "reason", 300) || null,
      createdBy: user.id,
    })
    .returning();
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "availability.blocked",
    entityType: "availability_exception",
    entityId: row.id,
    details: { kind, startsAt: startsAt.toISOString(), endsAt: endsAt.toISOString() },
  });
  const conflicts = await db()
    .select({ id: schema.appointments.id })
    .from(schema.appointments)
    .where(
      and(
        inArray(schema.appointments.status, [...BLOCKING_STATUSES]),
        lt(schema.appointments.startsAt, endsAt),
        gt(schema.appointments.endsAt, startsAt),
        row.doctorId ? eq(schema.appointments.doctorId, row.doctorId) : undefined,
      ),
    );
  return {
    ok: true,
    message: conflicts.length ? `${a.availability.added} ${fmt(a.availability.affects, { n: conflicts.length })}` : a.availability.added,
  };
});

export const removeException = adminAction("schedule.block", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (!UUID_RE.test(id)) return { ok: false, message: a.common.serverError };
  await db().delete(schema.availabilityExceptions).where(eq(schema.availabilityExceptions.id, id));
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "availability.unblocked",
    entityType: "availability_exception",
    entityId: id,
  });
  return { ok: true, message: a.availability.removed };
});
