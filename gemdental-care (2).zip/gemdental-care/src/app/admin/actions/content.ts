"use server";

import { eq } from "drizzle-orm";
import { adminAction, bool, int, str, UUID_RE } from "@/lib/admin/action";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";
import { storeImageUpload } from "@/lib/admin/media";
import { SITE_IMAGE_SLOTS } from "@/lib/content";
import { GALLERY_KINDS, RESULT_CONCERNS, type GalleryKind, type ResultConcern } from "@/lib/db/schema";

// ── Site images ─────────────────────────────────────────────

export const saveSiteImage = adminAction("content.manage", async ({ user, a, form }) => {
  const slot = str(form, "slot") as (typeof SITE_IMAGE_SLOTS)[number];
  if (!SITE_IMAGE_SLOTS.includes(slot)) return { ok: false, message: a.common.serverError };
  const alt = { sq: str(form, "altSq", 200), en: str(form, "altEn", 200) };
  const authentic = bool(form, "authentic");
  if (bool(form, "clear")) {
    await db().delete(schema.siteImages).where(eq(schema.siteImages.slot, slot));
    await audit({ actorId: user.id, actorLabel: user.email, action: "site_image.cleared", entityType: "site_image", entityId: slot });
    return { ok: true, message: a.common.saved };
  }
  const file = form.get("file");
  if (file && typeof file !== "string" && file.size > 0) {
    const res = await storeImageUpload(file, { alt, authentic, label: `site:${slot}` });
    if (!res.ok) return { ok: false, message: res.reason === "size" ? a.content.images.tooLarge : a.content.images.invalidType };
    await db()
      .insert(schema.siteImages)
      .values({ slot, mediaId: res.id })
      .onConflictDoUpdate({ target: schema.siteImages.slot, set: { mediaId: res.id, updatedAt: new Date() } });
    await audit({ actorId: user.id, actorLabel: user.email, action: "site_image.uploaded", entityType: "site_image", entityId: slot });
    return { ok: true, message: a.content.images.uploaded };
  }
  // Update alt text / authenticity on the existing image.
  const current = await db().select().from(schema.siteImages).where(eq(schema.siteImages.slot, slot));
  if (current[0]?.mediaId) await db().update(schema.media).set({ alt, authentic }).where(eq(schema.media.id, current[0].mediaId));
  return { ok: true, message: a.common.saved };
});

// ── FAQ ─────────────────────────────────────────────────────

export const saveFaq = adminAction("content.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (bool(form, "delete") && UUID_RE.test(id)) {
    await db().delete(schema.faqs).where(eq(schema.faqs.id, id));
    await audit({ actorId: user.id, actorLabel: user.email, action: "faq.deleted", entityType: "faq", entityId: id });
    return { ok: true, message: a.content.faq.deleted };
  }
  const verified = bool(form, "verified");
  const published = bool(form, "published");
  if (published && !verified) return { ok: false, message: a.content.faq.needsVerify, errors: { published: a.content.faq.needsVerify } };
  const values = {
    topic: str(form, "topic", 40) || "general",
    question: { sq: str(form, "questionSq", 300), en: str(form, "questionEn", 300) },
    answer: { sq: str(form, "answerSq", 3000), en: str(form, "answerEn", 3000) },
    verified,
    published,
    sortOrder: int(form, "sortOrder", 0, 999) ?? 0,
    updatedAt: new Date(),
  };
  if (!values.question.sq && !values.question.en)
    return { ok: false, message: a.services.invalid, errors: { questionSq: a.common.required } };
  if (UUID_RE.test(id)) await db().update(schema.faqs).set(values).where(eq(schema.faqs.id, id));
  else await db().insert(schema.faqs).values(values);
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "faq.saved",
    entityType: "faq",
    entityId: UUID_RE.test(id) ? id : null,
    details: { published },
  });
  return { ok: true, message: a.content.faq.saved };
});

// ── Reviews ─────────────────────────────────────────────────

export const saveReview = adminAction("content.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (bool(form, "delete") && UUID_RE.test(id)) {
    await db().delete(schema.testimonials).where(eq(schema.testimonials.id, id));
    await audit({ actorId: user.id, actorLabel: user.email, action: "review.deleted", entityType: "review", entityId: id });
    return { ok: true, message: a.content.reviews.deleted };
  }
  const verified = bool(form, "verified");
  const published = bool(form, "published");
  if (published && !verified)
    return { ok: false, message: a.content.reviews.needsVerify, errors: { published: a.content.reviews.needsVerify } };
  const authorName = str(form, "authorName", 80);
  const body = str(form, "body", 1500);
  const source = str(form, "source", 80);
  const errors: Record<string, string> = {};
  if (!authorName) errors.authorName = a.common.required;
  if (!body) errors.body = a.common.required;
  if (!source) errors.source = a.common.required;
  if (Object.keys(errors).length) return { ok: false, message: a.services.invalid, errors };
  const rating = int(form, "rating", 1, 5);
  const sourceUrl = str(form, "sourceUrl", 500);
  const values = {
    authorName,
    body,
    locale: str(form, "locale") === "en" ? "en" : "sq",
    rating,
    source,
    sourceUrl: /^https:\/\//.test(sourceUrl) ? sourceUrl : null,
    reviewDate: str(form, "reviewDate", 20) || null,
    verified,
    published,
    sortOrder: int(form, "sortOrder", 0, 999) ?? 0,
  };
  if (UUID_RE.test(id)) await db().update(schema.testimonials).set(values).where(eq(schema.testimonials.id, id));
  else await db().insert(schema.testimonials).values(values);
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "review.saved",
    entityType: "review",
    entityId: UUID_RE.test(id) ? id : null,
    details: { published },
  });
  return { ok: true, message: a.content.reviews.saved };
});

// ── Before & after cases ────────────────────────────────────

export const saveCase = adminAction("content.manage", async ({ user, a, form }) => {
  const id = str(form, "id");
  if (bool(form, "delete") && UUID_RE.test(id)) {
    await db().delete(schema.resultCases).where(eq(schema.resultCases.id, id));
    await audit({ actorId: user.id, actorLabel: user.email, action: "case.deleted", entityType: "result_case", entityId: id });
    return { ok: true, message: a.content.results.deleted };
  }
  const existing = UUID_RE.test(id) ? (await db().select().from(schema.resultCases).where(eq(schema.resultCases.id, id)))[0] : undefined;
  const title = { sq: str(form, "titleSq", 120), en: str(form, "titleEn", 120) };
  let beforeMediaId = existing?.beforeMediaId ?? null;
  let afterMediaId = existing?.afterMediaId ?? null;
  for (const [field, set] of [
    ["before", (v: string) => (beforeMediaId = v)],
    ["after", (v: string) => (afterMediaId = v)],
  ] as const) {
    const f = form.get(field);
    if (f && typeof f !== "string" && f.size > 0) {
      const res = await storeImageUpload(f, { alt: title, authentic: true, label: `case:${field}` });
      if (!res.ok) return { ok: false, message: res.reason === "size" ? a.content.images.tooLarge : a.content.images.invalidType };
      set(res.id);
    }
  }
  const consentObtained = bool(form, "consentObtained");
  const published = bool(form, "published");
  if (published && (!consentObtained || !beforeMediaId || !afterMediaId))
    return { ok: false, message: a.content.results.needsConsent, errors: { published: a.content.results.needsConsent } };
  const serviceId = str(form, "serviceId");
  const concern = str(form, "concern") as ResultConcern;
  const values = {
    title,
    concern: RESULT_CONCERNS.includes(concern) ? concern : null,
    description: { sq: str(form, "descriptionSq", 600), en: str(form, "descriptionEn", 600) },
    serviceId: UUID_RE.test(serviceId) ? serviceId : null,
    beforeMediaId,
    afterMediaId,
    consentObtained,
    consentDate: str(form, "consentDate", 20) || null,
    consentReference: str(form, "consentReference", 200) || null,
    approvedBy: str(form, "approvedBy", 120) || null,
    published,
  };
  if (existing) await db().update(schema.resultCases).set(values).where(eq(schema.resultCases.id, existing.id));
  else await db().insert(schema.resultCases).values(values);
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "case.saved",
    entityType: "result_case",
    entityId: existing?.id ?? null,
    details: { published, consentObtained },
  });
  return { ok: true, message: a.content.results.saved };
});

// ── Gallery photos (finished smiles, tooth gems) ────────────

export const saveGalleryPhoto = adminAction("content.manage", async ({ user, a, form }) => {
  const g = a.content.gallery;
  const id = str(form, "id");
  if (bool(form, "delete") && UUID_RE.test(id)) {
    const [row] = await db().delete(schema.galleryPhotos).where(eq(schema.galleryPhotos.id, id)).returning();
    if (row) await db().delete(schema.media).where(eq(schema.media.id, row.mediaId));
    await audit({ actorId: user.id, actorLabel: user.email, action: "gallery_photo.deleted", entityType: "gallery_photo", entityId: id });
    return { ok: true, message: g.deleted };
  }
  const existing = UUID_RE.test(id)
    ? (await db().select().from(schema.galleryPhotos).where(eq(schema.galleryPhotos.id, id)))[0]
    : undefined;
  const alt = { sq: str(form, "altSq", 200), en: str(form, "altEn", 200) };
  let mediaId = existing?.mediaId ?? null;
  const f = form.get("photo");
  if (f && typeof f !== "string" && f.size > 0) {
    const res = await storeImageUpload(f, { alt, authentic: true, label: "gallery" });
    if (!res.ok) return { ok: false, message: res.reason === "size" ? a.content.images.tooLarge : a.content.images.invalidType };
    mediaId = res.id;
  } else if (existing) {
    await db().update(schema.media).set({ alt }).where(eq(schema.media.id, existing.mediaId));
  }
  if (!mediaId) return { ok: false, message: g.needsPhoto, errors: { photo: g.needsPhoto } };
  const consentObtained = bool(form, "consentObtained");
  const published = bool(form, "published");
  if (published && !consentObtained) return { ok: false, message: g.needsConsent, errors: { published: g.needsConsent } };
  const kind = str(form, "kind") as GalleryKind;
  const values = {
    mediaId,
    kind: GALLERY_KINDS.includes(kind) ? kind : ("smile" as const),
    caption: { sq: str(form, "captionSq", 160), en: str(form, "captionEn", 160) },
    consentObtained,
    consentDate: str(form, "consentDate", 20) || null,
    consentReference: str(form, "consentReference", 200) || null,
    approvedBy: str(form, "approvedBy", 120) || null,
    published,
  };
  if (existing) {
    await db().update(schema.galleryPhotos).set(values).where(eq(schema.galleryPhotos.id, existing.id));
    // A replaced photo leaves its old image unused.
    if (existing.mediaId !== mediaId) await db().delete(schema.media).where(eq(schema.media.id, existing.mediaId));
  } else await db().insert(schema.galleryPhotos).values(values);
  await audit({
    actorId: user.id,
    actorLabel: user.email,
    action: "gallery_photo.saved",
    entityType: "gallery_photo",
    entityId: existing?.id ?? null,
    details: { published, consentObtained },
  });
  return { ok: true, message: g.saved };
});
