import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import "../globals.css";
import { getAdminDict } from "@/lib/admin/i18n";
import { getCurrentAdmin } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

const jost = localFont({ src: "../../fonts/jost-var.woff2", variable: "--font-jost", weight: "300 600", display: "swap" });
const cormorant = localFont({
  src: [{ path: "../../fonts/cormorant-garamond-latin-500-normal.woff2", weight: "500", style: "normal" }],
  variable: "--font-cormorant",
  display: "swap",
});

export async function generateMetadata(): Promise<Metadata> {
  const user = await getCurrentAdmin();
  const { a } = await getAdminDict(user?.locale);
  return { title: `${a.brand} · GemDental Care`, robots: { index: false, follow: false } };
}
export const viewport: Viewport = { themeColor: "#4F3F4A" };

export default async function AdminRootLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentAdmin();
  const { tag } = await getAdminDict(user?.locale);
  return (
    <html lang={tag} className={`${jost.variable} ${cormorant.variable}`}>
      <body className="admin-surface min-h-dvh text-[0.9375rem]">{children}</body>
    </html>
  );
}
