import Link from "next/link";
import { getCurrentAdmin } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";

export default async function Forbidden() {
  const user = await getCurrentAdmin();
  const { a } = await getAdminDict(user?.locale);
  return (
    <main className="mx-auto max-w-lg px-6 py-24 text-center">
      <p className="font-display text-champagne-ink text-xl">403</p>
      <h1 className="font-display text-plum mt-2 text-3xl">{a.forbidden.title}</h1>
      <p className="text-ink-muted mt-4">{a.forbidden.body}</p>
      <Link href="/admin" className="btn btn-primary mt-8">
        {a.forbidden.back}
      </Link>
    </main>
  );
}
