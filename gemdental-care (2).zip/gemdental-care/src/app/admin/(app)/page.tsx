import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { overviewStats } from "@/lib/admin/queries";
import { fmt } from "@/lib/i18n/format";
import { AppointmentList } from "@/components/admin/AppointmentList";
import { PageTitle } from "@/components/admin/fields";

export default async function Overview() {
  const user = await requireUser("appointments.view");
  const { a, locale, tag } = await getAdminDict(user.locale);
  const s = await overviewStats();
  const tz = s.settings.timezone;
  const tiles: [string, number | string, string?][] = [
    [a.overview.today, s.todayCount, "/admin/calendar?view=day"],
    [a.overview.pending, s.pending, "/admin/appointments?status=pending&upcoming=1"],
    [a.overview.confirmed, s.confirmed, "/admin/appointments?status=confirmed&upcoming=1"],
    [a.overview.upcoming, s.upcoming, "/admin/calendar?view=week"],
    [a.overview.cancellations, s.cancelled, "/admin/appointments?status=cancelled"],
    [a.overview.openSlots, s.openSlots ?? "—", "/admin/calendar?view=day"],
  ];
  return (
    <>
      <PageTitle
        title={fmt(a.overview.greeting, { name: user.name.split(" ")[0] })}
        lead={
          !s.settings.onlineBookingEnabled
            ? a.overview.bookingOff
            : s.settings.autoConfirm
              ? a.overview.autoConfirmOn
              : a.overview.autoConfirmOff
        }
        actions={
          <Link href="/admin/appointments/new" className="btn btn-primary btn-sm">
            {a.nav.newAppointment}
          </Link>
        }
      />
      {s.failures > 0 && (
        <p
          role="alert"
          className="bg-error-bg text-error mb-6 flex flex-wrap items-center justify-between gap-3 rounded-lg px-4 py-3 text-sm"
        >
          {fmt(a.overview.failures, { n: s.failures })}
          <Link href="/admin/notifications#failures" className="link-quiet font-medium">
            {a.overview.failuresLink}
          </Link>
        </p>
      )}
      <ul className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {tiles.map(([label, value, href]) => (
          <li key={label}>
            <Link href={href!} className="border-line hover:border-plum/40 block h-full rounded-lg border bg-white p-4">
              <span className="text-ink-muted block text-xs">{label}</span>
              <span className="text-plum mt-2 block text-3xl font-light tabular-nums">{value}</span>
            </Link>
          </li>
        ))}
      </ul>
      <div className="mt-10 grid gap-10 2xl:grid-cols-2">
        <section>
          <h2 className="text-plum mb-4 text-lg font-medium">{a.overview.pendingList}</h2>
          <AppointmentList rows={s.pendingList} a={a} tz={tz} tag={tag} locale={locale} empty={a.overview.noPending} />
        </section>
        <section>
          <h2 className="text-plum mb-4 text-lg font-medium">{a.overview.todayList}</h2>
          <AppointmentList rows={s.todayList} a={a} tz={tz} tag={tag} locale={locale} empty={a.overview.noToday} showDate={false} />
        </section>
      </div>
    </>
  );
}
