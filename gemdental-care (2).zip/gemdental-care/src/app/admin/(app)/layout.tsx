import Link from "next/link";
import { count, eq, and, gt } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { can } from "@/lib/auth/permissions";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { Logo } from "@/components/brand/Logo";
import { AdminNav, type NavItem } from "@/components/admin/AdminNav";
import { logout, setAdminLanguage } from "../actions/auth";
import { enabledLocales, LOCALE_LABEL, defaultLocale } from "@/lib/i18n/config";

export default async function AdminShell({ children }: { children: React.ReactNode }) {
  const user = await requireUser();
  const { a, locale } = await getAdminDict(user.locale);
  const [{ n: pending }] = await db()
    .select({ n: count() })
    .from(schema.appointments)
    .where(and(eq(schema.appointments.status, "pending"), gt(schema.appointments.startsAt, new Date())));

  const items: NavItem[] = [
    { href: "/admin", label: a.nav.overview },
    { href: "/admin/calendar", label: a.nav.calendar },
    { href: "/admin/appointments", label: a.nav.appointments, badge: pending },
    { href: "/admin/appointments/new", label: a.nav.newAppointment },
    { href: "/admin/availability", label: a.nav.availability },
  ];
  if (can(user.role, "services.manage")) items.push({ href: "/admin/services", label: a.nav.services });
  if (can(user.role, "doctors.manage")) items.push({ href: "/admin/doctors", label: a.nav.doctors });
  if (can(user.role, "content.manage")) items.push({ href: "/admin/content", label: a.nav.content });
  if (can(user.role, "notifications.manage")) items.push({ href: "/admin/notifications", label: a.nav.notifications });
  if (can(user.role, "settings.manage")) items.push({ href: "/admin/settings", label: a.nav.settings });
  if (can(user.role, "users.manage")) items.push({ href: "/admin/users", label: a.nav.users });
  if (can(user.role, "audit.view")) items.push({ href: "/admin/audit", label: a.nav.audit });

  const side = (
    <>
      <AdminNav items={items} label={a.nav.menu} />
      <div className="mt-8 space-y-3 border-t border-white/10 pt-6 text-sm">
        <Link href="/admin/account" className="text-mauve-light block rounded-md px-3 py-1 hover:text-white">
          {user.name}
          <span className="block text-xs opacity-75">{user.email}</span>
        </Link>
        <form action={setAdminLanguage} className="flex gap-1 px-3" aria-label={a.nav.language}>
          {enabledLocales().map((l) => (
            <button
              key={l}
              name="locale"
              value={l}
              aria-pressed={l === locale}
              className="text-mauve-light aria-pressed:border-champagne aria-pressed:text-champagne rounded-full border border-white/20 px-3 py-1 text-xs"
            >
              {LOCALE_LABEL[l]}
            </button>
          ))}
        </form>
        <Link href={`/${defaultLocale()}`} target="_blank" className="text-mauve-light block rounded-md px-3 py-2 hover:text-white">
          {a.nav.viewSite} ↗
        </Link>
        <form action={logout}>
          <button className="text-mauve-light w-full rounded-md px-3 py-2 text-left hover:bg-white/5 hover:text-white">
            {a.nav.signOut}
          </button>
        </form>
      </div>
    </>
  );

  return (
    <div className="lg:grid lg:min-h-dvh lg:grid-cols-[16rem_1fr]">
      {/* Desktop sidebar */}
      <aside className="on-dark bg-plum-deep sticky top-0 hidden h-dvh overflow-y-auto px-3 py-6 lg:block">
        <Link href="/admin" className="mb-8 block px-3">
          <Logo tone="white" height={34} alt="GemDental Care" />
          <span className="text-mauve-light mt-2 block text-xs">{a.brand}</span>
        </Link>
        {side}
      </aside>
      {/* Mobile top bar */}
      <div className="on-dark bg-plum-deep sticky top-0 z-30 lg:hidden">
        <details className="group">
          <summary className="flex cursor-pointer list-none items-center justify-between px-4 py-3">
            <Logo tone="white" height={28} alt="GemDental Care" />
            <span className="text-mauve-light flex items-center gap-2 text-sm">
              {a.nav.menu}
              {pending > 0 && <span className="bg-champagne text-plum-deep rounded-full px-2 text-xs">{pending}</span>}
            </span>
          </summary>
          <div className="max-h-[80dvh] overflow-y-auto px-3 pb-6">{side}</div>
        </details>
      </div>
      <main id="main" className="min-w-0 px-4 py-8 sm:px-8 lg:px-10 lg:py-10">
        {children}
      </main>
    </div>
  );
}
