import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { asc, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { UUID_RE } from "@/lib/admin/action";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, TextArea, TextField } from "@/components/admin/fields";
import { deleteService, saveService } from "../../../actions/services";

export default async function ServiceEdit({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ saved?: string }>;
}) {
  const user = await requireUser("services.manage");
  const { a } = await getAdminDict(user.locale);
  const { id } = await params;
  const isNew = id === "new";
  if (!isNew && !UUID_RE.test(id)) notFound();
  const s = isNew ? null : (await db().select().from(schema.services).where(eq(schema.services.id, id)))[0];
  if (!isNew && !s) notFound();
  const doctors = await db().select().from(schema.doctors).orderBy(asc(schema.doctors.sortOrder));
  const assigned = s
    ? new Set((await db().select().from(schema.doctorServices).where(eq(schema.doctorServices.serviceId, s.id))).map((r) => r.doctorId))
    : new Set<string>();
  const { saved } = await searchParams;

  return (
    <>
      <Link href="/admin/services" className="link-quiet text-ink-muted text-sm">
        ← {a.services.title}
      </Link>
      <div className="mt-4">
        <PageTitle title={s ? s.name.sq || s.name.en || "" : a.services.new} />
      </div>
      {saved && (
        <p role="status" className="bg-success-bg text-success mb-6 rounded-md px-3 py-2 text-sm">
          {a.services.created}
        </p>
      )}
      <AdminForm action={saveService} className="max-w-4xl space-y-6">
        <input type="hidden" name="id" value={s?.id ?? ""} />
        <Card>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField name="nameSq" label={a.services.nameSq} defaultValue={s?.name.sq} required />
            <TextField name="nameEn" label={a.services.nameEn} defaultValue={s?.name.en} />
            <TextField
              name="slug"
              label={a.services.slug}
              defaultValue={s?.slug}
              required
              hint={a.services.slugHint}
              pattern="[a-z0-9-]+"
            />
            <TextField name="sortOrder" type="number" label={a.services.sortOrder} defaultValue={s?.sortOrder ?? 0} min={0} max={999} />
            <TextArea name="summarySq" label={a.services.summarySq} defaultValue={s?.summary.sq} rows={2} />
            <TextArea name="summaryEn" label={a.services.summaryEn} defaultValue={s?.summary.en} rows={2} />
            <TextArea name="descriptionSq" label={a.services.descriptionSq} defaultValue={s?.description.sq} rows={7} />
            <TextArea name="descriptionEn" label={a.services.descriptionEn} defaultValue={s?.description.en} rows={7} />
          </div>
        </Card>
        <Card>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField
              name="durationMinutes"
              type="number"
              label={a.services.duration}
              defaultValue={s?.durationMinutes ?? 30}
              min={5}
              max={600}
              required
            />
            <TextField
              name="bufferMinutes"
              type="number"
              label={a.services.buffer}
              defaultValue={s?.bufferMinutes ?? 0}
              min={0}
              max={240}
              hint={a.services.bufferHint}
            />
            <TextField name="priceSq" label={a.services.priceSq} defaultValue={s?.price?.sq} />
            <TextField name="priceEn" label={a.services.priceEn} defaultValue={s?.price?.en} />
            <div className="space-y-2.5 sm:col-span-2">
              <Checkbox name="priceVisible" label={a.services.priceVisible} defaultChecked={s?.priceVisible} />
              <Checkbox name="durationVisible" label={a.services.durationVisible} defaultChecked={s?.durationVisible ?? true} />
            </div>
          </div>
        </Card>
        <Card>
          <div className="space-y-3">
            <Checkbox name="confirmed" label={a.services.confirmed} hint={a.services.confirmedHint} defaultChecked={s?.confirmed} />
            <Checkbox name="published" label={a.services.published} defaultChecked={s?.published} />
            <Checkbox name="bookable" label={a.services.bookable} defaultChecked={s?.bookable ?? true} />
            <Checkbox name="isConsultation" label={a.services.consultation} defaultChecked={s?.isConsultation} />
          </div>
          {doctors.length > 0 && (
            <fieldset className="border-line mt-6 border-t pt-5">
              <legend className="field-label">{a.services.doctors}</legend>
              <p className="field-hint mb-3">{a.services.doctorsHint}</p>
              <div className="space-y-2">
                {doctors.map((d) => (
                  <label key={d.id} className="flex items-center gap-3 text-sm">
                    <input type="checkbox" name="doctorIds" value={d.id} defaultChecked={assigned.has(d.id)} className="checkbox" />
                    {d.fullName}
                  </label>
                ))}
              </div>
            </fieldset>
          )}
        </Card>
        <Card title={a.services.image}>
          {s?.imageMediaId ? (
            <div className="mb-4 flex items-center gap-4">
              <Image src={`/media/${s.imageMediaId}`} alt="" width={160} height={100} className="h-24 w-40 rounded object-cover" />
              <Checkbox name="removeImage" label={a.content.images.clear} />
            </div>
          ) : (
            <p className="text-ink-muted mb-4 text-sm">{a.content.images.empty}</p>
          )}
          <label htmlFor="image" className="field-label">
            {s?.imageMediaId ? a.content.images.replace : a.content.images.upload}
          </label>
          <input id="image" name="image" type="file" accept="image/jpeg,image/png,image/webp" className="block text-sm" />
          <div className="mt-3">
            <Checkbox name="imageAuthentic" label={a.content.images.authentic} hint={a.content.images.authenticHint} defaultChecked />
          </div>
        </Card>
        <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
      </AdminForm>
      {s && (
        <AdminForm action={deleteService} confirmText={a.common.confirmDelete} className="border-line mt-10 max-w-4xl border-t pt-6">
          <input type="hidden" name="id" value={s.id} />
          <SubmitButton variant="danger">{a.common.delete}</SubmitButton>
        </AdminForm>
      )}
    </>
  );
}
