import Link from "next/link";
import { asc } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { pick } from "@/lib/i18n/config";
import { PageTitle } from "@/components/admin/fields";

export default async function ServicesAdmin() {
  const user = await requireUser("services.manage");
  const { a, locale } = await getAdminDict(user.locale);
  const services = await db().select().from(schema.services).orderBy(asc(schema.services.sortOrder));
  return (
    <>
      <PageTitle
        title={a.services.title}
        lead={a.services.lead}
        actions={
          <Link href="/admin/services/new" className="btn btn-primary btn-sm">
            {a.services.new}
          </Link>
        }
      />
      <div className="border-line overflow-hidden rounded-lg border bg-white">
        <table className="w-full text-left text-sm">
          <thead className="bg-ivory text-ink-muted text-xs">
            <tr>
              <th scope="col" className="px-4 py-2.5 font-normal">
                {a.services.name}
              </th>
              <th scope="col" className="hidden px-4 py-2.5 font-normal sm:table-cell">
                {a.services.duration}
              </th>
              <th scope="col" className="px-4 py-2.5 font-normal">
                {a.services.status}
              </th>
            </tr>
          </thead>
          <tbody className="divide-line divide-y">
            {services.map((s) => (
              <tr key={s.id} className="hover:bg-ivory relative">
                <td className="px-4 py-3">
                  <Link href={`/admin/services/${s.id}`} className="text-plum font-medium after:absolute after:inset-0">
                    {pick(s.name, locale)}
                  </Link>
                  <span className="text-ink-muted block text-xs">/{s.slug}</span>
                </td>
                <td className="hidden px-4 py-3 tabular-nums sm:table-cell">
                  {s.durationMinutes}
                  {s.bufferMinutes ? ` + ${s.bufferMinutes}` : ""} {a.common.minutes}
                </td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1.5 text-xs">
                    {!s.confirmed && (
                      <span className="bg-warning-bg text-champagne-ink rounded-full px-2 py-0.5">{a.services.unconfirmed}</span>
                    )}
                    <span className={`rounded-full px-2 py-0.5 ${s.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}>
                      {s.published ? a.services.live : a.services.hidden}
                    </span>
                    {!s.bookable && <span className="bg-cream text-ink-muted rounded-full px-2 py-0.5">{a.services.notBookable}</span>}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
