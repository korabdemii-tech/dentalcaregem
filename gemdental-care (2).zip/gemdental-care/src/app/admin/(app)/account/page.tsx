import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, PageTitle, TextField } from "@/components/admin/fields";
import { changeOwnPassword } from "../../actions/users";

export default async function AccountPage() {
  const user = await requireUser();
  const { a } = await getAdminDict(user.locale);
  return (
    <>
      <PageTitle title={a.users.changeOwn} lead={`${user.name} · ${user.email}`} />
      <Card className="max-w-lg">
        <AdminForm action={changeOwnPassword} className="space-y-4" resetOnSuccess>
          <TextField name="currentPassword" type="password" label={a.users.currentPassword} autoComplete="current-password" required />
          <TextField
            name="newPassword"
            type="password"
            label={a.users.newPassword}
            autoComplete="new-password"
            hint={a.users.passwordHint}
            required
          />
          <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
        </AdminForm>
      </Card>
    </>
  );
}
