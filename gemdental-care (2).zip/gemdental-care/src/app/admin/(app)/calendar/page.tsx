import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { appointmentsInRange, doctorsList, exceptionsInRange, type AppointmentRow } from "@/lib/admin/queries";
import { getSettings } from "@/lib/settings";
import { db, schema } from "@/lib/db";
import { inArray } from "drizzle-orm";
import { pick } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { dt, fmtTime } from "@/lib/admin/format";
import { addDays, isValidDateKey, minutesToHHMM, startOfZonedDay, weekdayOf, zonedDateKey, zonedMinutes, daysInMonth } from "@/lib/time";
import { PageTitle, StatusBadge } from "@/components/admin/fields";

type View = "day" | "week" | "month";
const STATUS_BAR: Record<string, string> = {
  pending: "border-l-champagne-ink bg-warning-bg",
  confirmed: "border-l-plum bg-white",
  reschedule_requested: "border-l-champagne-ink bg-warning-bg",
  completed: "border-l-mauve bg-cream",
  no_show: "border-l-error bg-error-bg",
  cancelled: "border-l-line-strong bg-cream opacity-60",
};

export default async function CalendarPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const user = await requireUser("appointments.view");
  const { a, locale, tag } = await getAdminDict(user.locale);
  const sp = await searchParams;
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = zonedDateKey(new Date(), tz);
  const view: View = sp.view === "day" || sp.view === "month" ? sp.view : "week";
  const date = sp.date && isValidDateKey(sp.date) ? sp.date : today;
  const doctors = await doctorsList();
  const doctorId = doctors.some((d) => d.id === sp.doctor) ? sp.doctor : undefined;

  // Range for the view
  let days: string[];
  if (view === "day") days = [date];
  else if (view === "week") {
    const monday = addDays(date, -((weekdayOf(date) + 6) % 7));
    days = Array.from({ length: 7 }, (_, i) => addDays(monday, i));
  } else {
    const y = Number(date.slice(0, 4));
    const m = Number(date.slice(5, 7));
    const first = `${date.slice(0, 7)}-01`;
    const lead = (weekdayOf(first) + 6) % 7;
    const total = Math.ceil((lead + daysInMonth(y, m)) / 7) * 7;
    days = Array.from({ length: total }, (_, i) => addDays(first, i - lead));
  }
  const from = startOfZonedDay(days[0], tz);
  const to = startOfZonedDay(addDays(days[days.length - 1], 1), tz);
  const [appts, blocks, hours] = await Promise.all([
    appointmentsInRange(from, to, doctorId),
    exceptionsInRange(from, to),
    db()
      .select()
      .from(schema.workingHours)
      .where(inArray(schema.workingHours.doctorId, doctors.map((d) => d.id).concat("00000000-0000-0000-0000-000000000000"))),
  ]);
  // One column per doctor who has appointments in range (or is active).
  const columnDoctors = doctors.filter((d) => d.active || appts.some((r) => r.doctorId === d.id));
  const relevantBlocks = blocks.filter((b) => !doctorId || !b.doctorId || b.doctorId === doctorId);
  const byDay = new Map<string, AppointmentRow[]>();
  for (const r of appts) {
    const k = zonedDateKey(r.startsAt, tz);
    byDay.set(k, [...(byDay.get(k) ?? []), r]);
  }

  // Time grid bounds from working hours (fallback 08:00–20:00)
  const startMin = Math.min(8 * 60, ...hours.map((h) => h.startMinute));
  const endMin = Math.max(18 * 60, ...hours.map((h) => h.endMinute));
  const gridStart = Math.floor(startMin / 60) * 60;
  const gridEnd = Math.ceil(endMin / 60) * 60;
  const PX_PER_MIN = 1.1;
  const gridHeight = (gridEnd - gridStart) * PX_PER_MIN;

  const shift = (dir: -1 | 1) => {
    if (view === "day") return addDays(date, dir);
    if (view === "week") return addDays(date, 7 * dir);
    const d = new Date(Date.UTC(Number(date.slice(0, 4)), Number(date.slice(5, 7)) - 1 + dir, 1));
    return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}-01`;
  };
  const href = (patch: Record<string, string | undefined>) => {
    const p = new URLSearchParams(Object.entries({ view, date, doctor: doctorId, ...patch }).filter(([, v]) => v) as [string, string][]);
    return `/admin/calendar?${p}`;
  };
  const dayLabel = (k: string, opts: Intl.DateTimeFormatOptions) =>
    new Intl.DateTimeFormat(tag, { timeZone: "UTC", ...opts }).format(
      Date.UTC(Number(k.slice(0, 4)), Number(k.slice(5, 7)) - 1, Number(k.slice(8, 10))),
    );
  const title =
    view === "month"
      ? dayLabel(date, { month: "long", year: "numeric" })
      : view === "week"
        ? `${dayLabel(days[0], { day: "numeric", month: "short" })} – ${dayLabel(days[6], { day: "numeric", month: "short", year: "numeric" })}`
        : dayLabel(date, { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  const blocksFor = (k: string) => {
    const s = startOfZonedDay(k, tz).getTime();
    const e = startOfZonedDay(addDays(k, 1), tz).getTime();
    return relevantBlocks
      .filter((b) => b.startsAt.getTime() < e && b.endsAt.getTime() > s)
      .map((b) => ({ ...b, s: Math.max(b.startsAt.getTime(), s), e: Math.min(b.endsAt.getTime(), e) }));
  };
  const minuteOf = (ms: number, k: string) => Math.round((ms - startOfZonedDay(k, tz).getTime()) / 60_000);

  return (
    <>
      <PageTitle title={a.calendar.title} />
      <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Link href={href({ date: shift(-1) })} className="btn btn-secondary btn-sm" aria-label={a.common.previous}>
            ‹
          </Link>
          <Link href={href({ date: today })} className="btn btn-secondary btn-sm">
            {a.common.today}
          </Link>
          <Link href={href({ date: shift(1) })} className="btn btn-secondary btn-sm" aria-label={a.common.next}>
            ›
          </Link>
          <h2 className="text-plum ml-2 text-lg font-medium capitalize" aria-live="polite">
            {title}
          </h2>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {doctors.length > 1 && (
            <form className="flex gap-2">
              <input type="hidden" name="view" value={view} />
              <input type="hidden" name="date" value={date} />
              <label htmlFor="doctor" className="sr-only">
                {a.appointments.doctor}
              </label>
              <select id="doctor" name="doctor" defaultValue={doctorId ?? ""} className="input !min-h-10 !py-1.5 text-sm">
                <option value="">{a.calendar.allDoctors}</option>
                {doctors.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.fullName}
                  </option>
                ))}
              </select>
              <button className="btn btn-secondary btn-sm">{a.common.filter}</button>
            </form>
          )}
          <div role="group" aria-label={a.calendar.title} className="border-line-strong inline-flex rounded-full border bg-white p-0.5">
            {(["day", "week", "month"] as View[]).map((v) => (
              <Link
                key={v}
                href={href({ view: v })}
                aria-current={v === view ? "page" : undefined}
                className="text-ink-muted aria-[current=page]:bg-plum rounded-full px-4 py-1.5 text-sm aria-[current=page]:text-white"
              >
                {a.calendar[v]}
              </Link>
            ))}
          </div>
        </div>
      </div>

      {view === "month" ? (
        <div className="border-line overflow-x-auto rounded-lg border bg-white">
          <div className="grid min-w-[42rem] grid-cols-7">
            {days.slice(0, 7).map((k) => (
              <div key={k} className="border-line text-ink-muted border-b px-2 py-2 text-xs capitalize">
                {dayLabel(k, { weekday: "short" })}
              </div>
            ))}
            {days.map((k) => {
              const list = (byDay.get(k) ?? []).filter((r) => r.status !== "cancelled");
              const inMonth = k.slice(0, 7) === date.slice(0, 7);
              const blocked = blocksFor(k).length > 0;
              return (
                <div
                  key={k}
                  className={`border-line min-h-28 border-r border-b p-1.5 ${inMonth ? "" : "bg-ivory/60 text-ink-muted/60"} ${blocked ? "bg-[repeating-linear-gradient(135deg,transparent_0_6px,#F3EEEB_6px_12px)]" : ""}`}
                >
                  <Link
                    href={href({ view: "day", date: k })}
                    className={`hover:bg-cream inline-grid h-7 w-7 place-items-center rounded-full text-sm tabular-nums ${k === today ? "bg-plum hover:bg-plum text-white" : ""}`}
                  >
                    {Number(k.slice(8))}
                  </Link>
                  <ul className="mt-1 space-y-0.5">
                    {list.slice(0, 3).map((r) => (
                      <li key={r.id}>
                        <Link
                          href={`/admin/appointments/${r.id}`}
                          className={`block truncate border-l-2 px-1.5 py-0.5 text-xs ${STATUS_BAR[r.status]}`}
                        >
                          <span className="tabular-nums">{fmtTime(r.startsAt, tz, tag)}</span> {r.patientName}
                        </Link>
                      </li>
                    ))}
                    {list.length > 3 && (
                      <li>
                        <Link href={href({ view: "day", date: k })} className="text-ink-muted px-1.5 text-xs">
                          {fmt(a.calendar.more, { n: list.length - 3 })}
                        </Link>
                      </li>
                    )}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <>
          {/* Agenda list on small screens */}
          <div className="space-y-6 md:hidden">
            {days.map((k) => {
              const list = byDay.get(k) ?? [];
              const bl = blocksFor(k);
              return (
                <section key={k}>
                  <h3 className={`text-sm font-medium capitalize ${k === today ? "text-plum" : "text-ink"}`}>
                    {dayLabel(k, { weekday: "long", day: "numeric", month: "long" })}
                  </h3>
                  <ul className="mt-2 space-y-2">
                    {bl.map((b) => (
                      <li key={b.id} className="bg-cream text-ink-muted rounded-md px-3 py-2 text-xs">
                        {a.calendar.blocked} · {a.availability.kinds[b.kind]} {b.reason ? `· ${b.reason}` : ""}
                      </li>
                    ))}
                    {list.map((r) => (
                      <li key={r.id}>
                        <Link
                          href={`/admin/appointments/${r.id}`}
                          className={`border-line flex items-center justify-between gap-3 rounded-md border border-l-4 px-3 py-2 ${STATUS_BAR[r.status]}`}
                        >
                          <span>
                            <span className="text-plum text-sm font-medium tabular-nums">{fmtTime(r.startsAt, tz, tag)}</span>{" "}
                            <span className="text-sm">{r.patientName}</span>
                            <span className="text-ink-muted block text-xs">{pick(r.serviceName, locale)}</span>
                          </span>
                          <StatusBadge status={r.status} label={a.status[r.status]} />
                        </Link>
                      </li>
                    ))}
                    {!list.length && !bl.length && <li className="text-ink-muted text-xs">—</li>}
                  </ul>
                </section>
              );
            })}
          </div>

          {/* Time grid on tablet/desktop */}
          <div className="border-line hidden overflow-x-auto rounded-lg border bg-white md:block">
            <div
              className="grid"
              style={{ gridTemplateColumns: `3.5rem repeat(${days.length}, minmax(${view === "day" ? "20rem" : "7.5rem"}, 1fr))` }}
            >
              <div className="border-line sticky left-0 z-10 border-b bg-white" />
              {days.map((k) => (
                <Link
                  key={k}
                  href={href({ view: "day", date: k })}
                  className={`border-line hover:bg-ivory border-b border-l px-2 py-2 text-center text-sm capitalize ${k === today ? "text-plum font-medium" : "text-ink-muted"}`}
                >
                  {dayLabel(k, { weekday: "short", day: "numeric" })}
                </Link>
              ))}
              {/* hour labels */}
              <div className="border-line relative" style={{ height: gridHeight }}>
                {Array.from({ length: (gridEnd - gridStart) / 60 }, (_, i) => (
                  <span
                    key={i}
                    className="text-ink-muted absolute right-2 -translate-y-1/2 text-[0.7rem] tabular-nums"
                    style={{ top: i * 60 * PX_PER_MIN }}
                  >
                    {i === 0 ? "" : minutesToHHMM(gridStart + i * 60)}
                  </span>
                ))}
              </div>
              {days.map((k) => (
                <div key={k} className="border-line relative border-l" style={{ height: gridHeight }}>
                  {Array.from({ length: (gridEnd - gridStart) / 30 }, (_, i) => {
                    const m = gridStart + i * 30;
                    return (
                      <Link
                        key={i}
                        href={`/admin/appointments/new?date=${k}&time=${minutesToHHMM(m)}`}
                        aria-label={`${a.nav.newAppointment}: ${k} ${minutesToHHMM(m)}`}
                        tabIndex={-1}
                        className={`hover:bg-champagne-soft/50 absolute inset-x-0 ${i % 2 ? "border-line/70 border-t border-dashed" : "border-line border-t"}`}
                        style={{ top: i * 30 * PX_PER_MIN, height: 30 * PX_PER_MIN }}
                      />
                    );
                  })}
                  {blocksFor(k).map((b) => {
                    const top = Math.max(0, (minuteOf(b.s, k) - gridStart) * PX_PER_MIN);
                    const bottom = Math.min(gridHeight, (minuteOf(b.e, k) - gridStart) * PX_PER_MIN);
                    if (bottom <= top) return null;
                    return (
                      <div
                        key={b.id}
                        className="text-ink-muted pointer-events-none absolute inset-x-0 bg-[repeating-linear-gradient(135deg,transparent_0_6px,#E6DCD3_6px_8px)] px-1.5 pt-1 text-[0.7rem]"
                        style={{ top, height: bottom - top }}
                      >
                        {a.availability.kinds[b.kind]}
                      </div>
                    );
                  })}
                  {(byDay.get(k) ?? []).map((r) => {
                    const sm = zonedMinutes(r.startsAt, tz);
                    const dur = Math.max(20, Math.round((r.endsAt.getTime() - r.startsAt.getTime()) / 60_000));
                    const cols = doctorId ? 1 : Math.max(1, columnDoctors.length);
                    const doctorIdx = doctorId
                      ? 0
                      : Math.max(
                          0,
                          columnDoctors.findIndex((d) => d.id === r.doctorId),
                        );
                    return (
                      <Link
                        key={r.id}
                        href={`/admin/appointments/${r.id}`}
                        className={`border-line hover:border-plum absolute overflow-hidden rounded-sm border border-l-4 px-1.5 py-1 text-xs shadow-[0_1px_0_rgba(56,42,53,0.06)] hover:z-10 ${STATUS_BAR[r.status]}`}
                        style={{
                          top: (sm - gridStart) * PX_PER_MIN + 1,
                          height: dur * PX_PER_MIN - 2,
                          left: `calc(${(doctorIdx / cols) * 100}% + 2px)`,
                          width: `calc(${100 / cols}% - 4px)`,
                        }}
                        title={`${fmtTime(r.startsAt, tz, tag)} ${r.patientName} · ${pick(r.serviceName, locale)} · ${a.status[r.status]}`}
                      >
                        <span className="font-medium tabular-nums">{fmtTime(r.startsAt, tz, tag)}</span> {r.patientName}
                        <span className="text-ink-muted block truncate">{pick(r.serviceName, locale)}</span>
                      </Link>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>
          {appts.length === 0 && <p className="text-ink-muted mt-4 text-sm">{a.calendar.empty}</p>}
        </>
      )}
      <p className="text-ink-muted mt-4 text-xs">{dt(new Date(), tz, tag, { timeZoneName: "long" }).split(", ").pop()}</p>
    </>
  );
}
