import Link from "next/link";
import Image from "next/image";
import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { minutesToHHMM } from "@/lib/time";
import { fmt } from "@/lib/i18n/format";
import { UUID_RE } from "@/lib/admin/action";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, TextArea, TextField } from "@/components/admin/fields";
import { saveDoctor, saveSchedule } from "../../../actions/doctors";

export default async function DoctorEdit({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ saved?: string }>;
}) {
  const user = await requireUser("doctors.manage");
  const { a } = await getAdminDict(user.locale);
  const { id } = await params;
  const isNew = id === "new";
  if (!isNew && !UUID_RE.test(id)) notFound();
  const d = isNew ? null : (await db().select().from(schema.doctors).where(eq(schema.doctors.id, id)))[0];
  if (!isNew && !d) notFound();
  const hours = d ? await db().select().from(schema.workingHours).where(eq(schema.workingHours.doctorId, d.id)) : [];
  const settings = await getSettings();
  const { saved } = await searchParams;
  const list = (v?: string[]) => (v ?? []).join("\n");
  const order = [1, 2, 3, 4, 5, 6, 0];

  return (
    <>
      <Link href="/admin/doctors" className="link-quiet text-ink-muted text-sm">
        ← {a.doctors.title}
      </Link>
      <div className="mt-4">
        <PageTitle title={d?.fullName ?? a.doctors.new} />
      </div>
      {saved && (
        <p role="status" className="bg-success-bg text-success mb-6 rounded-md px-3 py-2 text-sm">
          {a.doctors.created}
        </p>
      )}
      <div className="grid gap-6 2xl:grid-cols-2">
        <Card title={a.doctors.profile}>
          <p className="bg-warning-bg text-champagne-ink mb-5 rounded-md px-3 py-2 text-sm">{a.doctors.credentialsNote}</p>
          <AdminForm action={saveDoctor} className="grid gap-4 sm:grid-cols-2">
            <input type="hidden" name="id" value={d?.id ?? ""} />
            <TextField name="fullName" label={a.doctors.fullName} defaultValue={d?.fullName} required className="sm:col-span-2" />
            <TextField name="titleSq" label={a.doctors.titleSq} defaultValue={d?.title.sq} />
            <TextField name="titleEn" label={a.doctors.titleEn} defaultValue={d?.title.en} />
            <TextArea name="bioSq" label={a.doctors.bioSq} defaultValue={d?.bio.sq} rows={5} />
            <TextArea name="bioEn" label={a.doctors.bioEn} defaultValue={d?.bio.en} rows={5} />
            <TextArea name="experienceSq" label={a.doctors.experienceSq} defaultValue={d?.experience.sq} rows={2} />
            <TextArea name="experienceEn" label={a.doctors.experienceEn} defaultValue={d?.experience.en} rows={2} />
            <TextArea
              name="educationSq"
              label={a.doctors.educationSq}
              defaultValue={list(d?.education.sq)}
              hint={a.doctors.listHint}
              rows={3}
            />
            <TextArea
              name="educationEn"
              label={a.doctors.educationEn}
              defaultValue={list(d?.education.en)}
              hint={a.doctors.listHint}
              rows={3}
            />
            <TextArea name="specialtiesSq" label={a.doctors.specialtiesSq} defaultValue={list(d?.specialties.sq)} rows={3} />
            <TextArea name="specialtiesEn" label={a.doctors.specialtiesEn} defaultValue={list(d?.specialties.en)} rows={3} />
            <TextArea name="qualificationsSq" label={a.doctors.qualificationsSq} defaultValue={list(d?.qualifications.sq)} rows={3} />
            <TextArea name="qualificationsEn" label={a.doctors.qualificationsEn} defaultValue={list(d?.qualifications.en)} rows={3} />
            <TextArea name="languagesSq" label={a.doctors.languagesSq} defaultValue={list(d?.languages.sq)} rows={2} />
            <TextArea name="languagesEn" label={a.doctors.languagesEn} defaultValue={list(d?.languages.en)} rows={2} />
            <div className="sm:col-span-2">
              <p className="field-label">{a.doctors.photo}</p>
              {d?.photoMediaId && (
                <div className="mb-3 flex items-center gap-4">
                  <Image src={`/media/${d.photoMediaId}`} alt="" width={80} height={100} className="h-24 w-20 rounded object-cover" />
                  <Checkbox name="removePhoto" label={a.content.images.clear} />
                </div>
              )}
              <input
                name="photo"
                type="file"
                accept="image/jpeg,image/png,image/webp"
                className="block text-sm"
                aria-label={a.doctors.photo}
              />
            </div>
            <div className="space-y-2.5 sm:col-span-2">
              <Checkbox name="active" label={a.doctors.active} defaultChecked={d?.active ?? true} />
              <Checkbox name="published" label={a.doctors.published} defaultChecked={d?.published ?? true} />
            </div>
            <TextField name="sortOrder" type="number" label={a.services.sortOrder} defaultValue={d?.sortOrder ?? 0} min={0} max={999} />
            <div className="sm:col-span-2">
              <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
            </div>
          </AdminForm>
        </Card>

        {d && (
          <Card title={a.doctors.schedule}>
            <p className="text-ink-muted mb-5 text-sm">{fmt(a.doctors.scheduleLead, { tz: settings.timezone })}</p>
            <AdminForm action={saveSchedule}>
              <input type="hidden" name="doctorId" value={d.id} />
              <div className="overflow-x-auto">
                <table className="w-full min-w-[34rem] text-sm">
                  <thead className="text-ink-muted text-xs">
                    <tr>
                      <th scope="col" className="pb-2 text-left font-normal">
                        {a.doctors.day}
                      </th>
                      <th scope="col" className="pb-2 text-left font-normal">
                        {a.doctors.from}
                      </th>
                      <th scope="col" className="pb-2 text-left font-normal">
                        {a.doctors.until}
                      </th>
                      <th scope="col" className="pb-2 text-left font-normal">
                        {a.doctors.secondFrom}
                      </th>
                      <th scope="col" className="pb-2 text-left font-normal">
                        {a.doctors.secondUntil}
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {order.map((wd) => {
                      const r = hours.filter((h) => h.weekday === wd).sort((x, y) => x.startMinute - y.startMinute);
                      const v = (i: number, k: "startMinute" | "endMinute") => (r[i] ? minutesToHHMM(r[i][k]) : "");
                      return (
                        <tr key={wd} className="border-line border-t">
                          <th scope="row" className="py-2 pr-3 text-left font-normal">
                            {a.doctors.weekdays[wd]}
                            {!r.length && <span className="text-ink-muted block text-xs">{a.doctors.closed}</span>}
                          </th>
                          {(
                            [
                              [0, "startMinute", `d${wd}_from1`],
                              [0, "endMinute", `d${wd}_until1`],
                              [1, "startMinute", `d${wd}_from2`],
                              [1, "endMinute", `d${wd}_until2`],
                            ] as const
                          ).map(([i, k, name]) => (
                            <td key={name} className="py-2 pr-2">
                              <input
                                type="time"
                                step={300}
                                name={name}
                                defaultValue={v(i, k)}
                                aria-label={`${a.doctors.weekdays[wd]} ${name}`}
                                className="input !min-h-10 !py-1.5"
                              />
                            </td>
                          ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="mt-4 flex flex-wrap items-center gap-4">
                <SubmitButton pendingLabel={a.common.saving}>{a.doctors.saveSchedule}</SubmitButton>
                <Link href="/admin/availability" className="link-quiet text-plum text-sm">
                  {a.doctors.timeOffLink}
                </Link>
              </div>
            </AdminForm>
          </Card>
        )}
      </div>
    </>
  );
}
