import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { doctorsList } from "@/lib/admin/queries";
import { pick } from "@/lib/i18n/config";
import { PageTitle } from "@/components/admin/fields";

export default async function DoctorsAdmin() {
  const user = await requireUser("doctors.manage");
  const { a, locale } = await getAdminDict(user.locale);
  const doctors = await doctorsList();
  return (
    <>
      <PageTitle
        title={a.doctors.title}
        actions={
          <Link href="/admin/doctors/new" className="btn btn-primary btn-sm">
            {a.doctors.new}
          </Link>
        }
      />
      <ul className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {doctors.map((d) => (
          <li key={d.id}>
            <Link href={`/admin/doctors/${d.id}`} className="border-line hover:border-plum/40 block rounded-lg border bg-white p-5">
              <span className="font-display text-plum block text-xl">{d.fullName}</span>
              <span className="text-ink-muted mt-1 block text-sm">{pick(d.title, locale) || a.common.notSet}</span>
              <span className="mt-3 flex gap-2 text-xs">
                <span className={`rounded-full px-2 py-0.5 ${d.active ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}>
                  {a.doctors.active}: {d.active ? a.common.yes : a.common.no}
                </span>
                <span className={`rounded-full px-2 py-0.5 ${d.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}>
                  {d.published ? a.common.published : a.common.draft}
                </span>
              </span>
            </Link>
          </li>
        ))}
      </ul>
    </>
  );
}
