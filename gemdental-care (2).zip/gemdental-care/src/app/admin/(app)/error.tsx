"use client";

import { useEffect } from "react";

/** Dashboard error boundary: shown for network/database failures. Nothing was changed. */
export default function AdminError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error.digest ?? error.message);
  }, [error]);
  const sq = typeof document !== "undefined" && document.documentElement.lang.startsWith("sq");
  return (
    <div role="alert" className="border-error/30 bg-error-bg text-error max-w-lg rounded-lg border p-6">
      <h1 className="text-lg font-medium">{sq ? "Faqja nuk u ngarkua" : "This page couldn't load"}</h1>
      <p className="mt-2 text-sm">
        {sq
          ? "Nuk u lidhëm me serverin ose bazën e të dhënave. Asgjë nuk u ndryshua. Provoni përsëri pas pak."
          : "We couldn't reach the server or database. Nothing was changed. Try again in a moment."}
      </p>
      <button type="button" onClick={reset} className="btn btn-secondary btn-sm mt-4">
        {sq ? "Provo përsëri" : "Try again"}
      </button>
    </div>
  );
}
