import { desc, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { fmt } from "@/lib/i18n/format";
import { fmtDateTime } from "@/lib/admin/format";
import { channelProvider, maskRecipient } from "@/lib/notifications/providers";
import { DEFAULT_TEMPLATES, NOTIFICATION_EVENTS, TEMPLATE_VARIABLES } from "@/lib/notifications/templates";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle } from "@/components/admin/fields";
import { retryNotification, runQueue, saveChannels, saveTemplate } from "../../actions/notifications";
import Link from "next/link";

export default async function NotificationsPage() {
  const user = await requireUser("notifications.manage");
  const { a, tag } = await getAdminDict(user.locale);
  const n = a.notifications;
  const settings = await getSettings();
  const tz = settings.timezone;
  const [overrides, log, failures] = await Promise.all([
    db().select().from(schema.notificationTemplates),
    db().select().from(schema.notifications).orderBy(desc(schema.notifications.createdAt)).limit(40),
    db()
      .select()
      .from(schema.notifications)
      .where(eq(schema.notifications.status, "failed"))
      .orderBy(desc(schema.notifications.updatedAt))
      .limit(40),
  ]);
  const providerLabel = (c: "email" | "sms" | "whatsapp") => {
    const p = channelProvider(c);
    return p === "real" ? n.providerReal : p === "log" ? n.providerLog : n.providerNone;
  };
  const reminders = [...settings.reminders, ...Array(Math.max(0, 3 - settings.reminders.length)).fill(null)].slice(0, 4);

  return (
    <>
      <PageTitle
        title={n.title}
        lead={n.lead}
        actions={
          <AdminForm action={runQueue}>
            <SubmitButton variant="secondary" pendingLabel={a.common.loading}>
              {n.runQueue}
            </SubmitButton>
          </AdminForm>
        }
      />
      <AdminForm action={saveChannels} className="space-y-6">
        <div className="grid gap-6 xl:grid-cols-2">
          <Card title={n.channels}>
            <ul className="divide-line divide-y">
              {(["email", "sms", "whatsapp"] as const).map((c) => (
                <li key={c} className="flex flex-wrap items-center justify-between gap-3 py-3">
                  <div>
                    <p className="font-medium">{c === "email" ? n.channelEmail : c === "sms" ? n.channelSms : n.channelWhatsapp}</p>
                    <p className={`text-xs ${channelProvider(c) === "real" ? "text-success" : "text-ink-muted"}`}>{providerLabel(c)}</p>
                  </div>
                  <Checkbox name={`ch_${c}`} label={n.enableChannel} defaultChecked={settings.channelsEnabled[c]} />
                </li>
              ))}
            </ul>
          </Card>
          <Card title={n.reminders}>
            <div className="space-y-3">
              {reminders.map((r, i) => (
                <div key={i} className="flex flex-wrap items-end gap-4">
                  <div className="w-40">
                    <label htmlFor={`rem${i}`} className="field-label">
                      {n.reminderHours}
                    </label>
                    <input
                      id={`rem${i}`}
                      name={`rem${i}_hours`}
                      type="number"
                      min={1}
                      max={336}
                      defaultValue={r ? r.minutesBefore / 60 : ""}
                      className="input"
                    />
                  </div>
                  <div className="pb-3">
                    <Checkbox name={`rem${i}_enabled`} label={n.reminderEnabled} defaultChecked={r?.enabled ?? false} />
                  </div>
                </div>
              ))}
            </div>
          </Card>
        </div>
        <Card title={n.whatsappTemplates}>
          <p className="text-ink-muted mb-4 text-sm">{n.whatsappLead}</p>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {NOTIFICATION_EVENTS.map((e) => (
              <div key={e}>
                <label htmlFor={`wa_${e}`} className="field-label">
                  {n.events[e]}
                </label>
                <input
                  id={`wa_${e}`}
                  name={`wa_${e}`}
                  defaultValue={settings.whatsappTemplates[e] ?? ""}
                  placeholder="appointment_confirmed"
                  pattern="[a-z0-9_]+"
                  className="input font-mono text-sm"
                />
              </div>
            ))}
          </div>
        </Card>
        <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
      </AdminForm>

      <section className="mt-12">
        <h2 className="text-plum text-lg font-medium">{n.templates}</h2>
        <p className="text-ink-muted mt-1 mb-5 text-sm">
          {fmt(n.templatesLead, { vars: TEMPLATE_VARIABLES.map((v) => `{${v}}`).join(" ") })}
        </p>
        <div className="space-y-3">
          {NOTIFICATION_EVENTS.map((e) => (
            <details key={e} className="border-line rounded-lg border bg-white">
              <summary className="text-plum cursor-pointer px-5 py-4 font-medium">{n.events[e]}</summary>
              <div className="border-line grid gap-6 border-t p-5 xl:grid-cols-2">
                {(["email", "sms"] as const).flatMap((ch) =>
                  (["sq", "en"] as const).map((loc) => {
                    const o = overrides.find((x) => x.event === e && x.channel === ch && x.locale === loc);
                    const d = DEFAULT_TEMPLATES[e][ch][loc];
                    return (
                      <AdminForm key={`${ch}-${loc}`} action={saveTemplate} className="border-line space-y-3 rounded-md border p-4">
                        <p className="flex justify-between text-sm">
                          <span className="font-medium">
                            {ch === "email" ? n.channelEmail : n.channelSms} · {loc === "sq" ? a.common.albanian : a.common.english}
                          </span>
                          <span className="text-ink-muted text-xs">{o ? n.customised : n.defaultTpl}</span>
                        </p>
                        <input type="hidden" name="event" value={e} />
                        <input type="hidden" name="channel" value={ch} />
                        <input type="hidden" name="locale" value={loc} />
                        {ch === "email" && (
                          <div>
                            <label className="field-label" htmlFor={`s-${e}-${ch}-${loc}`}>
                              {n.subject}
                            </label>
                            <input id={`s-${e}-${ch}-${loc}`} name="subject" defaultValue={o?.subject ?? d.subject} className="input" />
                          </div>
                        )}
                        <div>
                          <label className="field-label" htmlFor={`b-${e}-${ch}-${loc}`}>
                            {n.body}
                          </label>
                          <textarea
                            id={`b-${e}-${ch}-${loc}`}
                            name="body"
                            rows={ch === "email" ? 9 : 3}
                            defaultValue={o?.body ?? d.body}
                            className="input text-sm"
                          />
                        </div>
                        <Checkbox name="enabled" label={n.templateEnabled} defaultChecked={o?.enabled ?? true} />
                        <div className="flex gap-3">
                          <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
                          {o && (
                            <SubmitButton variant="secondary" name="reset" value="1">
                              {n.resetTemplate}
                            </SubmitButton>
                          )}
                        </div>
                      </AdminForm>
                    );
                  }),
                )}
              </div>
            </details>
          ))}
        </div>
      </section>

      <section id="failures" className="mt-12">
        <h2 className="text-plum mb-4 text-lg font-medium">{n.failures}</h2>
        {failures.length ? (
          <ul className="divide-line border-line divide-y rounded-lg border bg-white">
            {failures.map((f) => (
              <li key={f.id} className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 text-sm">
                <div>
                  <p>
                    {n.events[f.event]} · {f.channel} · {f.recipient ? maskRecipient(f.recipient) : "—"}
                  </p>
                  <p className="text-error text-xs">{f.lastError}</p>
                  <Link href={`/admin/appointments/${f.appointmentId}`} className="link-quiet text-ink-muted text-xs">
                    {a.common.open}
                  </Link>
                </div>
                <AdminForm action={retryNotification}>
                  <input type="hidden" name="id" value={f.id} />
                  <SubmitButton variant="secondary">{n.retry}</SubmitButton>
                </AdminForm>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-ink-muted text-sm">{n.noFailures}</p>
        )}
      </section>

      <section className="mt-12">
        <h2 className="text-plum mb-4 text-lg font-medium">{n.log}</h2>
        <div className="border-line overflow-x-auto rounded-lg border bg-white">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead className="bg-ivory text-ink-muted text-xs">
              <tr>
                <th scope="col" className="px-4 py-2 font-normal">
                  {n.when}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {n.event}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {n.recipient}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {a.appointments.status}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {n.error}
                </th>
              </tr>
            </thead>
            <tbody className="divide-line divide-y">
              {log.map((l) => (
                <tr key={l.id}>
                  <td className="px-4 py-2 whitespace-nowrap tabular-nums">{fmtDateTime(l.sentAt ?? l.createdAt, tz, tag)}</td>
                  <td className="px-4 py-2">
                    {n.events[l.event]} · {l.channel}
                  </td>
                  <td className="px-4 py-2">{l.recipient ? maskRecipient(l.recipient) : "—"}</td>
                  <td className="px-4 py-2">{n.statuses[l.status]}</td>
                  <td className="text-ink-muted px-4 py-2 text-xs">{l.lastError ?? ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
