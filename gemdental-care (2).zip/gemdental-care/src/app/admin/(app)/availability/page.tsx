import { asc, gt } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { zonedDateKey } from "@/lib/time";
import { fmtDateTime } from "@/lib/admin/format";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, Select, TextField } from "@/components/admin/fields";
import { addException, removeException } from "../../actions/availability";

export default async function AvailabilityPage() {
  const user = await requireUser("schedule.block");
  const { a, tag } = await getAdminDict(user.locale);
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = zonedDateKey(new Date(), tz);
  const doctors = await db().select().from(schema.doctors).orderBy(asc(schema.doctors.sortOrder));
  const upcoming = await db()
    .select()
    .from(schema.availabilityExceptions)
    .where(gt(schema.availabilityExceptions.endsAt, new Date()))
    .orderBy(asc(schema.availabilityExceptions.startsAt));
  const docName = new Map(doctors.map((d) => [d.id, d.fullName]));

  return (
    <>
      <PageTitle title={a.availability.title} lead={a.availability.lead} />
      <div className="grid gap-6 xl:grid-cols-2">
        <Card>
          <AdminForm action={addException} className="grid gap-4 sm:grid-cols-2" resetOnSuccess>
            <Select
              name="doctorId"
              label={a.availability.doctor}
              options={[{ value: "", label: a.availability.wholeClinic }, ...doctors.map((d) => ({ value: d.id, label: d.fullName }))]}
            />
            <Select
              name="kind"
              label={a.availability.kind}
              defaultValue="time_off"
              options={(["time_off", "holiday", "closure", "block"] as const).map((k) => ({ value: k, label: a.availability.kinds[k] }))}
            />
            <TextField name="startDate" type="date" label={a.availability.start} required defaultValue={today} />
            <TextField
              name="startTime"
              type="time"
              label={`${a.availability.start} (${a.newAppointment.time.toLowerCase()})`}
              step={300}
              defaultValue="09:00"
            />
            <TextField name="endDate" type="date" label={a.availability.end} required defaultValue={today} />
            <TextField
              name="endTime"
              type="time"
              label={`${a.availability.end} (${a.newAppointment.time.toLowerCase()})`}
              step={300}
              defaultValue="18:00"
            />
            <div className="sm:col-span-2">
              <Checkbox name="allDay" label={a.availability.allDay} />
            </div>
            <TextField name="reason" label={a.availability.reason} className="sm:col-span-2" maxLength={300} />
            <div className="sm:col-span-2">
              <SubmitButton pendingLabel={a.common.saving}>{a.availability.add}</SubmitButton>
            </div>
          </AdminForm>
        </Card>
        <Card title={a.availability.upcoming}>
          {upcoming.length ? (
            <ul className="divide-line divide-y">
              {upcoming.map((x) => (
                <li key={x.id} className="flex flex-wrap items-center justify-between gap-3 py-3 text-sm">
                  <div>
                    <p className="text-plum font-medium">
                      {a.availability.kinds[x.kind]} · {x.doctorId ? docName.get(x.doctorId) : a.availability.wholeClinic}
                    </p>
                    <p className="text-ink-muted">
                      {fmtDateTime(x.startsAt, tz, tag)} → {fmtDateTime(x.endsAt, tz, tag)}
                    </p>
                    {x.reason && <p className="text-ink-muted text-xs">{x.reason}</p>}
                  </div>
                  <AdminForm action={removeException} confirmText={a.common.confirmDelete}>
                    <input type="hidden" name="id" value={x.id} />
                    <SubmitButton variant="danger">{a.common.remove}</SubmitButton>
                  </AdminForm>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-ink-muted text-sm">{a.availability.none}</p>
          )}
        </Card>
      </div>
    </>
  );
}
