import Link from "next/link";
import { desc } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { fmtDateTime } from "@/lib/admin/format";
import { PageTitle } from "@/components/admin/fields";

export default async function AuditPage({ searchParams }: { searchParams: Promise<{ page?: string }> }) {
  const user = await requireUser("audit.view");
  const { a, tag } = await getAdminDict(user.locale);
  const tz = (await getSettings()).timezone;
  const page = Math.max(0, Number((await searchParams).page ?? 0) || 0);
  const rows = await db()
    .select()
    .from(schema.auditLogs)
    .orderBy(desc(schema.auditLogs.createdAt))
    .limit(101)
    .offset(page * 100);
  return (
    <>
      <PageTitle title={a.audit.title} lead={a.audit.lead} />
      {rows.length === 0 ? (
        <p className="text-ink-muted text-sm">{a.audit.empty}</p>
      ) : (
        <div className="border-line overflow-x-auto rounded-lg border bg-white">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead className="bg-ivory text-ink-muted text-xs">
              <tr>
                <th scope="col" className="px-4 py-2 font-normal">
                  {a.audit.when}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {a.audit.who}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {a.audit.action}
                </th>
                <th scope="col" className="px-4 py-2 font-normal">
                  {a.audit.target}
                </th>
              </tr>
            </thead>
            <tbody className="divide-line divide-y">
              {rows.slice(0, 100).map((r) => (
                <tr key={r.id}>
                  <td className="px-4 py-2 whitespace-nowrap tabular-nums">{fmtDateTime(r.createdAt, tz, tag)}</td>
                  <td className="px-4 py-2">{r.actorLabel}</td>
                  <td className="px-4 py-2 font-mono text-xs">{r.action}</td>
                  <td className="text-ink-muted px-4 py-2 text-xs">
                    {r.entityType === "appointment" && r.entityId ? (
                      <Link className="link-quiet" href={`/admin/appointments/${r.entityId}`}>
                        {String((r.details as { reference?: string }).reference ?? r.entityId.slice(0, 8))}
                      </Link>
                    ) : (
                      `${r.entityType}${r.entityId ? ` · ${r.entityId.slice(0, 8)}` : ""}`
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <nav className="mt-6 flex justify-between">
        {page > 0 ? (
          <Link className="btn btn-secondary btn-sm" href={`?page=${page - 1}`}>
            {a.common.previous}
          </Link>
        ) : (
          <span />
        )}
        {rows.length > 100 && (
          <Link className="btn btn-secondary btn-sm" href={`?page=${page + 1}`}>
            {a.common.next}
          </Link>
        )}
      </nav>
    </>
  );
}
