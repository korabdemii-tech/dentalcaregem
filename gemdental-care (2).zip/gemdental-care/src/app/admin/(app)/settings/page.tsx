import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { getSettings } from "@/lib/settings";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, TextField } from "@/components/admin/fields";
import { saveSettings } from "../../actions/settings";

export default async function SettingsPage() {
  const user = await requireUser("settings.manage");
  const { a } = await getAdminDict(user.locale);
  const s = a.settings;
  const st = await getSettings();
  const hours = new Map(
    (st.openingHours ?? []).filter((h): h is { day: number; open: string; close: string } => !("closed" in h)).map((h) => [h.day, h]),
  );

  return (
    <>
      <PageTitle title={s.title} />
      <AdminForm action={saveSettings} className="max-w-4xl space-y-6">
        <Card title={s.contact}>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField name="clinicName" label={s.clinicName} defaultValue={st.clinicName} className="sm:col-span-2" />
            <TextField name="phone" type="tel" label={s.phone} defaultValue={st.phone} hint={s.phoneHint} />
            <TextField name="whatsapp" type="tel" label={s.whatsapp} defaultValue={st.whatsapp} />
            <TextField name="email" type="email" label={s.email} defaultValue={st.email} className="sm:col-span-2" />
          </div>
        </Card>
        <Card title={s.address}>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField name="addressSq" label={s.addressSq} defaultValue={st.addressLine?.sq} />
            <TextField name="addressEn" label={s.addressEn} defaultValue={st.addressLine?.en} />
            <TextField name="city" label={s.city} defaultValue={st.city} />
            <TextField name="postalCode" label={s.postalCode} defaultValue={st.postalCode} />
            <TextField name="country" label={s.country} defaultValue={st.country} hint={s.countryHint} maxLength={2} />
            <TextField name="mapsUrl" type="url" label={s.mapsUrl} defaultValue={st.mapsUrl} />
            <TextField name="latitude" label={s.latitude} defaultValue={st.latitude} inputMode="decimal" />
            <TextField name="longitude" label={s.longitude} defaultValue={st.longitude} inputMode="decimal" />
          </div>
        </Card>
        <Card title={s.hours}>
          <p className="text-ink-muted mb-4 text-sm">{s.hoursHint}</p>
          <div className="space-y-2">
            {[1, 2, 3, 4, 5, 6, 0].map((d) => (
              <div key={d} className="grid grid-cols-[7rem_1fr_1fr] items-center gap-3">
                <span className="text-sm">{a.doctors.weekdays[d]}</span>
                <input
                  type="time"
                  step={300}
                  name={`oh${d}_open`}
                  defaultValue={hours.get(d)?.open ?? ""}
                  aria-label={`${a.doctors.weekdays[d]} ${s.open}`}
                  className="input !min-h-10 !py-1.5"
                />
                <input
                  type="time"
                  step={300}
                  name={`oh${d}_close`}
                  defaultValue={hours.get(d)?.close ?? ""}
                  aria-label={`${a.doctors.weekdays[d]} ${s.close}`}
                  className="input !min-h-10 !py-1.5"
                />
              </div>
            ))}
          </div>
        </Card>
        <Card title={s.social}>
          <div className="grid gap-4 sm:grid-cols-2">
            {(["instagram", "facebook", "tiktok", "linkedin"] as const).map((k) => (
              <TextField
                key={k}
                name={k}
                type="url"
                label={k[0].toUpperCase() + k.slice(1)}
                defaultValue={st.social?.[k]}
                placeholder="https://"
              />
            ))}
          </div>
        </Card>
        <Card title={s.booking}>
          <div className="space-y-3">
            <Checkbox name="onlineBookingEnabled" label={s.onlineBooking} defaultChecked={st.onlineBookingEnabled} />
            <Checkbox name="autoConfirm" label={s.autoConfirm} hint={s.autoConfirmHint} defaultChecked={st.autoConfirm} />
          </div>
          <div className="mt-5 grid gap-4 sm:grid-cols-3">
            <TextField name="minNoticeHours" type="number" label={s.minNotice} defaultValue={st.minNoticeMinutes / 60} min={0} max={720} />
            <TextField name="horizonDays" type="number" label={s.horizon} defaultValue={st.horizonDays} min={1} max={365} />
            <TextField
              name="slotIntervalMinutes"
              type="number"
              label={s.slotInterval}
              defaultValue={st.slotIntervalMinutes}
              min={5}
              max={120}
              step={5}
            />
            <TextField name="timezone" label={s.timezone} defaultValue={st.timezone} hint={s.timezoneHint} className="sm:col-span-3" />
          </div>
        </Card>
        <Card title={s.privacy}>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField name="legalEntityName" label={s.legalEntity} defaultValue={st.legalEntityName} />
            <TextField name="privacyContactEmail" type="email" label={s.privacyEmail} defaultValue={st.privacyContactEmail} />
            <TextField
              name="dataRetentionMonths"
              type="number"
              label={s.retention}
              defaultValue={st.dataRetentionMonths}
              hint={s.retentionHint}
              min={1}
              max={240}
            />
          </div>
        </Card>
        <Card title={s.website}>
          <Checkbox name="previewNotice" label={s.previewNotice} hint={s.previewHint} defaultChecked={st.previewNotice} />
        </Card>
        <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
      </AdminForm>
    </>
  );
}
