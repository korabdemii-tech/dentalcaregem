import Link from "next/link";
import Image from "next/image";
import { asc, eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { pick } from "@/lib/i18n/config";
import { getSiteImages, SITE_IMAGE_SLOTS } from "@/lib/content";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, Select, TextArea, TextField } from "@/components/admin/fields";
import { saveCase, saveFaq, saveGalleryPhoto, saveReview, saveSiteImage } from "../../actions/content";
import { GALLERY_KINDS, RESULT_CONCERNS } from "@/lib/db/schema";

type Tab = "images" | "faq" | "reviews" | "results" | "gallery";

export default async function ContentPage({ searchParams }: { searchParams: Promise<{ tab?: string }> }) {
  const user = await requireUser("content.manage");
  const { a, locale } = await getAdminDict(user.locale);
  const sp = await searchParams;
  const tab: Tab = (["images", "faq", "reviews", "results", "gallery"] as const).find((t) => t === sp.tab) ?? "images";
  const c = a.content;

  return (
    <>
      <PageTitle title={c.title} />
      <nav aria-label={c.title} className="border-line mb-8 flex flex-wrap gap-1 border-b">
        {(["images", "faq", "reviews", "results", "gallery"] as const).map((t) => (
          <Link
            key={t}
            href={`/admin/content?tab=${t}`}
            aria-current={t === tab ? "page" : undefined}
            className="text-ink-muted hover:text-plum aria-[current=page]:border-plum aria-[current=page]:text-plum -mb-px border-b-2 border-transparent px-4 py-2.5 text-sm"
          >
            {c.tabs[t]}
          </Link>
        ))}
      </nav>
      {tab === "images" && <ImagesTab a={a} />}
      {tab === "faq" && <FaqTab a={a} />}
      {tab === "reviews" && <ReviewsTab a={a} />}
      {tab === "results" && <ResultsTab a={a} locale={locale} />}
      {tab === "gallery" && <GalleryTab a={a} />}
    </>
  );
}

type A = Awaited<ReturnType<typeof getAdminDict>>["a"];

async function ImagesTab({ a }: { a: A }) {
  const images = await getSiteImages();
  const c = a.content.images;
  return (
    <>
      <p className="text-ink-muted mb-6 max-w-2xl text-sm">{c.lead}</p>
      <div className="grid gap-6 lg:grid-cols-2">
        {SITE_IMAGE_SLOTS.map((slot) => {
          const img = images[slot];
          return (
            <Card key={slot} title={c.slots[slot]}>
              <AdminForm action={saveSiteImage} className="space-y-4">
                <input type="hidden" name="slot" value={slot} />
                {img ? (
                  <Image
                    src={img.url}
                    alt={img.alt.en ?? ""}
                    width={img.width}
                    height={img.height}
                    className="aspect-video w-full rounded object-cover"
                    sizes="40vw"
                  />
                ) : (
                  <p className="border-line-strong bg-ivory text-ink-muted grid aspect-video place-items-center rounded border border-dashed text-sm">
                    {c.empty}
                  </p>
                )}
                <div>
                  <label htmlFor={`file-${slot}`} className="field-label">
                    {img ? c.replace : c.upload}
                  </label>
                  <input id={`file-${slot}`} name="file" type="file" accept="image/jpeg,image/png,image/webp" className="block text-sm" />
                </div>
                <TextField name="altSq" label={c.altSq} defaultValue={img?.alt.sq} />
                <TextField name="altEn" label={c.altEn} defaultValue={img?.alt.en} />
                <Checkbox name="authentic" label={c.authentic} hint={c.authenticHint} defaultChecked={img?.authentic ?? true} />
                <div className="flex flex-wrap gap-3">
                  <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
                  {img && (
                    <SubmitButton variant="danger" name="clear" value="1">
                      {c.clear}
                    </SubmitButton>
                  )}
                </div>
              </AdminForm>
            </Card>
          );
        })}
      </div>
    </>
  );
}

function FaqForm({ a, f }: { a: A; f?: typeof schema.faqs.$inferSelect }) {
  const c = a.content.faq;
  return (
    <AdminForm action={saveFaq} className="grid gap-4 sm:grid-cols-2" resetOnSuccess={!f}>
      <input type="hidden" name="id" value={f?.id ?? ""} />
      <TextField name="questionSq" label={c.questionSq} defaultValue={f?.question.sq} />
      <TextField name="questionEn" label={c.questionEn} defaultValue={f?.question.en} />
      <TextArea name="answerSq" label={c.answerSq} defaultValue={f?.answer.sq} rows={4} />
      <TextArea name="answerEn" label={c.answerEn} defaultValue={f?.answer.en} rows={4} />
      <TextField name="topic" label={c.topic} defaultValue={f?.topic ?? "general"} />
      <TextField name="sortOrder" type="number" label={a.services.sortOrder} defaultValue={f?.sortOrder ?? 0} min={0} max={999} />
      <div className="space-y-2 sm:col-span-2">
        <Checkbox name="verified" label={c.verified} defaultChecked={f?.verified} />
        <Checkbox name="published" label={c.published} defaultChecked={f?.published} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <SubmitButton pendingLabel={a.common.saving}>{f ? a.common.save : c.add}</SubmitButton>
        {f && (
          <SubmitButton variant="danger" name="delete" value="1">
            {a.common.delete}
          </SubmitButton>
        )}
      </div>
    </AdminForm>
  );
}

async function FaqTab({ a }: { a: A }) {
  const faqs = await db().select().from(schema.faqs).orderBy(asc(schema.faqs.sortOrder));
  return (
    <>
      <p className="text-ink-muted mb-6 max-w-2xl text-sm">{a.content.faq.lead}</p>
      <div className="space-y-3">
        {faqs.map((f) => (
          <details key={f.id} className="border-line rounded-lg border bg-white">
            <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-3 px-5 py-4">
              <span className="text-plum font-medium">{f.question.sq || f.question.en}</span>
              <span className="flex gap-2 text-xs">
                {!f.verified && (
                  <span className="bg-warning-bg text-champagne-ink rounded-full px-2 py-0.5">{a.content.faq.needsVerify}</span>
                )}
                <span className={`rounded-full px-2 py-0.5 ${f.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}>
                  {f.published ? a.common.published : a.common.draft}
                </span>
              </span>
            </summary>
            <div className="border-line border-t p-5">
              <FaqForm a={a} f={f} />
            </div>
          </details>
        ))}
      </div>
      <Card title={a.content.faq.add} className="mt-8">
        <FaqForm a={a} />
      </Card>
    </>
  );
}

function ReviewForm({ a, r }: { a: A; r?: typeof schema.testimonials.$inferSelect }) {
  const c = a.content.reviews;
  return (
    <AdminForm action={saveReview} className="grid gap-4 sm:grid-cols-2" resetOnSuccess={!r}>
      <input type="hidden" name="id" value={r?.id ?? ""} />
      <TextField name="authorName" label={c.author} defaultValue={r?.authorName} required />
      <Select
        name="locale"
        label={c.language}
        defaultValue={r?.locale ?? "sq"}
        options={[
          { value: "sq", label: a.common.albanian },
          { value: "en", label: a.common.english },
        ]}
      />
      <TextArea name="body" label={c.body} defaultValue={r?.body} rows={4} className="sm:col-span-2" required />
      <TextField name="source" label={c.source} hint={c.sourceHint} defaultValue={r?.source} required />
      <TextField name="sourceUrl" type="url" label={c.sourceUrl} defaultValue={r?.sourceUrl} />
      <TextField name="reviewDate" type="date" label={c.date} defaultValue={r?.reviewDate} />
      <TextField name="rating" type="number" min={1} max={5} label={c.rating} defaultValue={r?.rating} />
      <div className="space-y-2 sm:col-span-2">
        <Checkbox name="verified" label={c.verified} defaultChecked={r?.verified} />
        <Checkbox name="published" label={c.published} defaultChecked={r?.published} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <SubmitButton pendingLabel={a.common.saving}>{r ? a.common.save : c.add}</SubmitButton>
        {r && (
          <SubmitButton variant="danger" name="delete" value="1">
            {a.common.delete}
          </SubmitButton>
        )}
      </div>
    </AdminForm>
  );
}

async function ReviewsTab({ a }: { a: A }) {
  const reviews = await db().select().from(schema.testimonials).orderBy(asc(schema.testimonials.sortOrder));
  return (
    <>
      <p className="text-ink-muted mb-6 max-w-2xl text-sm">{a.content.reviews.lead}</p>
      <div className="space-y-3">
        {reviews.map((r) => (
          <details key={r.id} className="border-line rounded-lg border bg-white">
            <summary className="flex cursor-pointer justify-between gap-3 px-5 py-4">
              <span className="text-plum">
                {r.authorName} · <span className="text-ink-muted">{r.source}</span>
              </span>
              <span
                className={`rounded-full px-2 py-0.5 text-xs ${r.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}
              >
                {r.published ? a.common.published : a.common.draft}
              </span>
            </summary>
            <div className="border-line border-t p-5">
              <ReviewForm a={a} r={r} />
            </div>
          </details>
        ))}
      </div>
      <Card title={a.content.reviews.add} className="mt-8">
        <ReviewForm a={a} />
      </Card>
    </>
  );
}

function CaseForm({
  a,
  k,
  services,
  locale,
}: {
  a: A;
  k?: typeof schema.resultCases.$inferSelect;
  services: (typeof schema.services.$inferSelect)[];
  locale: "sq" | "en";
}) {
  const c = a.content.results;
  return (
    <AdminForm action={saveCase} className="grid gap-4 sm:grid-cols-2" resetOnSuccess={!k}>
      <input type="hidden" name="id" value={k?.id ?? ""} />
      <TextField name="titleSq" label={c.titleSq} defaultValue={k?.title.sq} />
      <TextField name="titleEn" label={c.titleEn} defaultValue={k?.title.en} />
      <TextArea name="descriptionSq" label={c.descriptionSq} defaultValue={k?.description.sq} rows={2} />
      <TextArea name="descriptionEn" label={c.descriptionEn} defaultValue={k?.description.en} rows={2} />
      <Select
        name="serviceId"
        label={c.service}
        defaultValue={k?.serviceId ?? ""}
        options={[{ value: "", label: a.common.none }, ...services.map((s) => ({ value: s.id, label: pick(s.name, locale) }))]}
      />
      <Select
        name="concern"
        label={c.concern}
        defaultValue={k?.concern ?? ""}
        options={[{ value: "", label: a.common.none }, ...RESULT_CONCERNS.map((v) => ({ value: v, label: c.concerns[v] }))]}
      />
      {(["before", "after"] as const).map((side) => {
        const mid = side === "before" ? k?.beforeMediaId : k?.afterMediaId;
        return (
          <div key={side}>
            <label htmlFor={`${side}-${k?.id ?? "new"}`} className="field-label">
              {c[side]}
            </label>
            {mid && <Image src={`/media/${mid}`} alt="" width={200} height={150} className="mb-2 h-28 w-40 rounded object-cover" />}
            <input
              id={`${side}-${k?.id ?? "new"}`}
              name={side}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="block text-sm"
            />
          </div>
        );
      })}
      <div className="bg-ivory space-y-3 rounded-md p-4 sm:col-span-2">
        <Checkbox name="consentObtained" label={c.consentObtained} defaultChecked={k?.consentObtained} />
        <div className="grid gap-4 sm:grid-cols-3">
          <TextField name="consentDate" type="date" label={c.consentDate} defaultValue={k?.consentDate} />
          <TextField name="consentReference" label={c.consentReference} defaultValue={k?.consentReference} />
          <TextField name="approvedBy" label={c.approvedBy} defaultValue={k?.approvedBy} />
        </div>
      </div>
      <div className="sm:col-span-2">
        <Checkbox name="published" label={c.published} defaultChecked={k?.published} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <SubmitButton pendingLabel={a.common.saving}>{k ? a.common.save : c.add}</SubmitButton>
        {k && (
          <SubmitButton variant="danger" name="delete" value="1">
            {a.common.delete}
          </SubmitButton>
        )}
      </div>
    </AdminForm>
  );
}

async function ResultsTab({ a, locale }: { a: A; locale: "sq" | "en" }) {
  const [cases, services] = await Promise.all([
    db().select().from(schema.resultCases).orderBy(asc(schema.resultCases.sortOrder)),
    db().select().from(schema.services).orderBy(asc(schema.services.sortOrder)),
  ]);
  return (
    <>
      <p className="text-ink-muted mb-6 max-w-2xl text-sm">{a.content.results.lead}</p>
      <div className="space-y-3">
        {cases.map((k) => (
          <details key={k.id} className="border-line rounded-lg border bg-white">
            <summary className="flex cursor-pointer justify-between gap-3 px-5 py-4">
              <span className="text-plum">{k.title.sq || k.title.en || "—"}</span>
              <span
                className={`rounded-full px-2 py-0.5 text-xs ${k.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}
              >
                {k.published ? a.common.published : a.common.draft}
              </span>
            </summary>
            <div className="border-line border-t p-5">
              <CaseForm a={a} k={k} services={services} locale={locale} />
            </div>
          </details>
        ))}
      </div>
      <Card title={a.content.results.add} className="mt-8">
        <CaseForm a={a} services={services} locale={locale} />
      </Card>
    </>
  );
}

function GalleryForm({ a, p }: { a: A; p?: typeof schema.galleryPhotos.$inferSelect & { alt: Record<string, string> } }) {
  const g = a.content.gallery;
  const r = a.content.results;
  const fid = `photo-${p?.id ?? "new"}`;
  return (
    <AdminForm action={saveGalleryPhoto} className="grid gap-4 sm:grid-cols-2" resetOnSuccess={!p}>
      <input type="hidden" name="id" value={p?.id ?? ""} />
      <div>
        <label htmlFor={fid} className="field-label">
          {g.photo}
        </label>
        {p && <Image src={`/media/${p.mediaId}`} alt="" width={200} height={150} className="mb-2 h-28 w-40 rounded object-cover" />}
        <input id={fid} name="photo" type="file" accept="image/jpeg,image/png,image/webp" className="block text-sm" />
      </div>
      <Select
        name="kind"
        label={g.kind}
        defaultValue={p?.kind ?? "smile"}
        options={GALLERY_KINDS.map((k) => ({ value: k, label: g.kinds[k] }))}
      />
      <TextField name="captionSq" label={g.captionSq} defaultValue={p?.caption.sq} />
      <TextField name="captionEn" label={g.captionEn} defaultValue={p?.caption.en} />
      <TextField name="altSq" label={g.altSq} defaultValue={p?.alt.sq} />
      <TextField name="altEn" label={g.altEn} defaultValue={p?.alt.en} />
      <div className="bg-ivory space-y-3 rounded-md p-4 sm:col-span-2">
        <Checkbox name="consentObtained" label={r.consentObtained} defaultChecked={p?.consentObtained} />
        <div className="grid gap-4 sm:grid-cols-3">
          <TextField name="consentDate" type="date" label={r.consentDate} defaultValue={p?.consentDate} />
          <TextField name="consentReference" label={r.consentReference} defaultValue={p?.consentReference} />
          <TextField name="approvedBy" label={r.approvedBy} defaultValue={p?.approvedBy} />
        </div>
      </div>
      <div className="sm:col-span-2">
        <Checkbox name="published" label={r.published} defaultChecked={p?.published} />
      </div>
      <div className="flex gap-3 sm:col-span-2">
        <SubmitButton pendingLabel={a.common.saving}>{p ? a.common.save : g.add}</SubmitButton>
        {p && (
          <SubmitButton variant="danger" name="delete" value="1">
            {a.common.delete}
          </SubmitButton>
        )}
      </div>
    </AdminForm>
  );
}

async function GalleryTab({ a }: { a: A }) {
  const rows = await db()
    .select({ p: schema.galleryPhotos, alt: schema.media.alt })
    .from(schema.galleryPhotos)
    .innerJoin(schema.media, eq(schema.media.id, schema.galleryPhotos.mediaId))
    .orderBy(asc(schema.galleryPhotos.kind), asc(schema.galleryPhotos.sortOrder));
  const g = a.content.gallery;
  return (
    <>
      <p className="text-ink-muted mb-6 max-w-2xl text-sm">{g.lead}</p>
      <div className="space-y-3">
        {rows.map(({ p, alt }) => (
          <details key={p.id} className="border-line rounded-lg border bg-white">
            <summary className="flex cursor-pointer items-center justify-between gap-3 px-5 py-3">
              <span className="flex items-center gap-3">
                <Image src={`/media/${p.mediaId}`} alt="" width={64} height={48} className="h-12 w-16 rounded object-cover" />
                <span className="text-plum">{p.caption.sq || p.caption.en || "—"}</span>
                <span className="text-ink-muted text-xs">{g.kinds[p.kind]}</span>
              </span>
              <span
                className={`rounded-full px-2 py-0.5 text-xs ${p.published ? "bg-success-bg text-success" : "bg-cream text-ink-muted"}`}
              >
                {p.published ? a.common.published : a.common.draft}
              </span>
            </summary>
            <div className="border-line border-t p-5">
              <GalleryForm a={a} p={{ ...p, alt: alt as Record<string, string> }} />
            </div>
          </details>
        ))}
      </div>
      <Card title={g.add} className="mt-8">
        <GalleryForm a={a} />
      </Card>
    </>
  );
}
