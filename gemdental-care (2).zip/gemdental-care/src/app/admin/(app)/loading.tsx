/** Shown while a dashboard page loads its data. */
export default function Loading() {
  return (
    <div role="status" aria-label="Loading" className="space-y-6">
      <div className="skeleton h-10 w-64" />
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="skeleton h-24" />
        ))}
      </div>
      <div className="skeleton h-72" />
    </div>
  );
}
