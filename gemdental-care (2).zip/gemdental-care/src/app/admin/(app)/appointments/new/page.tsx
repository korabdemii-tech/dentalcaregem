import { asc } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { pick } from "@/lib/i18n/config";
import { getSettings } from "@/lib/settings";
import { zonedDateKey } from "@/lib/time";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, Select, TextArea, TextField } from "@/components/admin/fields";
import { createManual } from "../../../actions/appointments";

export default async function NewAppointmentPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const user = await requireUser("appointments.manage");
  const { a, locale } = await getAdminDict(user.locale);
  const sp = await searchParams;
  const settings = await getSettings();
  const services = await db().select().from(schema.services).orderBy(asc(schema.services.sortOrder));
  const doctors = (await db().select().from(schema.doctors).orderBy(asc(schema.doctors.sortOrder))).filter((d) => d.active);

  return (
    <>
      <PageTitle title={a.newAppointment.title} lead={a.newAppointment.lead} />
      <AdminForm action={createManual} className="max-w-3xl space-y-6">
        <Card title={a.newAppointment.patientSection}>
          <div className="grid gap-4 sm:grid-cols-2">
            <TextField name="fullName" label={a.newAppointment.fullName} required autoComplete="off" className="sm:col-span-2" />
            <TextField name="phone" label={a.newAppointment.phone} type="tel" required hint={a.settings.phoneHint} />
            <TextField name="email" label={a.newAppointment.email} type="email" required />
            <Select
              name="locale"
              label={a.newAppointment.language}
              defaultValue={locale}
              options={[
                { value: "sq", label: a.common.albanian },
                { value: "en", label: a.common.english },
              ]}
            />
          </div>
        </Card>
        <Card title={a.newAppointment.visitSection}>
          <div className="grid gap-4 sm:grid-cols-2">
            <Select
              name="serviceId"
              label={a.newAppointment.service}
              options={services.map((s) => ({ value: s.id, label: `${pick(s.name, locale)} · ${s.durationMinutes} ${a.common.minutes}` }))}
            />
            <Select name="doctorId" label={a.newAppointment.doctor} options={doctors.map((d) => ({ value: d.id, label: d.fullName }))} />
            <TextField
              name="date"
              type="date"
              label={a.newAppointment.date}
              required
              defaultValue={sp.date ?? zonedDateKey(new Date(), settings.timezone)}
            />
            <TextField name="time" type="time" step={300} label={a.newAppointment.time} required defaultValue={sp.time} />
            <Select
              name="status"
              label={a.newAppointment.status}
              defaultValue="confirmed"
              options={[
                { value: "confirmed", label: a.newAppointment.statusConfirmed },
                { value: "pending", label: a.newAppointment.statusPending },
              ]}
            />
            <TextArea name="note" label={a.newAppointment.note} rows={2} className="sm:col-span-2" />
            <div className="space-y-2 sm:col-span-2">
              <Checkbox name="override" label={a.appointment.override} hint={a.appointment.overrideHint} />
              <Checkbox name="notify" label={a.newAppointment.notify} defaultChecked />
            </div>
          </div>
        </Card>
        <SubmitButton pendingLabel={a.common.saving}>{a.newAppointment.submit}</SubmitButton>
      </AdminForm>
    </>
  );
}
