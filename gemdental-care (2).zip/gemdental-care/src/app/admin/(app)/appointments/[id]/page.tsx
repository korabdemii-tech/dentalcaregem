import Link from "next/link";
import { notFound } from "next/navigation";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { appointmentDetail, doctorsList } from "@/lib/admin/queries";
import { getSettings } from "@/lib/settings";
import { pick } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { fmtDateTime, fmtTime, dt } from "@/lib/admin/format";
import { zonedDateKey, zonedMinutes, minutesToHHMM } from "@/lib/time";
import { canTransition } from "@/lib/booking/manage";
import { formatPhoneDisplay, telHref, whatsappHref } from "@/lib/clinic-info";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, StatusBadge } from "@/components/admin/fields";
import { erasePatient, moveAppointment, saveNotes, updateStatus } from "../../../actions/appointments";
import { can } from "@/lib/auth/permissions";
import { UUID_RE } from "@/lib/admin/action";

export default async function AppointmentPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string; done?: string }>;
}) {
  const user = await requireUser("appointments.view");
  const { a, locale, tag } = await getAdminDict(user.locale);
  const { id } = await params;
  if (!UUID_RE.test(id)) notFound();
  const detail = await appointmentDetail(id);
  if (!detail) notFound();
  const { created, done } = await searchParams;
  const settings = await getSettings();
  const tz = settings.timezone;
  const { a: appt, p, s, d } = detail;
  const doctors = (await doctorsList()).filter((x) => x.active || x.id === d.id);
  const durationMin = Math.round((appt.endsAt.getTime() - appt.startsAt.getTime()) / 60_000);
  const canMove = !["cancelled", "completed", "no_show"].includes(appt.status);

  const statusBtn = (
    to: "confirmed" | "completed" | "no_show" | "reschedule_requested",
    label: string,
    variant: "primary" | "secondary" = "secondary",
  ) =>
    canTransition(appt.status, to) && (
      <AdminForm action={updateStatus} key={to}>
        <input type="hidden" name="id" value={appt.id} />
        <input type="hidden" name="to" value={to} />
        <SubmitButton variant={variant} pendingLabel={a.common.saving}>
          {label}
        </SubmitButton>
      </AdminForm>
    );

  return (
    <>
      <Link href="/admin/appointments" className="link-quiet text-ink-muted text-sm">
        ← {a.nav.appointments}
      </Link>
      <div className="mt-4">
        <PageTitle
          title={fmt(a.appointment.title, { ref: appt.reference })}
          lead={fmt(a.appointment.created, {
            date: fmtDateTime(appt.createdAt, tz, tag),
            source: appt.source === "online" ? a.appointments.sourceOnline : a.appointments.sourceAdmin,
          })}
          actions={<StatusBadge status={appt.status} label={a.status[appt.status]} />}
        />
      </div>
      {done && (
        <p role="status" className="bg-success-bg text-success mb-6 rounded-md px-3 py-2 text-sm">
          {done === "confirmed" ? a.appointment.confirmed : done === "cancelled" ? a.appointment.cancelled : a.appointment.updated}
        </p>
      )}
      {created && (
        <p role="status" className="bg-success-bg text-success mb-6 rounded-md px-3 py-2 text-sm">
          {fmt(a.newAppointment.created, { ref: appt.reference })}
        </p>
      )}

      <div className="grid gap-6 xl:grid-cols-3">
        <div className="space-y-6 xl:col-span-2">
          <Card title={a.common.details}>
            <dl className="grid gap-x-8 gap-y-4 sm:grid-cols-2">
              <div>
                <dt className="text-ink-muted text-xs">{a.appointments.when}</dt>
                <dd className="text-plum text-lg">
                  {dt(appt.startsAt, tz, tag, { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
                  <br />
                  {fmtTime(appt.startsAt, tz, tag)}–{fmtTime(appt.endsAt, tz, tag)}{" "}
                  <span className="text-ink-muted text-sm">({fmt(a.appointment.duration, { n: durationMin })})</span>
                </dd>
              </div>
              <div>
                <dt className="text-ink-muted text-xs">{a.appointments.treatment}</dt>
                <dd>{pick(s.name, locale)}</dd>
                <dt className="text-ink-muted mt-3 text-xs">{a.appointments.doctor}</dt>
                <dd>{d.fullName}</dd>
              </div>
            </dl>
            <div className="border-line mt-6 flex flex-wrap gap-2 border-t pt-5">
              {statusBtn("confirmed", a.appointment.confirm, "primary")}
              {statusBtn("completed", a.appointment.complete)}
              {statusBtn("no_show", a.appointment.noShow)}
              {statusBtn("reschedule_requested", a.appointment.requestReschedule)}
            </div>
            {canTransition(appt.status, "cancelled") && (
              <AdminForm
                action={updateStatus}
                className="border-line mt-5 flex flex-wrap items-end gap-3 border-t pt-5"
                confirmText={a.appointment.cancel + "?"}
              >
                <input type="hidden" name="id" value={appt.id} />
                <input type="hidden" name="to" value="cancelled" />
                <div className="min-w-56 flex-1">
                  <label htmlFor="reason" className="field-label">
                    {a.appointment.cancelReason}
                  </label>
                  <input id="reason" name="reason" className="input" maxLength={500} />
                </div>
                <SubmitButton variant="danger" pendingLabel={a.common.saving}>
                  {a.appointment.cancel}
                </SubmitButton>
              </AdminForm>
            )}
          </Card>

          {canMove && (
            <Card title={a.appointment.reschedule}>
              <AdminForm action={moveAppointment} className="grid gap-4 sm:grid-cols-3">
                <input type="hidden" name="id" value={appt.id} />
                <div>
                  <label htmlFor="mv-date" className="field-label">
                    {a.appointment.newDate}
                  </label>
                  <input id="mv-date" name="date" type="date" required defaultValue={zonedDateKey(appt.startsAt, tz)} className="input" />
                </div>
                <div>
                  <label htmlFor="mv-time" className="field-label">
                    {a.appointment.newTime}
                  </label>
                  <input
                    id="mv-time"
                    name="time"
                    type="time"
                    step={300}
                    required
                    defaultValue={minutesToHHMM(zonedMinutes(appt.startsAt, tz))}
                    className="input"
                  />
                </div>
                <div>
                  <label htmlFor="mv-doc" className="field-label">
                    {a.appointment.newDoctor}
                  </label>
                  <select id="mv-doc" name="doctorId" defaultValue={d.id} className="input">
                    {doctors.map((x) => (
                      <option key={x.id} value={x.id}>
                        {x.fullName}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2 sm:col-span-3">
                  <Checkbox name="override" label={a.appointment.override} hint={a.appointment.overrideHint} />
                  <Checkbox name="notify" label={a.appointment.notifyPatient} defaultChecked />
                </div>
                <div className="sm:col-span-3">
                  <SubmitButton pendingLabel={a.common.saving}>{a.appointment.rescheduleSubmit}</SubmitButton>
                </div>
              </AdminForm>
            </Card>
          )}

          <Card title={a.appointment.adminNotes}>
            <AdminForm action={saveNotes}>
              <input type="hidden" name="id" value={appt.id} />
              <label htmlFor="adminNotes" className="sr-only">
                {a.appointment.adminNotes}
              </label>
              <textarea
                id="adminNotes"
                name="adminNotes"
                defaultValue={appt.adminNotes ?? ""}
                rows={4}
                className="input"
                maxLength={4000}
              />
              <p className="field-hint">{a.appointment.adminNotesHint}</p>
              <div className="mt-3">
                <SubmitButton variant="secondary" pendingLabel={a.common.saving}>
                  {a.appointment.saveNotes}
                </SubmitButton>
              </div>
            </AdminForm>
          </Card>
        </div>

        <div className="space-y-6">
          <Card title={a.appointments.patient}>
            <p className="text-plum text-lg">{p.fullName}</p>
            <dl className="mt-4 space-y-3 text-sm">
              <div>
                <dt className="text-ink-muted text-xs">{a.appointment.phone}</dt>
                <dd className="flex flex-wrap gap-3">
                  <a href={telHref(p.phone)} className="link-quiet tabular-nums">
                    {formatPhoneDisplay(p.phone)}
                  </a>
                  <a href={whatsappHref(p.phone)} target="_blank" rel="noopener" className="link-quiet text-ink-muted">
                    WhatsApp
                  </a>
                </dd>
              </div>
              <div>
                <dt className="text-ink-muted text-xs">{a.appointment.email}</dt>
                <dd>
                  <a href={`mailto:${p.email}`} className="link-quiet break-all">
                    {p.email}
                  </a>
                </dd>
              </div>
              <div>
                <dt className="text-ink-muted text-xs">{a.appointment.language}</dt>
                <dd>{appt.locale === "en" ? a.common.english : a.common.albanian}</dd>
              </div>
              {p.isReturning !== null && (
                <div>
                  <dt className="text-ink-muted text-xs">{a.appointment.returning}</dt>
                  <dd>{p.isReturning ? a.common.yes : a.common.no}</dd>
                </div>
              )}
              <div>
                <dt className="text-ink-muted text-xs">{a.appointment.consents}</dt>
                <dd>
                  {a.appointment.consentSms}: {p.consentSms ? a.common.yes : a.common.no} · {a.appointment.consentWhatsapp}:{" "}
                  {p.consentWhatsapp ? a.common.yes : a.common.no}
                </dd>
              </div>
            </dl>
            {appt.patientNote && (
              <div className="border-line mt-5 border-t pt-4">
                <p className="text-ink-muted text-xs">{a.appointment.patientNote}</p>
                <p className="mt-1 text-sm whitespace-pre-line">{appt.patientNote}</p>
              </div>
            )}
            {can(user.role, "patients.erase") && p.fullName !== "Anonymised patient" && (
              <AdminForm action={erasePatient} confirmText={a.appointment.eraseHint} className="border-line mt-5 border-t pt-4">
                <input type="hidden" name="patientId" value={p.id} />
                <p className="text-ink-muted mb-3 text-xs">{a.appointment.eraseHint}</p>
                <SubmitButton variant="danger">{a.appointment.erase}</SubmitButton>
              </AdminForm>
            )}
          </Card>

          <Card title={a.appointment.messages}>
            {detail.messages.length ? (
              <ul className="space-y-3 text-sm">
                {detail.messages.map((m) => (
                  <li key={m.id} className="border-line border-b pb-3 last:border-0 last:pb-0">
                    <p className="flex flex-wrap justify-between gap-2">
                      <span>
                        {a.notifications.events[m.event]} · {m.channel}
                      </span>
                      <span className={m.status === "failed" ? "text-error" : m.status === "sent" ? "text-success" : "text-ink-muted"}>
                        {a.notifications.statuses[m.status]}
                      </span>
                    </p>
                    <p className="text-ink-muted text-xs">
                      {fmtDateTime(m.sentAt ?? m.createdAt, tz, tag)}
                      {m.lastError ? ` · ${m.lastError}` : ""}
                    </p>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-ink-muted text-sm">{a.appointment.noMessages}</p>
            )}
          </Card>

          <Card title={a.appointment.history}>
            <ul className="text-ink-muted space-y-2 text-xs">
              {detail.history.map((h) => (
                <li key={h.id}>
                  <span className="text-ink">{h.action.replace("appointment.", "")}</span> · {h.actorLabel} ·{" "}
                  {fmtDateTime(h.createdAt, tz, tag)}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </>
  );
}
