import Link from "next/link";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { listAppointments } from "@/lib/admin/queries";
import { getSettings } from "@/lib/settings";
import { isValidDateKey, startOfZonedDay, addDays } from "@/lib/time";
import { AppointmentList } from "@/components/admin/AppointmentList";
import { PageTitle } from "@/components/admin/fields";
import { schema } from "@/lib/db";

const PAGE = 50;

export default async function AppointmentsPage({ searchParams }: { searchParams: Promise<Record<string, string | undefined>> }) {
  const user = await requireUser("appointments.view");
  const { a, locale, tag } = await getAdminDict(user.locale);
  const sp = await searchParams;
  const settings = await getSettings();
  const tz = settings.timezone;
  const page = Math.max(0, Number(sp.page ?? 0) || 0);
  const upcoming = sp.upcoming === "1";
  const rows = await listAppointments({
    status: sp.status,
    q: sp.q?.slice(0, 100),
    from: sp.from && isValidDateKey(sp.from) ? startOfZonedDay(sp.from, tz) : undefined,
    to: sp.to && isValidDateKey(sp.to) ? startOfZonedDay(addDays(sp.to, 1), tz) : undefined,
    upcoming,
    limit: PAGE + 1,
    offset: page * PAGE,
  });
  const hasMore = rows.length > PAGE;
  const qs = (patch: Record<string, string | undefined>) => {
    const p = new URLSearchParams(Object.entries({ ...sp, ...patch }).filter(([, v]) => v) as [string, string][]);
    return `?${p}`;
  };

  return (
    <>
      <PageTitle
        title={a.appointments.title}
        actions={
          <Link href="/admin/appointments/new" className="btn btn-primary btn-sm">
            {a.nav.newAppointment}
          </Link>
        }
      />
      <form
        className="border-line mb-6 grid gap-3 rounded-lg border bg-white p-4 sm:grid-cols-2 lg:grid-cols-[2fr_1fr_1fr_1fr_auto]"
        role="search"
      >
        <div>
          <label htmlFor="q" className="field-label">
            {a.common.search}
          </label>
          <input id="q" name="q" defaultValue={sp.q ?? ""} placeholder={a.appointments.searchPlaceholder} className="input" />
        </div>
        <div>
          <label htmlFor="status" className="field-label">
            {a.appointments.status}
          </label>
          <select id="status" name="status" defaultValue={sp.status ?? ""} className="input">
            <option value="">{a.common.all}</option>
            {schema.appointmentStatus.enumValues.map((s) => (
              <option key={s} value={s}>
                {a.status[s]}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="from" className="field-label">
            {a.appointments.from}
          </label>
          <input id="from" name="from" type="date" defaultValue={sp.from ?? ""} className="input" />
        </div>
        <div>
          <label htmlFor="to" className="field-label">
            {a.appointments.to}
          </label>
          <input id="to" name="to" type="date" defaultValue={sp.to ?? ""} className="input" />
        </div>
        <div className="flex flex-wrap items-end gap-2">
          <label className="flex h-12 items-center gap-2 text-sm">
            <input type="checkbox" name="upcoming" value="1" defaultChecked={upcoming} className="checkbox" />
            {a.appointments.upcomingOnly}
          </label>
          <button className="btn btn-secondary btn-sm">{a.common.filter}</button>
          <Link href="/admin/appointments" className="btn btn-sm text-ink-muted">
            {a.common.clear}
          </Link>
        </div>
      </form>
      <AppointmentList rows={rows.slice(0, PAGE)} a={a} tz={tz} tag={tag} locale={locale} empty={a.appointments.empty} />
      {(page > 0 || hasMore) && (
        <nav className="mt-6 flex justify-between" aria-label="Pagination">
          {page > 0 ? (
            <Link className="btn btn-secondary btn-sm" href={qs({ page: String(page - 1) })}>
              {a.common.previous}
            </Link>
          ) : (
            <span />
          )}
          {hasMore && (
            <Link className="btn btn-secondary btn-sm" href={qs({ page: String(page + 1) })}>
              {a.common.next}
            </Link>
          )}
        </nav>
      )}
    </>
  );
}
