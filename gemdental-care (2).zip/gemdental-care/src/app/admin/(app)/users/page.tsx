import { asc } from "drizzle-orm";
import { requireUser } from "@/lib/auth/session";
import { getAdminDict } from "@/lib/admin/i18n";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { fmtDateTime } from "@/lib/admin/format";
import { AdminForm, SubmitButton } from "@/components/admin/AdminForm";
import { Card, Checkbox, PageTitle, Select, TextField } from "@/components/admin/fields";
import { createUser, updateUser } from "../../actions/users";

export default async function UsersPage() {
  const user = await requireUser("users.manage");
  const { a, tag } = await getAdminDict(user.locale);
  const u = a.users;
  const tz = (await getSettings()).timezone;
  const users = await db().select().from(schema.adminUsers).orderBy(asc(schema.adminUsers.createdAt));
  const roleOptions = (["owner", "manager", "staff"] as const).map((r) => ({ value: r, label: u.roles[r] }));
  return (
    <>
      <PageTitle title={u.title} lead={u.lead} />
      <div className="space-y-3">
        {users.map((x) => (
          <details key={x.id} className="border-line rounded-lg border bg-white">
            <summary className="flex cursor-pointer flex-wrap items-center justify-between gap-3 px-5 py-4">
              <span>
                <span className="text-plum font-medium">{x.name}</span> <span className="text-ink-muted text-sm">{x.email}</span>
              </span>
              <span className="flex gap-2 text-xs">
                <span className="bg-cream rounded-full px-2 py-0.5">{u.roles[x.role]}</span>
                {!x.active && (
                  <span className="bg-error-bg text-error rounded-full px-2 py-0.5">
                    {u.active}: {a.common.no}
                  </span>
                )}
              </span>
            </summary>
            <div className="border-line border-t p-5">
              <p className="text-ink-muted mb-4 text-xs">
                {u.lastLogin}: {x.lastLoginAt ? fmtDateTime(x.lastLoginAt, tz, tag) : u.never}
              </p>
              <AdminForm action={updateUser} className="grid gap-4 sm:grid-cols-3">
                <input type="hidden" name="id" value={x.id} />
                <Select name="role" label={u.role} defaultValue={x.role} options={roleOptions} />
                <TextField name="newPassword" type="password" label={u.resetPassword} autoComplete="new-password" hint={u.passwordHint} />
                <div className="pt-8">
                  <Checkbox name="active" label={u.active} defaultChecked={x.active} />
                </div>
                <div className="sm:col-span-3">
                  <SubmitButton pendingLabel={a.common.saving}>{a.common.save}</SubmitButton>
                </div>
              </AdminForm>
            </div>
          </details>
        ))}
      </div>
      <Card title={u.add} className="mt-8 max-w-3xl">
        <AdminForm action={createUser} className="grid gap-4 sm:grid-cols-2" resetOnSuccess>
          <TextField name="name" label={u.name} required autoComplete="off" />
          <TextField name="email" type="email" label={u.email} required autoComplete="off" />
          <Select name="role" label={u.role} defaultValue="staff" options={roleOptions} />
          <TextField name="password" type="password" label={u.password} hint={u.passwordHint} required autoComplete="new-password" />
          <div className="sm:col-span-2">
            <SubmitButton pendingLabel={a.common.saving}>{u.add}</SubmitButton>
          </div>
        </AdminForm>
      </Card>
    </>
  );
}
