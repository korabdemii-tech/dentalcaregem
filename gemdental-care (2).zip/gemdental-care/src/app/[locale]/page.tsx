import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { pick, pickList } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { getSettings } from "@/lib/settings";
import {
  getMediaMeta,
  getPublishedDoctors,
  getPublishedFaqs,
  getPublishedServices,
  getPublishedTestimonials,
  getSiteImages,
  mediaUrl,
} from "@/lib/content";
import { directionsHref, formatPhoneDisplay, fullAddress, openingHoursLines, telHref } from "@/lib/clinic-info";
import { pageMetadata } from "@/lib/seo";
import { ImageSlot } from "@/components/site/ImageSlot";
import { HeroTooth } from "@/components/site/HeroTooth";
import { ServiceCard } from "@/components/site/ServiceCard";
import { Journey } from "@/components/site/Journey";
import { Accordion } from "@/components/site/Accordion";
import { ResultsShowcase } from "@/components/gallery/ResultsShowcase";
import { SmileMarquee } from "@/components/gallery/SmileMarquee";
import { HeroResultCard } from "@/components/gallery/HeroResultCard";
import { getGalleryData, galleryStrings } from "@/lib/gallery";
import { MarkOutline } from "@/components/brand/Logo";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({
    locale,
    path: "",
    title: `GemDental Care · ${t.meta.titles.home}`,
    description: t.meta.defaultDescription,
  });
}

export default async function HomePage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const [settings, services, doctors, faqs, testimonials, gallery, images] = await Promise.all([
    getSettings(),
    getPublishedServices(),
    getPublishedDoctors(),
    getPublishedFaqs(),
    getPublishedTestimonials(),
    getGalleryData(locale),
    getSiteImages(),
  ]);
  const base = `/${locale}`;
  const media = await getMediaMeta([...services.map((s) => s.imageMediaId), ...doctors.map((d) => d.photoMediaId)]);
  const { cases, smiles } = gallery;
  const imageFor = (id: string | null) => {
    const m = id ? media.get(id) : undefined;
    return m && id ? { src: mediaUrl(id)!, width: m.width, height: m.height, alt: pick(m.alt, locale) } : null;
  };

  const featured = services.slice(0, 6);
  const doctor = doctors[0];
  const address = fullAddress(settings, locale);
  const hours = openingHoursLines(settings, t.days, t.common.closed);
  const directions = directionsHref(settings, locale);
  const tbc = <span className="text-ink-muted italic">{t.common.toBeConfirmed}</span>;
  const about = images.about;
  const aboutSecondary = images["about-secondary"];

  return (
    <>
      {/* ── Hero ─────────────────────────────────────────── */}
      <section className="relative overflow-hidden">
        <MarkOutline
          className="pointer-events-none absolute top-[-12%] left-[38%] hidden h-[135%] w-auto max-w-none opacity-60 lg:block"
          tone="champagne"
        />
        <div className="container-gd relative grid items-center gap-10 pt-8 pb-14 md:pt-12 lg:grid-cols-12 lg:gap-8 lg:pt-16 lg:pb-24">
          <div className="hero-enter lg:col-span-6 lg:pr-6">
            <h1 className="font-display text-plum text-4xl text-balance">{t.home.heroTitle}</h1>
            <p className="measure text-ink-muted mt-7 text-lg">{t.home.heroLead}</p>
            <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
              <Link href={`${base}/booking`} className="btn btn-primary">
                {t.home.heroPrimary}
              </Link>
              <Link href={`${base}/services`} className="btn btn-secondary">
                {t.home.heroSecondary}
              </Link>
            </div>
            <span aria-hidden className="bg-champagne-ink/60 mt-12 hidden h-px w-24 lg:block" />
          </div>
          <div className="relative lg:col-span-6">
            <div className="hero-image-enter">
              <HeroTooth className="mx-auto aspect-[5/6] w-full max-w-[22rem] sm:max-w-[26rem] lg:max-w-[34rem]" />
            </div>
            {cases[0] && <HeroResultCard item={cases[0]} href="#results" title={t.results.heroCardTitle} link={t.results.heroCardLink} />}
          </div>
        </div>
      </section>

      {/* ── Quick clinic information ─────────────────────── */}
      <section aria-label={t.home.info.contact} className="border-line border-y bg-white">
        <dl className="container-gd divide-line grid grid-cols-1 divide-y sm:grid-cols-2 sm:divide-y-0 lg:grid-cols-4 lg:divide-x">
          <div className="py-6 sm:pr-6 lg:py-8">
            <dt className="text-ink-muted text-xs">{t.home.info.location}</dt>
            <dd className="mt-1.5">
              {address ? (
                directions ? (
                  <a href={directions} target="_blank" rel="noopener" className="link-quiet">
                    {address}
                  </a>
                ) : (
                  address
                )
              ) : (
                tbc
              )}
            </dd>
          </div>
          <div className="py-6 sm:pl-6 lg:py-8">
            <dt className="text-ink-muted text-xs">{t.home.info.hours}</dt>
            <dd className="mt-1.5">
              {hours.length ? (
                <>
                  <span>
                    {hours[0].days} · {hours[0].hours}
                  </span>
                  {hours.length > 1 && (
                    <Link href={`${base}/contact`} className="link-quiet text-ink-muted mt-0.5 block text-sm">
                      {t.home.info.hoursSeeContact}
                    </Link>
                  )}
                </>
              ) : (
                tbc
              )}
            </dd>
          </div>
          <div className="py-6 sm:pr-6 lg:py-8 lg:pl-6">
            <dt className="text-ink-muted text-xs">{t.home.info.contact}</dt>
            <dd className="mt-1.5">
              {settings.phone ? (
                <a href={telHref(settings.phone)} className="link-quiet tabular-nums">
                  {formatPhoneDisplay(settings.phone)}
                </a>
              ) : (
                tbc
              )}
            </dd>
          </div>
          <div className="py-6 sm:pl-6 lg:py-8">
            <dt className="text-ink-muted text-xs">{t.home.info.booking}</dt>
            <dd className="mt-1.5">
              <Link href={`${base}/booking`} className="link-quiet text-plum">
                {t.home.info.bookingValue}
              </Link>
            </dd>
          </div>
        </dl>
      </section>

      {/* ── Treatments ───────────────────────────────────── */}
      <section className="section-y" aria-labelledby="treatments-title">
        <div className="container-gd">
          <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
            <h2 id="treatments-title" data-reveal className="font-display text-plum text-3xl lg:col-span-5">
              {t.home.treatmentsTitle}
            </h2>
            <p data-reveal style={{ ["--i" as string]: 1 }} className="measure text-ink-muted lg:col-span-6 lg:col-start-7">
              {t.home.treatmentsLead}
            </p>
          </div>
          {featured.length ? (
            <>
              <ul className="mt-12 grid gap-5 sm:grid-cols-2 lg:mt-16 lg:grid-cols-3 lg:gap-6">
                {featured.map((s, i) => (
                  <li key={s.id} data-reveal style={{ ["--i" as string]: i % 3 }}>
                    <ServiceCard
                      href={`${base}/services/${s.slug}`}
                      bookHref={`${base}/booking?service=${s.slug}`}
                      name={pick(s.name, locale)}
                      summary={pick(s.summary, locale)}
                      duration={s.durationVisible ? fmt(t.common.minutes, { n: s.durationMinutes }) : null}
                      image={imageFor(s.imageMediaId)}
                      labels={{ learnMore: t.common.learnMore, book: t.common.book, placeholder: t.preview.placeholderPhoto }}
                      feature={i === 0}
                    />
                  </li>
                ))}
              </ul>
              {services.length > featured.length && (
                <div className="mt-10 flex justify-center">
                  <Link href={`${base}/services`} className="btn btn-secondary">
                    {t.common.viewAll}
                  </Link>
                </div>
              )}
            </>
          ) : (
            <div className="border-line mt-12 border bg-white p-8">
              <p className="measure text-ink-muted">{t.home.treatmentsEmpty}</p>
              <Link href={`${base}/booking`} className="btn btn-primary mt-6">
                {t.home.heroPrimary}
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* ── About (real clinic photographs) ─────────────── */}
      <section className="bg-cream section-y overflow-hidden" aria-labelledby="about-title">
        <div className="container-gd grid items-center gap-14 lg:grid-cols-12 lg:gap-8">
          <div className="relative lg:col-span-6" data-parallax>
            <div className="relative mr-[22%] sm:mr-[30%]" data-reveal="unveil">
              <div data-depth style={{ ["--depth" as string]: "-10px" }} className="facet facet-lg">
                <ImageSlot
                  src={about?.url}
                  width={about?.width}
                  height={about?.height}
                  alt={about?.alt[locale] ?? ""}
                  placeholderLabel={t.preview.placeholderPhoto}
                  tone="champagne"
                  className="aspect-[4/5]"
                  sizes="(min-width:1024px) 34vw, 80vw"
                />
              </div>
            </div>
            <div className="absolute right-0 bottom-[-8%] w-[46%] sm:w-[40%]" data-reveal style={{ ["--i" as string]: 2 }}>
              <div
                data-depth
                style={{ ["--depth" as string]: "16px" }}
                className="border-cream border-[6px] shadow-[0_30px_60px_-25px_rgb(56_42_53/0.5)] sm:border-8"
              >
                <ImageSlot
                  src={aboutSecondary?.url}
                  width={aboutSecondary?.width}
                  height={aboutSecondary?.height}
                  alt={aboutSecondary?.alt[locale] ?? ""}
                  placeholderLabel=""
                  showLabel={false}
                  tone="plum"
                  className="aspect-[3/4]"
                  sizes="(min-width:1024px) 16vw, 40vw"
                />
              </div>
            </div>
            {about?.authentic && (
              <span
                data-depth
                style={{ ["--depth" as string]: "24px" }}
                className="glass text-plum absolute top-6 left-4 flex items-center gap-2 rounded-full px-4 py-2 text-xs tracking-[0.12em] uppercase sm:left-6"
              >
                <span aria-hidden className="bg-champagne-ink block h-1.5 w-1.5 rotate-45" />
                {t.results.clinicChip}
              </span>
            )}
          </div>
          <div className="mt-6 lg:col-span-5 lg:col-start-8 lg:mt-0" data-reveal>
            <h2 id="about-title" className="font-display text-plum text-3xl text-balance">
              {t.home.aboutTitle}
            </h2>
            {t.home.aboutBody.map((p) => (
              <p key={p} className="measure text-ink-muted mt-6">
                {p}
              </p>
            ))}
            <Link href={`${base}/about`} className="link-underline text-plum mt-8 inline-block">
              {t.home.aboutLink}
            </Link>
          </div>
        </div>
      </section>

      {/* ── Before & after (only clinic-approved cases with consent) ── */}
      {cases.length > 0 && (
        <ResultsShowcase
          cases={cases}
          strings={galleryStrings(t.results)}
          allHref={`${base}/results`}
          text={{
            eyebrow: t.results.eyebrow,
            title: t.results.title,
            lead: t.results.lead,
            viewAll: t.results.viewAll,
            consent: t.results.consent,
          }}
        />
      )}

      {/* ── Why GemDental ────────────────────────────────── */}
      <section className="section-y" aria-labelledby="why-title">
        <div className="container-gd">
          <h2 id="why-title" data-reveal className="font-display text-plum text-3xl">
            {t.home.whyTitle}
          </h2>
          <ul className="mt-12 grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-4">
            {t.home.why.map((w, i) => (
              <li key={w.title} data-reveal style={{ ["--i" as string]: i }} className="border-plum/25 border-t pt-6">
                <span aria-hidden className="bg-champagne-ink block h-2 w-2 rotate-45" />
                <h3 className="text-plum mt-5 text-lg font-medium">{w.title}</h3>
                <p className="text-ink-muted mt-2 text-[0.9375rem]">{w.body}</p>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* ── Doctor ───────────────────────────────────────── */}
      {doctor && (
        <section className="border-line section-y border-t bg-white" aria-labelledby="doctor-title">
          <div className="container-gd grid items-center gap-10 md:grid-cols-12 lg:gap-16">
            <div className="md:col-span-5 lg:col-span-4" data-reveal="unveil">
              <div className="facet">
                <ImageSlot
                  src={imageFor(doctor.photoMediaId)?.src}
                  width={imageFor(doctor.photoMediaId)?.width}
                  height={imageFor(doctor.photoMediaId)?.height}
                  alt={doctor.fullName}
                  placeholderLabel={t.team.portraitPending}
                  tone="plum"
                  className="aspect-[4/5]"
                  sizes="(min-width:768px) 35vw, 100vw"
                />
              </div>
            </div>
            <div className="md:col-span-7 lg:col-span-6 lg:col-start-6" data-reveal>
              <p id="doctor-title" className="text-champagne-ink text-sm">
                {t.home.doctorTitle}
              </p>
              <h2 className="font-display text-plum mt-3 text-3xl">{doctor.fullName}</h2>
              {pick(doctor.title, locale) && <p className="text-ink-muted mt-2">{pick(doctor.title, locale)}</p>}
              <p className="measure text-ink-muted mt-6">{pick(doctor.bio, locale) || t.home.doctorProfileSoon}</p>
              {pickList(doctor.specialties, locale).length > 0 && (
                <ul className="mt-6 flex flex-wrap gap-2">
                  {pickList(doctor.specialties, locale).map((s) => (
                    <li key={s} className="border-line text-ink-muted rounded-full border px-3 py-1 text-sm">
                      {s}
                    </li>
                  ))}
                </ul>
              )}
              <Link href={`${base}/team`} className="link-underline text-plum mt-8 inline-block">
                {t.home.doctorLink}
              </Link>
            </div>
          </div>
        </section>
      )}

      {/* ── Patient journey ──────────────────────────────── */}
      <section className="border-line section-y border-t" aria-labelledby="journey-title">
        <div className="container-gd">
          <div className="grid gap-6 lg:grid-cols-12 lg:items-end">
            <h2 id="journey-title" data-reveal className="font-display text-plum text-3xl lg:col-span-6">
              {t.home.journeyTitle}
            </h2>
            <p className="text-ink-muted lg:col-span-5 lg:col-start-8">{t.home.journeyLead}</p>
          </div>
          <div className="mt-14" data-reveal style={{ ["--i" as string]: 1 }}>
            <Journey steps={t.home.journey} />
          </div>
          <Link href={`${base}/booking`} className="btn btn-primary mt-14">
            {t.home.heroPrimary}
          </Link>
        </div>
      </section>

      {/* ── Reviews (only verified, published reviews) ───── */}
      {testimonials.length > 0 && (
        <section className="section-y" aria-labelledby="reviews-title">
          <div className="container-gd">
            <h2 id="reviews-title" className="font-display text-plum text-3xl">
              {t.home.reviewsTitle}
            </h2>
            <ul className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {testimonials.map((r, i) => (
                <li
                  key={r.id}
                  data-reveal
                  data-spotlight
                  style={{ ["--i" as string]: i % 3 }}
                  className="border-line flex flex-col border bg-white p-7"
                >
                  <blockquote lang={r.locale} className="font-display text-plum text-xl leading-snug">
                    “{r.body}”
                  </blockquote>
                  <p className="text-ink-muted mt-auto pt-6 text-sm">
                    {r.authorName}
                    {r.source && (
                      <>
                        {" · "}
                        {r.sourceUrl ? (
                          <a href={r.sourceUrl} target="_blank" rel="noopener" className="link-quiet">
                            {r.source}
                          </a>
                        ) : (
                          r.source
                        )}
                      </>
                    )}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {/* ── FAQ ──────────────────────────────────────────── */}
      {faqs.length > 0 && (
        <section className="border-line section-y border-t" aria-labelledby="faq-title">
          <div className="container-gd grid gap-10 lg:grid-cols-12">
            <div className="lg:col-span-4" data-reveal>
              <h2 id="faq-title" className="font-display text-plum text-3xl">
                {t.home.faqTitle}
              </h2>
              <p className="text-ink-muted mt-6">{t.home.faqMore}</p>
              <Link href={`${base}/contact`} className="link-underline text-plum mt-2 inline-block">
                {t.home.faqContact}
              </Link>
            </div>
            <div className="lg:col-span-7 lg:col-start-6">
              <Accordion items={faqs.map((f) => ({ id: f.id, question: pick(f.question, locale), answer: pick(f.answer, locale) }))} />
            </div>
          </div>
        </section>
      )}

      {/* ── Smiles marquee ─────────────────────────────────── */}
      <SmileMarquee cases={cases} smiles={smiles} href={`${base}/results`} title={t.results.marqueeTitle} beforeLabel={t.results.before} />

      {/* ── Final call to action ─────────────────────────── */}
      <section className="on-dark bg-plum relative overflow-hidden text-white">
        <MarkOutline
          tone="champagne"
          className="pointer-events-none absolute top-1/2 right-[-6%] h-[170%] w-auto max-w-none -translate-y-1/2 opacity-30"
        />
        <div className="container-gd relative py-24 md:py-32" data-reveal>
          <h2 className="font-display max-w-3xl text-4xl text-balance text-white">{t.home.ctaTitle}</h2>
          <p className="measure text-mauve-light mt-6 text-lg">{t.home.ctaBody}</p>
          <div className="mt-10 flex flex-col gap-3 sm:flex-row">
            <Link href={`${base}/booking`} className="btn btn-champagne">
              {t.home.ctaButton}
            </Link>
            {settings.phone && (
              <a href={telHref(settings.phone)} className="btn btn-ghost-light">
                {t.common.callUs} {formatPhoneDisplay(settings.phone)}
              </a>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
