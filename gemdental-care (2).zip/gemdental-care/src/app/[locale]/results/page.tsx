import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { pageMetadata } from "@/lib/seo";
import { getGalleryData, galleryStrings } from "@/lib/gallery";
import { PageHeader } from "@/components/site/PageHeader";
import { ResultsGallery } from "@/components/gallery/ResultsGallery";
import { MarkOutline } from "@/components/brand/Logo";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/results", title: t.meta.titles.results, description: t.meta.descriptions.results });
}

export default async function ResultsPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const { cases, smiles, gems, hasAny } = await getGalleryData(locale);
  const r = t.results;

  return (
    <>
      <PageHeader title={r.pageTitle} lead={r.pageLead} crumbLabel={t.a11y.breadcrumb} crumbs={[{ href: base, label: t.nav.home }]} />
      {hasAny ? (
        <ResultsGallery
          cases={cases}
          smiles={smiles}
          gems={gems}
          strings={galleryStrings(r)}
          text={{
            casesTitle: r.casesTitle,
            smilesTitle: r.smilesTitle,
            smilesLead: r.smilesLead,
            gemsTitle: r.gemsTitle,
            gemsLead: r.gemsLead,
            showing: r.showing,
          }}
        />
      ) : (
        <section className="section-y">
          <div className="container-gd">
            <p className="measure text-ink-muted">{r.empty}</p>
          </div>
        </section>
      )}
      {hasAny && (
        <section className="container-gd pb-6">
          <p className="text-ink-muted text-sm">{r.consent}</p>
        </section>
      )}
      <section className="on-dark bg-plum relative mt-10 overflow-hidden text-white">
        <MarkOutline
          tone="champagne"
          className="pointer-events-none absolute top-1/2 right-[-6%] h-[170%] w-auto max-w-none -translate-y-1/2 opacity-30"
        />
        <div className="container-gd relative py-20 md:py-28" data-reveal>
          <h2 className="font-display max-w-3xl text-4xl text-balance text-white">{r.ctaTitle}</h2>
          <p className="measure text-mauve-light mt-6 text-lg">{r.ctaBody}</p>
          <Link href={`${base}/booking`} className="btn btn-champagne mt-10">
            {t.home.ctaButton}
          </Link>
        </div>
      </section>
    </>
  );
}
