import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { pageMetadata } from "@/lib/seo";
import { directionsHref, formatPhoneDisplay, fullAddress, openingHoursLines, telHref, whatsappHref } from "@/lib/clinic-info";
import { PageHeader } from "@/components/site/PageHeader";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/contact", title: t.meta.titles.contact, description: t.meta.descriptions.contact });
}

export default async function ContactPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const s = await getSettings();
  const address = fullAddress(s, locale);
  const hours = openingHoursLines(s, t.days, t.common.closed);
  const directions = directionsHref(s, locale);
  const tbc = <span className="text-ink-muted italic">{t.common.toBeConfirmed}</span>;
  const social = Object.entries(s.social ?? {}).filter(([, v]) => v) as [string, string][];

  return (
    <>
      <PageHeader
        title={t.contact.title}
        lead={t.contact.lead}
        crumbLabel={t.a11y.breadcrumb}
        crumbs={[{ href: base, label: t.nav.home }]}
      />
      <section className="section-y !pt-14">
        <div className="container-gd grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-6">
            {/* One-tap actions, shown only for confirmed details */}
            {(s.phone || s.whatsapp || directions) && (
              <div className="mb-12 grid grid-cols-1 gap-3 sm:grid-cols-3">
                {s.phone && (
                  <a href={telHref(s.phone)} className="btn btn-primary">
                    {t.common.callUs}
                  </a>
                )}
                {s.whatsapp && (
                  <a href={whatsappHref(s.whatsapp)} target="_blank" rel="noopener" className="btn btn-secondary">
                    {t.common.whatsapp}
                  </a>
                )}
                {directions && (
                  <a href={directions} target="_blank" rel="noopener" className="btn btn-secondary">
                    {t.common.directions}
                  </a>
                )}
              </div>
            )}
            <dl className="divide-line border-line divide-y border-y">
              {[
                [t.contact.address, address ? <address className="not-italic">{address}</address> : tbc],
                [
                  t.contact.phone,
                  s.phone ? (
                    <a href={telHref(s.phone)} className="link-quiet tabular-nums">
                      {formatPhoneDisplay(s.phone)}
                    </a>
                  ) : (
                    tbc
                  ),
                ],
                [
                  t.contact.whatsapp,
                  s.whatsapp ? (
                    <a href={whatsappHref(s.whatsapp)} target="_blank" rel="noopener" className="link-quiet tabular-nums">
                      {formatPhoneDisplay(s.whatsapp)}
                    </a>
                  ) : (
                    tbc
                  ),
                ],
                [
                  t.contact.email,
                  s.email ? (
                    <a href={`mailto:${s.email}`} className="link-quiet">
                      {s.email}
                    </a>
                  ) : (
                    tbc
                  ),
                ],
              ].map(([label, value], i) => (
                <div key={i} className="grid gap-1 py-5 sm:grid-cols-3 sm:gap-6">
                  <dt className="text-ink-muted text-sm">{label}</dt>
                  <dd className="sm:col-span-2">{value}</dd>
                </div>
              ))}
              <div className="grid gap-1 py-5 sm:grid-cols-3 sm:gap-6">
                <dt className="text-ink-muted text-sm">{t.contact.hours}</dt>
                <dd className="sm:col-span-2">
                  {hours.length ? (
                    <table className="w-full max-w-sm text-left">
                      <tbody>
                        {hours.map((h) => (
                          <tr key={h.days}>
                            <th scope="row" className="py-0.5 pr-4 font-normal">
                              {h.days}
                            </th>
                            <td className="py-0.5 text-right tabular-nums">{h.hours}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  ) : (
                    tbc
                  )}
                </dd>
              </div>
              {social.length > 0 && (
                <div className="grid gap-1 py-5 sm:grid-cols-3 sm:gap-6">
                  <dt className="text-ink-muted text-sm">{t.contact.social}</dt>
                  <dd className="flex flex-wrap gap-4 sm:col-span-2">
                    {social.map(([n, url]) => (
                      <a key={n} href={url} target="_blank" rel="noopener" className="link-quiet capitalize">
                        {n}
                      </a>
                    ))}
                  </dd>
                </div>
              )}
            </dl>
            <p className="text-ink-muted mt-8 text-sm">{t.contact.emergency}</p>
          </div>
          <div className="lg:col-span-5 lg:col-start-8">
            <div className="facet facet-lg bg-cream relative grid aspect-[4/3] place-items-center overflow-hidden p-8 text-center">
              {directions && address ? (
                <a href={directions} target="_blank" rel="noopener" className="btn btn-primary">
                  {t.contact.getDirections}
                </a>
              ) : (
                <p className="measure text-ink-muted text-sm">{t.contact.mapPending}</p>
              )}
            </div>
            <div className="on-dark bg-plum mt-6 p-8 text-white">
              <h2 className="font-display text-2xl">{t.contact.bookOnline}</h2>
              <p className="text-mauve-light mt-2">{t.contact.bookOnlineBody}</p>
              <Link href={`${base}/booking`} className="btn btn-champagne mt-6">
                {t.nav.book}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
