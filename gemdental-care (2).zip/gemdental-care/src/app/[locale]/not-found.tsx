"use client";

import Link from "next/link";
import { useParams } from "next/navigation";

// Client component so it can read the [locale] segment; copy mirrors the dictionaries' notFound keys.
const COPY = {
  en: {
    title: "We couldn't find that page",
    body: "The link may be out of date, or the page may have moved.",
    home: "Go to the homepage",
    book: "Book an appointment",
  },
  sq: {
    title: "Nuk e gjetëm këtë faqe",
    body: "Lidhja mund të jetë e vjetër, ose faqja mund të jetë zhvendosur.",
    home: "Shko te faqja kryesore",
    book: "Rezervo një termin",
  },
} as const;

export default function NotFound() {
  const params = useParams<{ locale?: string }>();
  const locale = params?.locale === "en" ? "en" : "sq";
  const t = COPY[locale];
  return (
    <section className="container-gd section-y">
      <p className="font-display text-champagne-ink text-xl">404</p>
      <h1 className="font-display text-plum mt-3 text-3xl">{t.title}</h1>
      <p className="measure text-ink-muted mt-4">{t.body}</p>
      <div className="mt-8 flex flex-col gap-3 sm:flex-row">
        <Link href={`/${locale}`} className="btn btn-primary">
          {t.home}
        </Link>
        <Link href={`/${locale}/booking`} className="btn btn-secondary">
          {t.book}
        </Link>
      </div>
    </section>
  );
}
