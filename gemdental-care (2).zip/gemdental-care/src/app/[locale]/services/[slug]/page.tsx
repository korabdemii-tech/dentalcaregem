import Link from "next/link";
import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { pick } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { getDoctorsForService, getMediaMeta, getPublishedServices, getServiceBySlug, mediaUrl } from "@/lib/content";
import { pageMetadata, jsonLd } from "@/lib/seo";
import { env } from "@/lib/env";
import { PageHeader } from "@/components/site/PageHeader";
import { ImageSlot } from "@/components/site/ImageSlot";

type Params = Promise<{ locale: string; slug: string }>;

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { locale: l, slug } = await params;
  const locale = resolveLocale(l);
  const service = await getServiceBySlug(slug);
  if (!service) return {};
  return pageMetadata({
    locale,
    path: `/services/${slug}`,
    title: pick(service.name, locale),
    description: pick(service.summary, locale),
    image: service.imageMediaId ? mediaUrl(service.imageMediaId) : null,
  });
}

export default async function ServicePage({ params }: { params: Params }) {
  const { locale: l, slug } = await params;
  const locale = resolveLocale(l);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const service = await getServiceBySlug(slug);
  if (!service) notFound();
  const [doctors, all, media] = await Promise.all([
    getDoctorsForService(service.id),
    getPublishedServices(),
    getMediaMeta([service.imageMediaId]),
  ]);
  const m = service.imageMediaId ? media.get(service.imageMediaId) : undefined;
  const name = pick(service.name, locale);
  const paragraphs = pick(service.description, locale)
    .split(/\n{2,}/)
    .filter(Boolean);
  const others = all.filter((s) => s.id !== service.id).slice(0, 4);
  const price = service.priceVisible ? pick(service.price, locale) : "";

  const structured = {
    "@context": "https://schema.org",
    "@type": "MedicalProcedure",
    name,
    description: pick(service.summary, locale),
    url: `${env.siteUrl}${base}/services/${service.slug}`,
    provider: { "@id": `${env.siteUrl}/#clinic` },
  };

  return (
    <>
      <PageHeader
        title={name}
        lead={pick(service.summary, locale)}
        crumbLabel={t.a11y.breadcrumb}
        crumbs={[
          { href: base, label: t.nav.home },
          { href: `${base}/services`, label: t.nav.treatments },
        ]}
      />
      <section className="section-y !pt-14">
        <div className="container-gd grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="facet facet-lg">
              <ImageSlot
                src={m ? mediaUrl(service.imageMediaId) : null}
                width={m?.width}
                height={m?.height}
                alt={m ? pick(m.alt, locale) : ""}
                placeholderLabel={t.preview.placeholderPhoto}
                className="aspect-[16/10]"
                priority
              />
            </div>
            {paragraphs.length > 0 && (
              <div className="mt-12">
                <h2 className="font-display text-plum text-2xl">{t.services.detailWhat}</h2>
                {paragraphs.map((p) => (
                  <p key={p} className="measure-wide text-ink-muted mt-5">
                    {p}
                  </p>
                ))}
              </div>
            )}
            <p className="measure-wide border-champagne text-ink-muted mt-8 border-l-2 pl-4 text-sm">{t.services.detailCaveat}</p>
          </div>
          <aside className="lg:col-span-4 lg:col-start-9">
            <div className="border-line sticky top-[calc(var(--gd-header-h)+1.5rem)] border bg-white p-7">
              <h2 className="text-champagne-ink text-sm">{t.services.detailAside}</h2>
              <dl className="divide-line mt-4 divide-y text-[0.9375rem]">
                {service.durationVisible && (
                  <div className="flex justify-between gap-4 py-3">
                    <dt className="text-ink-muted">{t.common.duration}</dt>
                    <dd className="tabular-nums">{fmt(t.common.minutes, { n: service.durationMinutes })}</dd>
                  </div>
                )}
                <div className="flex justify-between gap-4 py-3">
                  <dt className="text-ink-muted">{t.common.price}</dt>
                  <dd className="text-right">{price || t.common.priceOnRequest}</dd>
                </div>
                {doctors.length > 0 && (
                  <div className="flex justify-between gap-4 py-3">
                    <dt className="text-ink-muted">{t.common.doctor}</dt>
                    <dd className="text-right">{doctors.map((d) => d.fullName).join(", ")}</dd>
                  </div>
                )}
              </dl>
              {service.bookable && (
                <Link href={`${base}/booking?service=${service.slug}`} className="btn btn-primary mt-6 w-full">
                  {t.services.detailBook}
                </Link>
              )}
            </div>
          </aside>
        </div>
      </section>
      {others.length > 0 && (
        <section className="border-line bg-cream border-t py-16">
          <div className="container-gd">
            <h2 className="font-display text-plum text-2xl">{t.services.detailOther}</h2>
            <ul className="border-line bg-line mt-8 grid gap-px border sm:grid-cols-2 lg:grid-cols-4">
              {others.map((s) => (
                <li key={s.id} className="bg-ivory">
                  <Link href={`${base}/services/${s.slug}`} className="group block h-full p-6 hover:bg-white">
                    <span className="font-display text-plum text-xl">{pick(s.name, locale)}</span>
                    <span className="text-ink-muted mt-2 block text-sm">{pick(s.summary, locale)}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}
      <script type="application/ld+json" dangerouslySetInnerHTML={jsonLd(structured)} />
    </>
  );
}
