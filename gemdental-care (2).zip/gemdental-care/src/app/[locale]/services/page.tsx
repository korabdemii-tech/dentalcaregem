import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { pick } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { getMediaMeta, getPublishedServices, mediaUrl } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";
import { PageHeader } from "@/components/site/PageHeader";
import { ServiceCard } from "@/components/site/ServiceCard";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/services", title: t.meta.titles.services, description: t.meta.descriptions.services });
}

export default async function ServicesPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const services = await getPublishedServices();
  const media = await getMediaMeta(services.map((s) => s.imageMediaId));
  const consultation = services.find((s) => s.isConsultation);

  return (
    <>
      <PageHeader
        title={t.services.title}
        lead={t.services.lead}
        crumbLabel={t.a11y.breadcrumb}
        crumbs={[{ href: base, label: t.nav.home }]}
      />
      <section className="section-y !pt-14">
        <div className="container-gd">
          {services.length ? (
            <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3 lg:gap-6">
              {services.map((s) => {
                const m = s.imageMediaId ? media.get(s.imageMediaId) : undefined;
                return (
                  <li key={s.id}>
                    <ServiceCard
                      href={`${base}/services/${s.slug}`}
                      bookHref={`${base}/booking?service=${s.slug}`}
                      name={pick(s.name, locale)}
                      summary={pick(s.summary, locale)}
                      duration={s.durationVisible ? fmt(t.common.minutes, { n: s.durationMinutes }) : null}
                      image={m ? { src: mediaUrl(s.imageMediaId)!, width: m.width, height: m.height, alt: pick(m.alt, locale) } : null}
                      labels={{ learnMore: t.common.learnMore, book: t.common.book, placeholder: t.preview.placeholderPhoto }}
                    />
                  </li>
                );
              })}
            </ul>
          ) : (
            <p className="measure text-ink-muted">{t.home.treatmentsEmpty}</p>
          )}

          <div className="on-dark bg-plum mt-16 grid gap-6 p-8 text-white sm:p-12 md:grid-cols-12 md:items-center">
            <div className="md:col-span-8">
              <h2 className="font-display text-2xl">{t.services.notSure}</h2>
              <p className="text-mauve-light mt-3">{t.services.notSureBody}</p>
            </div>
            <div className="md:col-span-4 md:text-right">
              <Link href={`${base}/booking${consultation ? `?service=${consultation.slug}` : ""}`} className="btn btn-champagne">
                {t.services.notSureCta}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
