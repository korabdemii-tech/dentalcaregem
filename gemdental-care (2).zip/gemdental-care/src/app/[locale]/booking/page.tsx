import type { Metadata } from "next";
import Link from "next/link";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { LOCALE_TAG, pick } from "@/lib/i18n/config";
import { getSettings } from "@/lib/settings";
import { pageMetadata } from "@/lib/seo";
import { env } from "@/lib/env";
import { signToken } from "@/lib/security/token";
import { bookableServices, eligibleDoctors } from "@/lib/booking/availability-service";
import { getPublishedDoctors, mediaUrl } from "@/lib/content";
import { db, schema } from "@/lib/db";
import { eq } from "drizzle-orm";
import { BookingFlow } from "@/components/booking/BookingFlow";
import type { BookingDoctor, BookingService } from "@/components/booking/types";
import { formatPhoneDisplay, telHref } from "@/lib/clinic-info";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/booking", title: t.meta.titles.booking, description: t.meta.descriptions.booking });
}

export default async function BookingPage({
  params,
  searchParams,
}: {
  params: Promise<{ locale: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const locale = resolveLocale((await params).locale);
  const sp = await searchParams;
  const t = getDictionary(locale);
  const settings = await getSettings();
  const base = `/${locale}`;

  const svcRows = settings.onlineBookingEnabled ? await bookableServices() : [];
  const services: BookingService[] = await Promise.all(
    svcRows.map(async (s) => ({
      id: s.id,
      slug: s.slug,
      name: pick(s.name, locale),
      summary: pick(s.summary, locale),
      durationMinutes: s.durationVisible ? s.durationMinutes : null,
      price: s.priceVisible ? pick(s.price, locale) || null : null,
      isConsultation: s.isConsultation,
      doctorIds: (await eligibleDoctors(s.id)).map((d) => d.id),
    })),
  );
  const bookableIds = new Set(services.flatMap((s) => s.doctorIds));
  const publicDoctors = new Map((await getPublishedDoctors()).map((d) => [d.id, d]));
  const doctorRows = bookableIds.size ? await db().select().from(schema.doctors).where(eq(schema.doctors.active, true)) : [];
  const doctors: BookingDoctor[] = doctorRows
    .filter((d) => bookableIds.has(d.id))
    .map((d) => ({
      id: d.id,
      slug: d.slug,
      name: d.fullName,
      title: publicDoctors.has(d.id) ? pick(d.title, locale) : "",
      photoUrl: publicDoctors.has(d.id) ? mediaUrl(d.photoMediaId) : null,
    }));

  const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

  return (
    <>
      <section className="border-line border-b">
        <div className="container-gd pt-10 pb-10 md:pt-14">
          <h1 className="font-display text-plum text-4xl">{t.booking.title}</h1>
          <p className="measure text-ink-muted mt-4 text-lg">{t.booking.lead}</p>
        </div>
      </section>
      <section className="container-gd py-10 md:py-14">
        {!settings.onlineBookingEnabled ? (
          <div className="measure border-line border bg-white p-8">
            <p>{t.booking.disabled}</p>
            {settings.phone && (
              <a href={telHref(settings.phone)} className="btn btn-primary mt-6">
                {t.common.callUs} {formatPhoneDisplay(settings.phone)}
              </a>
            )}
            <Link href={`${base}/contact`} className="btn btn-secondary mt-6 ml-3">
              {t.nav.contact}
            </Link>
          </div>
        ) : (
          <BookingFlow
            services={services}
            doctors={doctors}
            initialToken={signToken({ iat: Date.now(), v: 1 })}
            initialServiceSlug={one(sp.service)}
            initialDoctorSlug={one(sp.doctor)}
            config={{
              locale,
              localeTag: LOCALE_TAG[locale],
              timezone: settings.timezone,
              autoConfirm: settings.autoConfirm,
              phoneCountry: settings.country,
              turnstileSiteKey: env.turnstile.siteKey || null,
              privacyHref: `${base}/privacy`,
              termsHref: `${base}/terms`,
              homeHref: base,
              clinicName: settings.clinicName,
            }}
            strings={{ booking: t.booking, errors: t.errors, dates: t.dates, minutes: t.common.minutes }}
          />
        )}
      </section>
    </>
  );
}
