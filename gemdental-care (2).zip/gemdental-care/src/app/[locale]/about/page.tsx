import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { getSiteImages } from "@/lib/content";
import { pageMetadata } from "@/lib/seo";
import { PageHeader } from "@/components/site/PageHeader";
import { ImageSlot } from "@/components/site/ImageSlot";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/about", title: t.meta.titles.about, description: t.meta.descriptions.about });
}

export default async function AboutPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const images = await getSiteImages();
  const img = images.about;
  const second = images["about-secondary"];
  return (
    <>
      <PageHeader title={t.about.title} lead={t.about.lead} crumbLabel={t.a11y.breadcrumb} crumbs={[{ href: base, label: t.nav.home }]} />
      <section className="section-y !pt-14">
        <div className="container-gd grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-[calc(var(--gd-header-h)+2rem)]" data-parallax>
              <div className="facet facet-lg" data-reveal="unveil">
                <ImageSlot
                  src={img?.url}
                  width={img?.width}
                  height={img?.height}
                  alt={img?.alt[locale] ?? ""}
                  placeholderLabel={t.preview.placeholderPhoto}
                  tone="plum"
                  className="aspect-[4/5]"
                  sizes="(min-width:1024px) 40vw, 100vw"
                />
              </div>
              {second && (
                <div
                  data-depth
                  style={{ ["--depth" as string]: "14px" }}
                  className="border-ivory relative -mt-24 ml-auto w-[48%] border-8 shadow-[0_30px_60px_-25px_rgb(56_42_53/0.5)] sm:-mt-32"
                >
                  <ImageSlot
                    src={second.url}
                    width={second.width}
                    height={second.height}
                    alt={second.alt[locale] ?? ""}
                    placeholderLabel=""
                    showLabel={false}
                    className="aspect-[3/4]"
                    sizes="(min-width:1024px) 20vw, 48vw"
                  />
                </div>
              )}
            </div>
          </div>
          <div className="lg:col-span-6 lg:col-start-7">
            {t.about.sections.map((s, i) => (
              <div key={s.title} data-reveal className={i ? "border-line mt-14 border-t pt-14" : ""}>
                <h2 className="font-display text-plum text-3xl">{s.title}</h2>
                <p className="measure text-ink-muted mt-5 text-lg">{s.body}</p>
              </div>
            ))}
            <p className="text-ink-muted mt-14 text-sm italic">{t.about.note}</p>
            <div className="mt-10 flex flex-col gap-3 sm:flex-row">
              <Link href={`${base}/booking`} className="btn btn-primary">
                {t.home.heroPrimary}
              </Link>
              <Link href={`${base}/team`} className="btn btn-secondary">
                {t.nav.doctor}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
