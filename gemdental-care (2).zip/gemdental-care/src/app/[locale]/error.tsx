"use client";

import { useEffect } from "react";
import { useParams } from "next/navigation";

// Kept dependency-free so it renders even when the server is unhealthy.
const COPY = {
  en: {
    title: "Something went wrong",
    body: "This page couldn't load. Please try again. If it keeps happening, contact the clinic by phone.",
    retry: "Try again",
  },
  sq: {
    title: "Diçka shkoi keq",
    body: "Kjo faqe nuk u ngarkua. Ju lutemi provoni përsëri. Nëse vazhdon, kontaktoni klinikën me telefon.",
    retry: "Provo përsëri",
  },
} as const;

export default function Error({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  const params = useParams<{ locale: string }>();
  const t = COPY[(params?.locale as keyof typeof COPY) ?? "sq"] ?? COPY.sq;
  useEffect(() => {
    console.error(error.digest ?? error.message);
  }, [error]);
  return (
    <section className="container-gd section-y">
      <h1 className="font-display text-plum text-3xl">{t.title}</h1>
      <p className="measure text-ink-muted mt-4">{t.body}</p>
      <button type="button" onClick={reset} className="btn btn-primary mt-8">
        {t.retry}
      </button>
    </section>
  );
}
