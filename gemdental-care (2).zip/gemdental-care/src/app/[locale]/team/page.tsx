import Link from "next/link";
import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { pick, pickList } from "@/lib/i18n/config";
import { fmt } from "@/lib/i18n/format";
import { getMediaMeta, getPublishedDoctors, mediaUrl } from "@/lib/content";
import { pageMetadata, jsonLd } from "@/lib/seo";
import { env } from "@/lib/env";
import { PageHeader } from "@/components/site/PageHeader";
import { ImageSlot } from "@/components/site/ImageSlot";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/team", title: t.meta.titles.team, description: t.meta.descriptions.team });
}

export default async function TeamPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const base = `/${locale}`;
  const doctors = await getPublishedDoctors();
  const media = await getMediaMeta(doctors.map((d) => d.photoMediaId));

  return (
    <>
      <PageHeader title={t.team.title} lead={t.team.lead} crumbLabel={t.a11y.breadcrumb} crumbs={[{ href: base, label: t.nav.home }]} />
      {doctors.map((d) => {
        const m = d.photoMediaId ? media.get(d.photoMediaId) : undefined;
        const lists: [string, string[]][] = [
          [t.team.specialties, pickList(d.specialties, locale)],
          [t.team.education, pickList(d.education, locale)],
          [t.team.qualifications, pickList(d.qualifications, locale)],
          [t.team.languages, pickList(d.languages, locale)],
        ];
        const experience = pick(d.experience, locale);
        const bio = pick(d.bio, locale);
        const hasDetails = bio || experience || lists.some(([, v]) => v.length);
        const person = {
          "@context": "https://schema.org",
          "@type": "Person",
          name: d.fullName,
          ...(pick(d.title, locale) ? { jobTitle: pick(d.title, locale) } : {}),
          worksFor: { "@id": `${env.siteUrl}/#clinic` },
          ...(m ? { image: `${env.siteUrl}${mediaUrl(d.photoMediaId)}` } : {}),
        };
        return (
          <section key={d.id} className="section-y !pt-14" aria-labelledby={`doc-${d.id}`}>
            <div className="container-gd grid gap-12 md:grid-cols-12">
              <div className="md:col-span-5 lg:col-span-4">
                <div className="facet">
                  <ImageSlot
                    src={m ? mediaUrl(d.photoMediaId) : null}
                    width={m?.width}
                    height={m?.height}
                    alt={d.fullName}
                    placeholderLabel={t.team.portraitPending}
                    tone="plum"
                    className="aspect-[4/5]"
                    priority
                    sizes="(min-width:768px) 35vw, 100vw"
                  />
                </div>
              </div>
              <div className="md:col-span-7 lg:col-span-7 lg:col-start-6">
                <h2 id={`doc-${d.id}`} className="font-display text-plum text-3xl">
                  {d.fullName}
                </h2>
                {pick(d.title, locale) && <p className="text-ink-muted mt-2 text-lg">{pick(d.title, locale)}</p>}
                {bio
                  ? bio.split(/\n{2,}/).map((p) => (
                      <p key={p} className="measure-wide text-ink-muted mt-6">
                        {p}
                      </p>
                    ))
                  : null}
                {!hasDetails && <p className="measure border-champagne text-ink-muted mt-6 border-l-2 pl-4">{t.team.profilePending}</p>}
                {experience && (
                  <div className="mt-10">
                    <h3 className="text-champagne-ink text-sm">{t.team.experience}</h3>
                    <p className="measure-wide text-ink-muted mt-2">{experience}</p>
                  </div>
                )}
                <dl className="mt-10 grid gap-8 sm:grid-cols-2">
                  {lists
                    .filter(([, v]) => v.length)
                    .map(([label, values]) => (
                      <div key={label}>
                        <dt className="text-champagne-ink text-sm">{label}</dt>
                        <dd className="mt-2">
                          <ul className="text-ink-muted space-y-1.5">
                            {values.map((v) => (
                              <li key={v}>{v}</li>
                            ))}
                          </ul>
                        </dd>
                      </div>
                    ))}
                </dl>
                {d.active && (
                  <Link href={`${base}/booking?doctor=${d.slug}`} className="btn btn-primary mt-12">
                    {fmt(t.team.bookWith, { name: d.fullName })}
                  </Link>
                )}
              </div>
            </div>
            <script type="application/ld+json" dangerouslySetInnerHTML={jsonLd(person)} />
          </section>
        );
      })}
    </>
  );
}
