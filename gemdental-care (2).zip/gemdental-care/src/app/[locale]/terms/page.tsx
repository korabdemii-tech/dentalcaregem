import type { Metadata } from "next";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { getSettings } from "@/lib/settings";
import { pageMetadata } from "@/lib/seo";
import { termsEn } from "@/lib/i18n/legal/en";
import { termsSq } from "@/lib/i18n/legal/sq";
import { LegalPage } from "@/components/site/LegalPage";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return pageMetadata({ locale, path: "/terms", title: t.meta.titles.terms, description: t.meta.descriptions.terms });
}

export default async function TermsPage({ params }: { params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const s = await getSettings();
  return (
    <LegalPage
      title={t.meta.titles.terms}
      doc={locale === "sq" ? termsSq : termsEn}
      draftNotice={t.legal.draftNotice}
      crumbLabel={t.a11y.breadcrumb}
      crumbs={[{ href: `/${locale}`, label: t.nav.home }]}
      vars={{
        entity: s.legalEntityName || `GemDental Care [${t.common.toBeConfirmed}]`,
        privacyEmail: s.privacyContactEmail || s.email || `[${t.common.toBeConfirmed}]`,
        retention: String(s.dataRetentionMonths),
      }}
    />
  );
}
