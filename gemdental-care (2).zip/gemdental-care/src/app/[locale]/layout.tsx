import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { ViewTransition } from "react";
import "../globals.css";
import { Header } from "@/components/site/Header";
import { Footer } from "@/components/site/Footer";
import { StickyBookBar } from "@/components/site/StickyBookBar";
import { getDictionary, resolveLocale } from "@/lib/i18n";
import { enabledLocales, LOCALE_LABEL, LOCALE_TAG } from "@/lib/i18n/config";
import { getSettings } from "@/lib/settings";
import { dentistJsonLd, jsonLd } from "@/lib/seo";
import { env } from "@/lib/env";
import { getGalleryData } from "@/lib/gallery";
import { Interactions } from "@/components/site/Interactions";

export const dynamic = "force-dynamic";

const jost = localFont({
  src: "../../fonts/jost-var.woff2",
  variable: "--font-jost",
  weight: "300 600",
  display: "swap",
  fallback: ["Futura", "Century Gothic", "system-ui", "sans-serif"],
});

const cormorant = localFont({
  src: [
    { path: "../../fonts/cormorant-garamond-latin-500-normal.woff2", weight: "500", style: "normal" },
    { path: "../../fonts/cormorant-garamond-latin-500-italic.woff2", weight: "500", style: "italic" },
    { path: "../../fonts/cormorant-garamond-latin-600-normal.woff2", weight: "600", style: "normal" },
  ],
  variable: "--font-cormorant",
  display: "swap",
  fallback: ["Georgia", "serif"],
});

export const viewport: Viewport = {
  themeColor: "#4F3F4A",
  width: "device-width",
  initialScale: 1,
};

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  return {
    metadataBase: new URL(env.siteUrl),
    title: { default: t.meta.defaultTitle, template: "%s · GemDental Care" },
    description: t.meta.defaultDescription,
    applicationName: "GemDental Care",
    formatDetection: { telephone: false },
  };
}

export default async function LocaleLayout({ children, params }: { children: React.ReactNode; params: Promise<{ locale: string }> }) {
  const locale = resolveLocale((await params).locale);
  const t = getDictionary(locale);
  const [settings, hasResults] = await Promise.all([
    getSettings(),
    // The nav link is optional: never let a gallery problem take the whole site down.
    getGalleryData(locale).then(
      (g) => g.hasAny,
      () => false,
    ),
  ]);
  const locales = enabledLocales().map((code) => ({ code, label: LOCALE_LABEL[code] }));

  return (
    <html lang={LOCALE_TAG[locale]} className={`${jost.variable} ${cormorant.variable}`}>
      <body className="flex min-h-dvh flex-col">
        <a href="#main" className="sr-only-focusable bg-plum fixed top-3 left-3 z-50 rounded-full px-4 py-2 text-sm text-white">
          {t.a11y.skipToContent}
        </a>
        {settings.previewNotice && (
          <div className="bg-champagne-soft text-champagne-ink">
            <p className="container-gd py-2 text-center text-xs leading-snug">{t.preview.ribbon}</p>
          </div>
        )}
        <Header locale={locale} locales={locales} nav={t.nav} a11y={t.a11y} showResults={hasResults} />
        <ViewTransition>
          <main id="main" tabIndex={-1} className="flex-1 outline-none">
            {children}
          </main>
        </ViewTransition>
        <Footer t={t} locale={locale} settings={settings} showResults={hasResults} />
        <Interactions />
        <StickyBookBar locale={locale} label={t.nav.book} call={t.common.callUs} phone={settings.phone} />
        <script type="application/ld+json" dangerouslySetInnerHTML={jsonLd(dentistJsonLd(settings, locale))} />
      </body>
    </html>
  );
}
