"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo, useState } from "react";
import { CompareSlider } from "./Compare";
import { Viewer } from "./Viewer";
import type { CaseItem, GalleryStrings } from "./types";
import type { ResultConcern } from "@/lib/db/schema";

const fill = (s: string, vars: Record<string, string | number>) => s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));

/**
 * Homepage results feature: one large drag-to-compare case, filters by what
 * the patient came in with, a thumbnail rail (hover a thumbnail to glimpse the
 * "before"), and a full-screen viewer.
 */
export function ResultsShowcase({
  cases,
  strings,
  allHref,
  text,
}: {
  cases: CaseItem[];
  strings: GalleryStrings;
  allHref: string;
  text: { eyebrow: string; title: string; lead: string; viewAll: string; consent: string };
}) {
  const [filter, setFilter] = useState<ResultConcern | "all">("all");
  const [active, setActive] = useState(0);
  const [viewer, setViewer] = useState<number | null>(null);

  const concerns = useMemo(() => {
    const counts = new Map<ResultConcern, number>();
    for (const c of cases) if (c.concern) counts.set(c.concern, (counts.get(c.concern) ?? 0) + 1);
    return [...counts.entries()];
  }, [cases]);
  const list = filter === "all" ? cases : cases.filter((c) => c.concern === filter);
  const current = list[Math.min(active, list.length - 1)];
  if (!current) return null;
  const idx = list.indexOf(current);
  const go = (d: number) => setActive((idx + d + list.length) % list.length);

  return (
    <section id="results" className="on-dark bg-plum-deep section-y relative overflow-hidden text-white" aria-labelledby="results-title">
      <div
        aria-hidden
        className="pointer-events-none absolute -top-40 -right-40 h-[36rem] w-[36rem] rounded-full opacity-25 blur-3xl"
        style={{ background: "radial-gradient(circle, var(--gd-champagne), transparent 65%)" }}
      />
      <div className="container-gd relative grid gap-10 lg:grid-cols-12 lg:gap-12">
        <div className="min-w-0 lg:col-span-4" data-reveal>
          <p className="text-champagne text-sm tracking-[0.18em] uppercase">{text.eyebrow}</p>
          <h2 id="results-title" className="font-display mt-4 text-3xl text-balance text-white">
            {text.title}
          </h2>
          <p className="text-mauve-light mt-5">{text.lead}</p>

          {concerns.length > 1 && (
            <div
              className="-mx-[var(--gd-gutter)] mt-8 flex [scrollbar-width:none] gap-2 overflow-x-auto px-[var(--gd-gutter)] pb-1 sm:mx-0 sm:flex-wrap sm:px-0"
              role="group"
              aria-label={strings.filterLabel}
            >
              {[["all", cases.length] as const, ...concerns].map(([key, n]) => {
                const on = filter === key;
                return (
                  <button
                    key={key}
                    type="button"
                    aria-pressed={on}
                    onClick={() => {
                      setFilter(key);
                      setActive(0);
                    }}
                    className={`chip shrink-0 ${on ? "bg-champagne border-champagne text-plum-deep" : "text-mauve-light border-white/25 hover:border-white/60 hover:text-white"}`}
                  >
                    {key === "all" ? strings.all : strings.concerns[key]}
                    <span className="chip-count">{n}</span>
                  </button>
                );
              })}
            </div>
          )}

          <div className="mt-10 hidden lg:block">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => go(-1)}
                aria-label={strings.prev}
                className="grid h-12 w-12 place-items-center rounded-full border border-white/25 transition-colors hover:bg-white/10"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m15 6-6 6 6 6" />
                </svg>
              </button>
              <button
                type="button"
                onClick={() => go(1)}
                aria-label={strings.next}
                className="grid h-12 w-12 place-items-center rounded-full border border-white/25 transition-colors hover:bg-white/10"
              >
                <svg
                  viewBox="0 0 24 24"
                  className="h-5 w-5"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                >
                  <path d="m9 6 6 6-6 6" />
                </svg>
              </button>
              <span className="text-mauve-light ml-2 text-sm tabular-nums">
                <span className="font-display text-2xl text-white">{String(idx + 1).padStart(2, "0")}</span> /{" "}
                {String(list.length).padStart(2, "0")}
              </span>
            </div>
            <Link href={allHref} className="btn btn-champagne mt-10">
              {text.viewAll}
            </Link>
          </div>
        </div>

        <div className="min-w-0 lg:col-span-8" data-reveal style={{ ["--i" as string]: 1 }}>
          <div className="relative">
            <div key={current.id} className="viewer-slide">
              <CompareSlider
                item={current}
                labels={{
                  before: strings.before,
                  after: strings.after,
                  dragHint: strings.dragHint,
                  slider: fill(strings.compareLabel, { title: current.title }),
                }}
                sizes="(min-width: 1024px) 60vw, 100vw"
                intro={idx === 0 && filter === "all"}
                className="text-champagne"
              />
            </div>
            <button
              type="button"
              onClick={() => setViewer(cases.indexOf(current))}
              className="bg-plum-deep/70 absolute right-3 bottom-3 grid h-11 w-11 place-items-center rounded-full border border-white/40 backdrop-blur transition-transform hover:scale-105"
              aria-label={`${strings.openFull}: ${current.title}`}
            >
              <svg
                viewBox="0 0 24 24"
                className="h-5 w-5"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.6"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
              </svg>
            </button>
          </div>
          <div className="mt-5 flex items-start justify-between gap-4">
            <div>
              <h3 className="font-display text-2xl text-white">{current.title}</h3>
              {current.concern && <p className="text-champagne mt-1 text-sm">{strings.concerns[current.concern]}</p>}
            </div>
            <span className="text-mauve-light shrink-0 pt-1 text-sm tabular-nums lg:hidden">
              {idx + 1} / {list.length}
            </span>
          </div>

          <ul className="mt-6 flex snap-x [scrollbar-width:thin] gap-3 overflow-x-auto pb-2">
            {list.map((c, n) => (
              <li key={c.id} className="snap-start">
                <button
                  type="button"
                  onClick={() => setActive(n)}
                  aria-label={c.title}
                  data-concern={c.concern ?? undefined}
                  aria-current={n === idx ? "true" : undefined}
                  className={`group relative block h-20 w-32 overflow-hidden rounded-[var(--radius-sm)] transition-all duration-300 sm:h-24 sm:w-36 ${
                    n === idx ? "ring-champagne ring-2 ring-offset-2 ring-offset-[var(--gd-plum-deep)]" : "opacity-60 hover:opacity-100"
                  }`}
                >
                  <Image src={c.after.src} alt="" fill sizes="150px" className="object-cover transition-opacity duration-500" />
                  <Image
                    src={c.before.src}
                    alt=""
                    fill
                    sizes="150px"
                    className="object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100"
                  />
                  <span className="bg-plum-deep/80 absolute bottom-1 left-1 rounded-full px-2 text-[0.6875rem] opacity-0 transition-opacity group-hover:opacity-100">
                    {strings.before}
                  </span>
                </button>
              </li>
            ))}
          </ul>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between lg:hidden">
            <Link href={allHref} className="btn btn-champagne">
              {text.viewAll}
            </Link>
          </div>
          <p className="text-mauve-light mt-6 text-xs">{text.consent}</p>
        </div>
      </div>

      <Viewer
        slides={cases.map((item) => ({ kind: "compare" as const, item }))}
        index={viewer}
        onIndex={setViewer}
        onClose={() => setViewer(null)}
        strings={strings}
      />
    </section>
  );
}
