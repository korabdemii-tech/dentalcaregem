import Image from "next/image";
import Link from "next/link";
import type { CaseItem, PhotoItem } from "./types";

type Tile = { key: string; after: CaseItem["after"]; before?: CaseItem["before"]; label: string };

/**
 * An endless, slowly drifting strip of finished smiles. Hover (or focus) a
 * tile to glimpse the "before"; hovering pauses the strip. With reduced
 * motion it becomes a normal horizontally scrollable row.
 */
export function SmileMarquee({
  cases,
  smiles,
  href,
  title,
  beforeLabel,
}: {
  cases: CaseItem[];
  smiles: PhotoItem[];
  href: string;
  title: string;
  beforeLabel: string;
}) {
  const tiles: Tile[] = [
    ...cases.map((c) => ({ key: c.id, after: c.after, before: c.before, label: c.title })),
    ...smiles.map((s) => ({ key: s.id, after: s.image, label: s.caption })),
  ];
  // Interleave single smiles among the cases for rhythm.
  if (tiles.length < 4) return null;

  const row = (dup: boolean) =>
    tiles.map((t) => (
      <li
        key={`${dup ? "d" : "o"}-${t.key}`}
        className={`shrink-0 snap-start pr-4 ${dup ? "marquee-dup" : ""}`}
        aria-hidden={dup || undefined}
      >
        <Link
          href={href}
          tabIndex={dup ? -1 : undefined}
          className="group relative block h-44 overflow-hidden rounded-[var(--radius-md)] sm:h-56"
          style={{ aspectRatio: `${Math.min(Math.max(t.after.width / t.after.height, 1.1), 2)}` }}
          aria-label={dup ? undefined : t.label}
        >
          <Image
            src={t.after.src}
            alt=""
            fill
            sizes="(min-width: 640px) 420px, 320px"
            className="ease-gd object-cover transition-transform duration-700 group-hover:scale-105"
          />
          {t.before && (
            <>
              <Image
                src={t.before.src}
                alt=""
                fill
                sizes="(min-width: 640px) 420px, 320px"
                className="object-cover opacity-0 transition-opacity duration-500 group-hover:opacity-100 group-focus-visible:opacity-100"
              />
              <span className="bg-plum-deep/80 absolute top-2.5 left-2.5 rounded-full px-2.5 py-0.5 text-xs text-white opacity-0 transition-opacity duration-300 group-hover:opacity-100 group-focus-visible:opacity-100">
                {beforeLabel}
              </span>
            </>
          )}
        </Link>
      </li>
    ));

  return (
    <section aria-label={title} className="py-10 sm:py-14">
      <div className="container-gd mb-6 flex items-center gap-4" data-reveal="fade">
        <span aria-hidden className="bg-champagne-ink h-px w-10" />
        <h2 className="text-champagne-ink text-sm tracking-[0.18em] uppercase">{title}</h2>
      </div>
      <div className="marquee" style={{ ["--marquee-dur" as string]: `${tiles.length * 6}s` }}>
        <ul className="marquee-track">
          {row(false)}
          {row(true)}
        </ul>
      </div>
    </section>
  );
}
