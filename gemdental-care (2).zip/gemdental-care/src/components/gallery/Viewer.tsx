"use client";

import Image from "next/image";
import { useEffect, useRef, useState } from "react";
import { CompareSlider } from "./Compare";
import type { GalleryStrings, Slide } from "./types";

const fill = (s: string, vars: Record<string, string | number>) => s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));

function slideImage(s: Slide) {
  return s.kind === "compare" ? s.item.after : s.item.image;
}

/**
 * Full-screen viewer built on the native <dialog> element (focus is kept
 * inside, Escape closes, the page behind is inert). Arrow keys and the
 * buttons move between slides; photos can also be swiped.
 */
export function Viewer({
  slides,
  index,
  onIndex,
  onClose,
  strings,
}: {
  slides: Slide[];
  index: number | null;
  onIndex: (i: number) => void;
  onClose: () => void;
  strings: GalleryStrings;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const thumbs = useRef<HTMLDivElement>(null);
  const [dir, setDir] = useState(1);
  const swipe = useRef<{ x: number; y: number } | null>(null);
  const open = index !== null && slides.length > 0;
  const i = index ?? 0;
  const slide = slides[i];

  useEffect(() => {
    const d = ref.current;
    if (!d) return;
    if (open && !d.open) {
      d.showModal();
      const prev = document.documentElement.style.overflow;
      document.documentElement.style.overflow = "hidden";
      return () => {
        document.documentElement.style.overflow = prev;
      };
    }
    if (!open && d.open) d.close();
  }, [open]);

  // Keep the active thumbnail in view.
  useEffect(() => {
    if (!open) return;
    thumbs.current?.querySelector<HTMLElement>(`[data-i="${i}"]`)?.scrollIntoView({ block: "nearest", inline: "center" });
  }, [i, open]);

  const go = (delta: number) => {
    if (!slides.length) return;
    setDir(delta);
    onIndex((i + delta + slides.length) % slides.length);
  };

  if (!slide && open) return null;
  const img = slide ? slideImage(slide) : null;
  const ratio = img ? img.width / img.height : 1;
  const title = slide ? (slide.kind === "compare" ? slide.item.title : slide.item.caption) : "";

  return (
    <dialog
      ref={ref}
      className="viewer on-dark"
      aria-label={strings.viewer}
      onClose={onClose}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onKeyDown={(e) => {
        const t = e.target as HTMLElement;
        if (t instanceof HTMLInputElement && t.type === "range") return; // arrows move the slider there
        if (e.key === "ArrowRight") {
          e.preventDefault();
          go(1);
        } else if (e.key === "ArrowLeft") {
          e.preventDefault();
          go(-1);
        }
      }}
    >
      {open && slide && img && (
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between gap-4 px-4 pt-4 sm:px-6">
            <p className="text-mauve-light text-sm tabular-nums" aria-live="polite">
              {fill(strings.counter, { n: i + 1, total: slides.length })}
            </p>
            <button
              type="button"
              onClick={onClose}
              className="grid h-11 w-11 place-items-center rounded-full border border-white/25 transition-colors hover:bg-white/10"
              aria-label={strings.close}
              autoFocus
            >
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round">
                <path d="M6 6l12 12M18 6 6 18" />
              </svg>
            </button>
          </div>

          <div className="relative flex min-h-0 flex-1 items-center justify-center px-4 sm:px-20">
            <div
              key={`${slide.kind}-${slide.item.id}`}
              className="viewer-slide w-full"
              style={{ ["--dir" as string]: dir, width: `min(100%, calc((100dvh - 15rem) * ${ratio}))` }}
              onPointerDown={(e) => {
                if (slide.kind === "photo") swipe.current = { x: e.clientX, y: e.clientY };
              }}
              onPointerUp={(e) => {
                const s = swipe.current;
                swipe.current = null;
                if (!s) return;
                const dx = e.clientX - s.x;
                if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(e.clientY - s.y)) go(dx < 0 ? 1 : -1);
              }}
            >
              {slide.kind === "compare" ? (
                <CompareSlider
                  item={slide.item}
                  labels={{
                    before: strings.before,
                    after: strings.after,
                    dragHint: strings.dragHint,
                    slider: fill(strings.compareLabel, { title: slide.item.title }),
                  }}
                  sizes="(min-width: 1024px) 80vw, 100vw"
                  priority
                  followPointer
                />
              ) : (
                <div
                  className="relative w-full [touch-action:pan-y] overflow-hidden rounded-[var(--radius-md)]"
                  style={{ aspectRatio: `${img.width} / ${img.height}` }}
                >
                  <Image src={img.src} alt={img.alt} fill sizes="(min-width: 1024px) 80vw, 100vw" priority className="object-contain" />
                </div>
              )}
            </div>

            {slides.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() => go(-1)}
                  aria-label={strings.prev}
                  className="absolute top-1/2 left-2 hidden h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-white/25 bg-black/20 backdrop-blur transition-colors hover:bg-white/15 sm:grid"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m15 6-6 6 6 6" />
                  </svg>
                </button>
                <button
                  type="button"
                  onClick={() => go(1)}
                  aria-label={strings.next}
                  className="absolute top-1/2 right-2 hidden h-12 w-12 -translate-y-1/2 place-items-center rounded-full border border-white/25 bg-black/20 backdrop-blur transition-colors hover:bg-white/15 sm:grid"
                >
                  <svg
                    viewBox="0 0 24 24"
                    className="h-5 w-5"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.6"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  >
                    <path d="m9 6 6 6-6 6" />
                  </svg>
                </button>
              </>
            )}
          </div>

          <div className="px-4 pt-4 pb-4 sm:px-6">
            <div className="flex items-start justify-between gap-4">
              <div className="min-w-0">
                <p className="font-display text-xl text-white sm:text-2xl">{title}</p>
                {slide.kind === "compare" && slide.item.description && (
                  <p className="text-mauve-light mt-1 text-xs sm:text-sm">{slide.item.description}</p>
                )}
              </div>
              {slides.length > 1 && (
                <div className="flex shrink-0 gap-2 sm:hidden">
                  <button
                    type="button"
                    onClick={() => go(-1)}
                    aria-label={strings.prev}
                    className="grid h-11 w-11 place-items-center rounded-full border border-white/25"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      className="h-5 w-5"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m15 6-6 6 6 6" />
                    </svg>
                  </button>
                  <button
                    type="button"
                    onClick={() => go(1)}
                    aria-label={strings.next}
                    className="grid h-11 w-11 place-items-center rounded-full border border-white/25"
                  >
                    <svg
                      viewBox="0 0 24 24"
                      className="h-5 w-5"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.6"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <path d="m9 6 6 6-6 6" />
                    </svg>
                  </button>
                </div>
              )}
            </div>
            {slides.length > 1 && (
              <div ref={thumbs} className="mt-4 flex [scrollbar-width:none] gap-2 overflow-x-auto pb-1">
                {slides.map((s, n) => {
                  const t = slideImage(s);
                  return (
                    <button
                      key={`${s.kind}-${s.item.id}`}
                      type="button"
                      data-i={n}
                      onClick={() => {
                        setDir(n > i ? 1 : -1);
                        onIndex(n);
                      }}
                      aria-label={s.kind === "compare" ? s.item.title : s.item.caption}
                      aria-current={n === i ? "true" : undefined}
                      className={`relative h-14 w-20 shrink-0 overflow-hidden rounded-[var(--radius-sm)] transition-all duration-300 ${
                        n === i ? "ring-champagne opacity-100 ring-2" : "opacity-50 hover:opacity-90"
                      }`}
                    >
                      <Image src={t.src} alt="" fill sizes="80px" className="object-cover" />
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </dialog>
  );
}
