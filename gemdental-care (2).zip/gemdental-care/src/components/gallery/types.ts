import type { ResultConcern } from "@/lib/db/schema";

export type Img = { src: string; width: number; height: number; alt: string };

export type CaseItem = {
  id: string;
  title: string;
  description: string;
  concern: ResultConcern | null;
  before: Img;
  after: Img;
};

export type PhotoItem = { id: string; caption: string; image: Img };

/** One slide in the full-screen viewer. */
export type Slide = { kind: "compare"; item: CaseItem } | { kind: "photo"; item: PhotoItem };

export type GalleryStrings = {
  before: string;
  after: string;
  dragHint: string;
  all: string;
  filterLabel: string;
  concerns: Record<ResultConcern, string>;
  openFull: string;
  close: string;
  prev: string;
  next: string;
  counter: string;
  compareLabel: string;
  magnifyHint: string;
  viewer: string;
};
