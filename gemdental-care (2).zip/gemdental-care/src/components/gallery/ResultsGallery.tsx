"use client";

import Image from "next/image";
import { useMemo, useRef, useState } from "react";
import { CompareSlider } from "./Compare";
import { Viewer } from "./Viewer";
import type { CaseItem, GalleryStrings, PhotoItem, Slide } from "./types";
import type { ResultConcern } from "@/lib/db/schema";

const fill = (s: string, vars: Record<string, string | number>) => s.replace(/\{(\w+)\}/g, (_, k) => String(vars[k] ?? ""));

const ExpandIcon = () => (
  <svg
    viewBox="0 0 24 24"
    className="h-[1.1rem] w-[1.1rem]"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.6"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5" />
  </svg>
);

/** A tooth-gem photo with a magnifying loupe that follows the mouse. */
function GemCard({ photo, onOpen, hint }: { photo: PhotoItem; onOpen: () => void; hint: string }) {
  const ref = useRef<HTMLButtonElement>(null);
  const lens = useRef<HTMLSpanElement>(null);
  const ZOOM = 2.6;
  const move = (e: React.PointerEvent) => {
    if (e.pointerType !== "mouse" || !ref.current || !lens.current) return;
    const r = ref.current.getBoundingClientRect();
    const x = e.clientX - r.left;
    const y = e.clientY - r.top;
    const l = lens.current;
    const size = l.offsetWidth;
    l.style.left = `${x}px`;
    l.style.top = `${y}px`;
    l.style.backgroundSize = `${r.width * ZOOM}px ${r.height * ZOOM}px`;
    l.style.backgroundPosition = `${-(x * ZOOM - size / 2)}px ${-(y * ZOOM - size / 2)}px`;
    l.classList.add("is-on");
  };
  return (
    <figure>
      <button
        ref={ref}
        type="button"
        onClick={onOpen}
        onPointerMove={move}
        onPointerLeave={() => lens.current?.classList.remove("is-on")}
        className="group relative block w-full cursor-zoom-in overflow-hidden rounded-[var(--radius-md)] bg-white"
        style={{ aspectRatio: `${photo.image.width} / ${photo.image.height}` }}
        aria-label={photo.image.alt}
      >
        <Image src={photo.image.src} alt="" fill sizes="(min-width: 768px) 30vw, 100vw" className="object-cover" />
        <span ref={lens} aria-hidden className="loupe z-10" style={{ backgroundImage: `url(${photo.image.src})` }} />
      </button>
      <figcaption className="mt-3 flex items-center justify-between gap-3">
        <span className="font-display text-plum text-xl">{photo.caption}</span>
        <span className="text-ink-muted hidden text-xs [@media(hover:hover)]:inline">{hint}</span>
      </figcaption>
    </figure>
  );
}

/**
 * The /results page: filterable before/after cases (each one draggable, and
 * on desktop the divider follows the mouse), finished smiles, tooth gems,
 * and a shared full-screen viewer.
 */
export function ResultsGallery({
  cases,
  smiles,
  gems,
  strings,
  text,
}: {
  cases: CaseItem[];
  smiles: PhotoItem[];
  gems: PhotoItem[];
  strings: GalleryStrings;
  text: { casesTitle: string; smilesTitle: string; smilesLead: string; gemsTitle: string; gemsLead: string; showing: string };
}) {
  const [filter, setFilter] = useState<ResultConcern | "all">("all");
  const [viewer, setViewer] = useState<number | null>(null);

  const concerns = useMemo(() => {
    const counts = new Map<ResultConcern, number>();
    for (const c of cases) if (c.concern) counts.set(c.concern, (counts.get(c.concern) ?? 0) + 1);
    return [...counts.entries()];
  }, [cases]);
  const visible = filter === "all" ? cases : cases.filter((c) => c.concern === filter);

  const slides: Slide[] = [
    ...visible.map((item) => ({ kind: "compare" as const, item })),
    ...smiles.map((item) => ({ kind: "photo" as const, item })),
    ...gems.map((item) => ({ kind: "photo" as const, item })),
  ];
  const photoStart = visible.length;

  return (
    <>
      {cases.length > 0 && (
        <section className="section-y !pt-10" aria-labelledby="cases-title">
          <div className="container-gd">
            <h2 id="cases-title" className="sr-only">
              {text.casesTitle}
            </h2>
            {concerns.length > 1 && (
              <div
                className="bg-ivory/90 sticky top-[var(--gd-header-h)] z-20 -mx-[var(--gd-gutter)] flex [scrollbar-width:none] items-center gap-2 overflow-x-auto px-[var(--gd-gutter)] py-3 backdrop-blur sm:flex-wrap"
                role="group"
                aria-label={strings.filterLabel}
              >
                {[["all", cases.length] as const, ...concerns].map(([key, n]) => {
                  const on = filter === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      aria-pressed={on}
                      onClick={() => setFilter(key)}
                      className={`chip shrink-0 ${on ? "bg-plum border-plum text-white" : "text-plum border-line-strong hover:border-plum bg-white"}`}
                    >
                      {key === "all" ? strings.all : strings.concerns[key]}
                      <span className="chip-count">{n}</span>
                    </button>
                  );
                })}
                <span className="text-ink-muted ml-auto hidden text-sm sm:inline" aria-live="polite">
                  {fill(text.showing, { n: visible.length })}
                </span>
              </div>
            )}

            <ul className="mt-8 columns-1 gap-6 md:columns-2 xl:columns-3">
              {visible.map((c, n) => (
                <li
                  key={c.id}
                  className="mb-8 break-inside-avoid"
                  data-concern={c.concern ?? undefined}
                  data-reveal
                  style={{ ["--i" as string]: n % 3 }}
                >
                  <article data-spotlight className="border-line overflow-hidden rounded-[var(--radius-lg)] border bg-white p-3">
                    <div className="relative">
                      <CompareSlider
                        item={c}
                        labels={{
                          before: strings.before,
                          after: strings.after,
                          dragHint: strings.dragHint,
                          slider: fill(strings.compareLabel, { title: c.title }),
                        }}
                        sizes="(min-width: 1280px) 30vw, (min-width: 768px) 45vw, 100vw"
                        followPointer
                        className="text-plum"
                      />
                      <button
                        type="button"
                        onClick={() => setViewer(n)}
                        aria-label={`${strings.openFull}: ${c.title}`}
                        className="bg-plum-deep/70 absolute right-2.5 bottom-2.5 z-10 grid h-10 w-10 place-items-center rounded-full border border-white/40 text-white backdrop-blur transition-transform hover:scale-110"
                      >
                        <ExpandIcon />
                      </button>
                    </div>
                    <div className="px-2 pt-4 pb-2">
                      {c.concern && <p className="text-champagne-ink text-xs tracking-[0.14em] uppercase">{strings.concerns[c.concern]}</p>}
                      <h3 className="font-display text-plum mt-1.5 text-xl leading-snug">
                        <button type="button" onClick={() => setViewer(n)} className="text-left hover:underline">
                          {c.title}
                        </button>
                      </h3>
                    </div>
                  </article>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {smiles.length > 0 && (
        <section className="bg-cream section-y" aria-labelledby="smiles-title">
          <div className="container-gd">
            <div className="grid gap-6 lg:grid-cols-12 lg:items-end" data-reveal>
              <h2 id="smiles-title" className="font-display text-plum text-3xl lg:col-span-5">
                {text.smilesTitle}
              </h2>
              <p className="text-ink-muted lg:col-span-6 lg:col-start-7">{text.smilesLead}</p>
            </div>
            <ul className="mt-12 grid gap-6 md:grid-cols-3">
              {smiles.map((p, n) => (
                <li key={p.id} data-reveal="zoom" style={{ ["--i" as string]: n }}>
                  <figure>
                    <button
                      type="button"
                      data-tilt="7"
                      onClick={() => setViewer(photoStart + n)}
                      className="group relative block w-full cursor-zoom-in overflow-hidden rounded-[var(--radius-lg)] shadow-[0_30px_60px_-30px_rgb(56_42_53/0.45)]"
                      style={{ aspectRatio: "4 / 5" }}
                      aria-label={`${strings.openFull}: ${p.caption}`}
                    >
                      <Image
                        src={p.image.src}
                        alt={p.image.alt}
                        fill
                        sizes="(min-width: 768px) 30vw, 100vw"
                        className="ease-gd object-cover transition-transform duration-[1.2s] group-hover:scale-110"
                      />
                      <span className="from-plum-deep/70 absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t to-transparent opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
                      <span className="absolute right-3 bottom-3 grid h-10 w-10 translate-y-2 place-items-center rounded-full bg-white/85 text-[var(--gd-plum)] opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
                        <ExpandIcon />
                      </span>
                    </button>
                    <figcaption className="text-ink-muted mt-3 text-sm">{p.caption}</figcaption>
                  </figure>
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      {gems.length > 0 && (
        <section className="section-y relative overflow-hidden" aria-labelledby="gems-title">
          <div className="container-gd grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-4" data-reveal>
              <span aria-hidden className="bg-champagne-ink block h-2.5 w-2.5 rotate-45" />
              <h2 id="gems-title" className="font-display text-plum mt-6 text-3xl">
                {text.gemsTitle}
              </h2>
              <p className="text-ink-muted mt-5">{text.gemsLead}</p>
            </div>
            <ul className="grid gap-8 sm:grid-cols-3 lg:col-span-8">
              {gems.map((p, n) => (
                <li key={p.id} data-reveal style={{ ["--i" as string]: n }} className={n === 1 ? "sm:mt-12" : ""}>
                  <GemCard photo={p} hint={strings.magnifyHint} onOpen={() => setViewer(photoStart + smiles.length + n)} />
                </li>
              ))}
            </ul>
          </div>
        </section>
      )}

      <Viewer slides={slides} index={viewer} onIndex={setViewer} onClose={() => setViewer(null)} strings={strings} />
    </>
  );
}
