"use client";

import Image from "next/image";
import { useCallback, useEffect, useId, useRef, useState } from "react";
import type { CaseItem } from "./types";

type Labels = { before: string; after: string; dragHint?: string; slider: string };

/** Presentational before/after split. `pos` is the share of the before photo shown, 0–100. */
export function CompareView({
  item,
  pos,
  labels,
  sizes,
  priority = false,
  dragging = false,
  showHint = false,
  className = "",
  rounded = true,
}: {
  item: CaseItem;
  pos: number;
  labels: Labels;
  sizes: string;
  priority?: boolean;
  dragging?: boolean;
  showHint?: boolean;
  className?: string;
  rounded?: boolean;
}) {
  return (
    <div
      className={`compare bg-plum-night relative w-full overflow-hidden ${rounded ? "rounded-[var(--radius-md)]" : ""} ${dragging ? "is-dragging" : ""} ${className}`}
      style={{ aspectRatio: `${item.after.width} / ${item.after.height}`, ["--pos" as string]: `${pos}%` }}
    >
      <Image src={item.after.src} alt={item.after.alt} fill sizes={sizes} priority={priority} draggable={false} className="object-cover" />
      <div className="compare-before absolute inset-0">
        <Image
          src={item.before.src}
          alt={item.before.alt}
          fill
          sizes={sizes}
          priority={priority}
          draggable={false}
          className="object-cover"
        />
      </div>

      <div aria-hidden className="compare-line pointer-events-none absolute inset-y-0 w-0">
        <span className="absolute inset-y-0 -left-px w-0.5 bg-white/90 shadow-[0_0_12px_rgb(0_0_0/0.35)]" />
        <span className="compare-knob bg-plum/85 absolute top-1/2 left-0 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-white text-white shadow-lg backdrop-blur-sm">
          <svg
            viewBox="0 0 24 24"
            className="h-5 w-5"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="m9 6-5 6 5 6M15 6l5 6-5 6" />
          </svg>
        </span>
      </div>

      <span
        aria-hidden
        className={`bg-plum-deep/80 absolute top-3 left-3 rounded-full px-3 py-1 text-xs tracking-wide text-white backdrop-blur-sm transition-opacity duration-300 ${pos < 14 ? "opacity-0" : "opacity-100"}`}
      >
        {labels.before}
      </span>
      <span
        aria-hidden
        className={`bg-champagne text-plum-deep absolute top-3 right-3 rounded-full px-3 py-1 text-xs tracking-wide transition-opacity duration-300 ${pos > 86 ? "opacity-0" : "opacity-100"}`}
      >
        {labels.after}
      </span>
      {showHint && labels.dragHint && (
        <span
          aria-hidden
          className="bg-plum-deep/75 pointer-events-none absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full px-3.5 py-1.5 text-xs whitespace-nowrap text-white backdrop-blur-sm"
        >
          <span className="compare-hint inline-flex items-center gap-2">
            <span aria-hidden>‹</span>
            {labels.dragHint}
            <span aria-hidden>›</span>
          </span>
        </span>
      )}
    </div>
  );
}

const ease = (t: number) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);

/**
 * Interactive before/after comparison.
 * - Drag (mouse, pen or touch; vertical swipes still scroll the page)
 * - Click anywhere to jump the divider there
 * - Keyboard and screen readers: a native range input
 * - `followPointer`: on desktop the divider follows the mouse without clicking
 * - `intro`: one slow sweep the first time it scrolls into view
 */
export function CompareSlider({
  item,
  labels,
  sizes,
  priority,
  intro = false,
  followPointer = false,
  className = "",
  rounded = true,
}: {
  item: CaseItem;
  labels: Labels;
  sizes: string;
  priority?: boolean;
  intro?: boolean;
  followPointer?: boolean;
  className?: string;
  rounded?: boolean;
}) {
  const [pos, setPos] = useState(50);
  const [dragging, setDragging] = useState(false);
  const [touched, setTouched] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  const anim = useRef(0);
  const id = useId();

  const interacted = useRef(false);
  const stopIntro = () => {
    interacted.current = true;
    if (anim.current) cancelAnimationFrame(anim.current);
    anim.current = 0;
  };

  const fromEvent = useCallback((clientX: number) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r || !r.width) return;
    setPos(Math.min(100, Math.max(0, ((clientX - r.left) / r.width) * 100)));
  }, []);

  // One gentle sweep (50 → 18 → 82 → 50) when first seen, to show it can be dragged.
  useEffect(() => {
    if (!intro || !ref.current) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const el = ref.current;
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io.disconnect();
        if (interacted.current) return;
        const keys = [50, 18, 82, 50];
        const seg = 700;
        const start = performance.now() + 250;
        const step = (now: number) => {
          if (interacted.current) return;
          const t = Math.max(0, now - start);
          const i = Math.min(keys.length - 2, Math.floor(t / seg));
          const local = Math.min(1, (t - i * seg) / seg);
          setPos(keys[i] + (keys[i + 1] - keys[i]) * ease(local));
          if (t < seg * (keys.length - 1)) anim.current = requestAnimationFrame(step);
          else anim.current = 0;
        };
        anim.current = requestAnimationFrame(step);
      },
      { threshold: 0.6 },
    );
    io.observe(el);
    return () => {
      io.disconnect();
      if (anim.current) cancelAnimationFrame(anim.current);
      anim.current = 0;
    };
  }, [intro]);

  return (
    <div
      ref={ref}
      className={`group/compare relative cursor-ew-resize rounded-[var(--radius-md)] has-[input:focus-visible]:outline-2 has-[input:focus-visible]:outline-offset-4 has-[input:focus-visible]:outline-current ${className}`}
      onPointerDown={(e) => {
        if (e.pointerType === "mouse" && e.button !== 0) return;
        stopIntro();
        setTouched(true);
        setDragging(true);
        e.currentTarget.setPointerCapture(e.pointerId);
        // Touch: wait for movement, so a tap or a vertical scroll doesn't make the divider jump.
        if (e.pointerType === "mouse") fromEvent(e.clientX);
      }}
      onPointerMove={(e) => {
        if (dragging || (followPointer && e.pointerType === "mouse")) {
          if (!dragging) stopIntro();
          fromEvent(e.clientX);
        }
      }}
      onPointerUp={() => setDragging(false)}
      onPointerCancel={() => setDragging(false)}
      onLostPointerCapture={() => setDragging(false)}
    >
      <CompareView
        item={item}
        pos={pos}
        labels={labels}
        sizes={sizes}
        priority={priority}
        dragging={dragging}
        showHint={!touched && !followPointer}
        rounded={rounded}
      />
      <label htmlFor={id} className="sr-only">
        {labels.slider}
      </label>
      <input
        id={id}
        type="range"
        min={0}
        max={100}
        step={2}
        value={Math.round(pos)}
        aria-valuetext={`${labels.before} ${Math.round(pos)}% · ${labels.after} ${100 - Math.round(pos)}%`}
        onFocus={stopIntro}
        onChange={(e) => {
          stopIntro();
          setTouched(true);
          setPos(Number(e.target.value));
        }}
        className="sr-only"
      />
    </div>
  );
}
