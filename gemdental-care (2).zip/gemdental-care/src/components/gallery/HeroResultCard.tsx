import Image from "next/image";
import type { CaseItem } from "./types";

/** Floating glass card in the hero: a tiny looping before/after wipe that links to the results. */
export function HeroResultCard({ item, href, title, link }: { item: CaseItem; href: string; title: string; link: string }) {
  return (
    <a
      href={href}
      className="glass float-y group absolute bottom-2 left-0 z-10 flex items-center gap-3 rounded-[var(--radius-lg)] p-2.5 pr-5 transition-shadow hover:shadow-2xl sm:bottom-8 lg:-left-6"
    >
      <span className="relative block h-16 w-24 shrink-0 overflow-hidden rounded-[var(--radius-md)] sm:h-[4.5rem] sm:w-28">
        <Image src={item.after.src} alt="" fill sizes="120px" className="object-cover" />
        <span className="wipe-before absolute inset-0">
          <Image src={item.before.src} alt="" fill sizes="120px" className="object-cover" />
        </span>
        <span aria-hidden className="wipe-line absolute inset-y-0 left-1/2 w-0.5 bg-white shadow" />
      </span>
      <span className="text-sm leading-tight">
        <span className="text-champagne-ink block text-[0.6875rem] tracking-[0.16em] uppercase">{title}</span>
        <span className="text-plum mt-1 flex items-center gap-1.5 font-medium">
          {link}
          <span aria-hidden className="transition-transform duration-300 group-hover:translate-x-1">
            →
          </span>
        </span>
      </span>
    </a>
  );
}
