"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { patientDetailsSchema } from "@/lib/validation";
import { fmt, lookup } from "@/lib/i18n/format";
import { capFirst, formatClock, formatDateKey, formatInstant } from "@/lib/i18n/dates";
import { Calendar } from "./Calendar";
import { Turnstile } from "./Turnstile";
import type { BookingConfig, BookingDoctor, BookingResult, BookingService, BookingStrings, Details, Slot } from "./types";

type StepId = "service" | "doctor" | "datetime" | "details" | "review";
type SubmitError =
  | "slotTaken"
  | "sessionExpired"
  | "network"
  | "server"
  | "rateLimited"
  | "bot"
  | "serviceUnavailable"
  | "doctorUnavailable"
  | "bookingDisabled"
  | "fixFields";

const EMPTY_DETAILS: Details = {
  fullName: "",
  phone: "",
  email: "",
  note: "",
  isReturning: "unspecified",
  consentSms: false,
  consentWhatsapp: false,
  acceptPrivacy: false,
};

function todayIn(tz: string) {
  const p = Object.fromEntries(
    new Intl.DateTimeFormat("en-CA", { timeZone: tz, year: "numeric", month: "2-digit", day: "2-digit" })
      .formatToParts(new Date())
      .map((x) => [x.type, x.value]),
  );
  return `${p.year}-${p.month}-${p.day}`;
}

function newKey() {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID().replace(/-/g, "");
  return Math.random().toString(36).slice(2) + Date.now().toString(36) + Math.random().toString(36).slice(2);
}

async function getJSON<T>(url: string, signal?: AbortSignal): Promise<T> {
  const res = await fetch(url, { signal, headers: { Accept: "application/json" }, cache: "no-store" });
  if (!res.ok) throw Object.assign(new Error(`HTTP ${res.status}`), { status: res.status });
  return res.json() as Promise<T>;
}

export function BookingFlow({
  services,
  doctors,
  config,
  strings,
  initialToken,
  initialServiceSlug,
  initialDoctorSlug,
}: {
  services: BookingService[];
  doctors: BookingDoctor[];
  config: BookingConfig;
  strings: BookingStrings;
  initialToken: string;
  initialServiceSlug?: string;
  initialDoctorSlug?: string;
}) {
  const b = strings.booking;
  const tz = config.timezone;
  const doctorById = useMemo(() => new Map(doctors.map((d) => [d.id, d])), [doctors]);

  // ── Selection state ─────────────────────────────────────────
  const preService = services.find((s) => s.slug === initialServiceSlug) ?? null;
  const preDoctor = doctors.find((d) => d.slug === initialDoctorSlug) ?? null;
  const [serviceId, setServiceId] = useState<string | null>(preService?.id ?? null);
  const service = services.find((s) => s.id === serviceId) ?? null;
  const eligibleDoctors = useMemo(
    () => (service ? service.doctorIds.map((id) => doctorById.get(id)!).filter(Boolean) : []),
    [service, doctorById],
  );
  const [doctorChoice, setDoctorChoice] = useState<string>(() => {
    if (preService && preDoctor && preService.doctorIds.includes(preDoctor.id)) return preDoctor.id;
    return "any";
  });
  const showDoctorStep = eligibleDoctors.length > 1;

  const steps: StepId[] = useMemo(
    () => (showDoctorStep ? ["service", "doctor", "datetime", "details", "review"] : ["service", "datetime", "details", "review"]),
    [showDoctorStep],
  );
  const [step, setStep] = useState<StepId>(preService ? (showDoctorStep && !preDoctor ? "doctor" : "datetime") : "service");
  const stepIndex = steps.indexOf(step);

  const today = useMemo(() => todayIn(tz), [tz]);
  const [ym, setYm] = useState<{ y: number; m: number }>(() => ({ y: Number(today.slice(0, 4)), m: Number(today.slice(5, 7)) }));
  const [available, setAvailable] = useState<Set<string>>(new Set());
  const [lastBookable, setLastBookable] = useState<string | null>(null);
  const [monthState, setMonthState] = useState<"idle" | "loading" | "error">("idle");
  const [date, setDate] = useState<string | null>(null);
  const [slots, setSlots] = useState<Slot[]>([]);
  const [slotsState, setSlotsState] = useState<"idle" | "loading" | "error">("idle");
  const [slot, setSlot] = useState<Slot | null>(null);
  const [searchingNext, setSearchingNext] = useState(false);

  const [details, setDetails] = useState<Details>(EMPTY_DETAILS);
  const [fieldErrs, setFieldErrs] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  const [token, setToken] = useState(initialToken);
  const [honeypot, setHoneypot] = useState("");
  const [turnstileToken, setTurnstileToken] = useState<string | undefined>();
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<SubmitError | null>(null);
  const [notice, setNotice] = useState<SubmitError | null>(null);
  const [result, setResult] = useState<BookingResult | null>(null);
  const idemRef = useRef<{ sig: string; key: string } | null>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const errorRef = useRef<HTMLDivElement>(null);
  const firstRender = useRef(true);

  const doctorParam = doctorChoice === "any" ? "any" : doctorChoice;
  const schema = useMemo(() => patientDetailsSchema(config.phoneCountry), [config.phoneCountry]);

  // Move focus to the step heading whenever the step changes (not on first load).
  useEffect(() => {
    if (firstRender.current) {
      firstRender.current = false;
      return;
    }
    headingRef.current?.focus({ preventScroll: true });
    headingRef.current?.scrollIntoView({ block: "start", behavior: "smooth" });
  }, [step, result]);

  // ── Month availability ──────────────────────────────────────
  const loadMonth = useCallback(
    async (y: number, m: number, signal?: AbortSignal) => {
      if (!serviceId) return null;
      const q = new URLSearchParams({ service: serviceId, doctor: doctorParam, month: `${y}-${String(m).padStart(2, "0")}` });
      return getJSON<{ available: string[]; lastBookable: string }>(`/api/booking/availability?${q}`, signal);
    },
    [serviceId, doctorParam],
  );

  useEffect(() => {
    if (step !== "datetime" || !serviceId) return;
    const ctrl = new AbortController();
    setMonthState("loading");
    loadMonth(ym.y, ym.m, ctrl.signal)
      .then((r) => {
        if (!r) return;
        setAvailable(new Set(r.available));
        setLastBookable(r.lastBookable);
        setMonthState("idle");
      })
      .catch((e) => {
        if ((e as Error).name !== "AbortError") setMonthState("error");
      });
    return () => ctrl.abort();
  }, [step, serviceId, ym, loadMonth]);

  // ── Day slots ───────────────────────────────────────────────
  const loadSlots = useCallback(
    async (d: string, signal?: AbortSignal) => {
      if (!serviceId) return;
      setSlotsState("loading");
      try {
        const q = new URLSearchParams({ service: serviceId, doctor: doctorParam, date: d });
        const r = await getJSON<{ slots: Slot[] }>(`/api/booking/slots?${q}`, signal);
        setSlots(r.slots);
        setSlotsState("idle");
        setSlot((cur) => (cur && r.slots.some((s) => s.start === cur.start) ? cur : null));
      } catch (e) {
        if ((e as Error).name !== "AbortError") setSlotsState("error");
      }
    },
    [serviceId, doctorParam],
  );

  useEffect(() => {
    if (step !== "datetime" || !date) return;
    const ctrl = new AbortController();
    loadSlots(date, ctrl.signal);
    return () => ctrl.abort();
  }, [step, date, loadSlots]);

  const minMonth = { y: Number(today.slice(0, 4)), m: Number(today.slice(5, 7)) };
  const maxMonth = lastBookable ? { y: Number(lastBookable.slice(0, 4)), m: Number(lastBookable.slice(5, 7)) } : null;
  const cmp = (a: { y: number; m: number }, c: { y: number; m: number }) => a.y * 12 + a.m - (c.y * 12 + c.m);
  const canPrev = cmp(ym, minMonth) > 0;
  const canNext = maxMonth ? cmp(ym, maxMonth) < 0 : true;

  const findNextAvailable = async () => {
    setSearchingNext(true);
    let cur = { ...ym };
    try {
      for (let i = 0; i < 6; i++) {
        const next = new Date(Date.UTC(cur.y, cur.m, 1));
        cur = { y: next.getUTCFullYear(), m: next.getUTCMonth() + 1 };
        if (maxMonth && cmp(cur, maxMonth) > 0) break;
        const r = await loadMonth(cur.y, cur.m);
        if (r && r.available.length) {
          setYm(cur);
          setAvailable(new Set(r.available));
          setDate(r.available[0]);
          return;
        }
      }
    } catch {
      setMonthState("error");
    } finally {
      setSearchingNext(false);
    }
  };

  // ── Formatting helpers (always in clinic time) ──────────────
  const fmtDate = (iso: string) => capFirst(formatInstant(iso, tz, strings.dates, "full"));
  const fmtTime = (iso: string) => formatClock(iso, tz);
  const dayKeyLabel = (k: string) => capFirst(formatDateKey(k, strings.dates, "dayMonth"));
  const hourOf = (iso: string) =>
    Number(new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", hourCycle: "h23" }).format(new Date(iso)));

  // ── Navigation ──────────────────────────────────────────────
  const goTo = (s: StepId) => {
    setSubmitError(null);
    setStep(s);
  };
  const next = () => goTo(steps[Math.min(stepIndex + 1, steps.length - 1)]);
  const back = () => goTo(steps[Math.max(stepIndex - 1, 0)]);

  const chooseService = (id: string) => {
    const s = services.find((x) => x.id === id)!;
    setServiceId(id);
    setDoctorChoice(s.doctorIds.length === 1 ? s.doctorIds[0] : "any");
    setDate(null);
    setSlot(null);
    setSlots([]);
    setNotice(null);
    setStep(s.doctorIds.length > 1 ? "doctor" : "datetime");
  };
  const chooseDoctor = (id: string) => {
    setDoctorChoice(id);
    setDate(null);
    setSlot(null);
    setSlots([]);
    setStep("datetime");
  };

  // ── Details validation ──────────────────────────────────────
  const validate = (d: Details) => {
    const r = schema.safeParse(d);
    if (r.success) return {};
    const out: Record<string, string> = {};
    for (const issue of r.error.issues) {
      const k = String(issue.path[0]);
      if (!out[k]) out[k] = issue.message;
    }
    return out;
  };
  const setField = <K extends keyof Details>(k: K, v: Details[K]) => {
    const nextD = { ...details, [k]: v };
    setDetails(nextD);
    if (touched[k] || fieldErrs[k]) setFieldErrs(validate(nextD));
  };
  const blur = (k: keyof Details) => {
    setTouched((t) => ({ ...t, [k]: true }));
    setFieldErrs(validate(details));
  };
  const submitDetails = (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate(details);
    setFieldErrs(errs);
    setTouched({ fullName: true, phone: true, email: true, note: true, acceptPrivacy: true });
    const firstBad = Object.keys(errs)[0];
    if (firstBad) {
      document.getElementById(`f-${firstBad}`)?.focus();
      return;
    }
    next();
  };
  const errText = (k: string) => (fieldErrs[k] ? lookup({ errors: strings.errors }, fieldErrs[k]) : null);

  // ── Submit ──────────────────────────────────────────────────
  const submit = async () => {
    if (!service || !slot) return;
    const sig = `${service.id}|${doctorParam}|${slot.start}|${details.email.trim().toLowerCase()}`;
    if (!idemRef.current || idemRef.current.sig !== sig) idemRef.current = { sig, key: newKey() };
    setSubmitting(true);
    setSubmitError(null);
    let res: Response;
    try {
      res = await fetch("/api/booking", {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json" },
        body: JSON.stringify({
          serviceId: service.id,
          doctorId: doctorParam,
          start: slot.start,
          locale: config.locale,
          idempotencyKey: idemRef.current.key,
          sessionToken: token,
          turnstileToken,
          website: honeypot,
          patient: details,
        }),
      });
    } catch {
      setSubmitting(false);
      setSubmitError("network");
      return;
    }
    let data: Record<string, unknown> = {};
    try {
      data = await res.json();
    } catch {
      /* non-JSON error page */
    }
    setSubmitting(false);
    if (res.ok) {
      setResult(data as unknown as BookingResult);
      return;
    }
    const code = String(data.error ?? "");
    const refreshToken = async () => {
      try {
        const r = await getJSON<{ token: string }>("/api/booking/session");
        setToken(r.token);
      } catch {
        /* keep old token; next attempt will report again */
      }
    };
    switch (code) {
      case "SLOT_UNAVAILABLE":
        idemRef.current = null;
        setSlot(null);
        setNotice("slotTaken");
        setStep("datetime");
        if (date) loadSlots(date);
        return;
      case "SESSION_EXPIRED":
        await refreshToken();
        idemRef.current = null;
        setSlot(null);
        setNotice("sessionExpired");
        setStep("datetime");
        if (date) loadSlots(date);
        return;
      case "VALIDATION":
        setFieldErrs(
          Object.fromEntries(
            Object.entries((data.fields as Record<string, string>) ?? {}).map(([k, v]) => [k.replace(/^patient\./, ""), v]),
          ),
        );
        setNotice("fixFields");
        setStep("details");
        return;
      case "RATE_LIMITED":
        setSubmitError("rateLimited");
        break;
      case "BOT":
        await refreshToken();
        setSubmitError("bot");
        break;
      case "SERVICE_UNAVAILABLE":
        setSubmitError("serviceUnavailable");
        break;
      case "DOCTOR_UNAVAILABLE":
        setSubmitError("doctorUnavailable");
        break;
      case "BOOKING_DISABLED":
        setSubmitError("bookingDisabled");
        break;
      default:
        setSubmitError("server");
    }
    requestAnimationFrame(() => errorRef.current?.focus());
  };

  const startOver = () => {
    setResult(null);
    setServiceId(null);
    setDoctorChoice("any");
    setDate(null);
    setSlot(null);
    setSlots([]);
    setDetails(EMPTY_DETAILS);
    setFieldErrs({});
    setTouched({});
    setNotice(null);
    idemRef.current = null;
    setStep("service");
    getJSON<{ token: string }>("/api/booking/session")
      .then((r) => setToken(r.token))
      .catch(() => {});
  };

  // ── Success ─────────────────────────────────────────────────
  if (result) {
    return (
      <Success
        result={result}
        serviceName={service?.name ?? ""}
        email={details.email}
        strings={b}
        fmtDate={fmtDate}
        fmtTime={fmtTime}
        headingRef={headingRef}
        homeHref={config.homeHref}
        clinicName={config.clinicName}
        onAnother={startOver}
      />
    );
  }

  const selectedDoctorName =
    doctorChoice !== "any"
      ? doctorById.get(doctorChoice)?.name
      : slot && slot.doctorIds.length === 1
        ? doctorById.get(slot.doctorIds[0])?.name
        : null;

  const stepTitle: Record<StepId, string> = {
    service: b.service.heading,
    doctor: b.doctor.heading,
    datetime: b.date.heading,
    details: b.details.heading,
    review: b.review.heading,
  };

  // ── Layout ──────────────────────────────────────────────────
  return (
    <div className="grid gap-10 lg:grid-cols-12 lg:gap-12">
      <div className="lg:col-span-8">
        <Progress
          steps={steps}
          current={stepIndex}
          labels={b.steps}
          progressLabel={fmt(b.progress, { current: stepIndex + 1, total: steps.length })}
          onJump={(i) => i < stepIndex && goTo(steps[i])}
        />

        <h2 ref={headingRef} tabIndex={-1} className="font-display text-plum mt-10 scroll-mt-28 text-3xl outline-none">
          {stepTitle[step]}
        </h2>

        {notice && (step === "datetime" || step === "details") && (
          <div role="alert" className="border-error bg-error-bg text-error mt-6 border-l-2 px-4 py-3 text-sm">
            {b.errors[notice]}
          </div>
        )}

        {/* STEP: service */}
        {step === "service" && (
          <div className="mt-8">
            {services.length === 0 ? (
              <p className="text-ink-muted">{b.service.none}</p>
            ) : (
              <ul className="grid gap-3 sm:grid-cols-2" role="list">
                {[...services]
                  .sort((a, c) => Number(c.isConsultation) - Number(a.isConsultation))
                  .map((s) => {
                    const sel = s.id === serviceId;
                    return (
                      <li key={s.id}>
                        <button
                          type="button"
                          onClick={() => chooseService(s.id)}
                          aria-pressed={sel}
                          className={`group flex h-full w-full flex-col items-start border p-5 text-left transition-colors duration-200 ${
                            sel ? "border-plum ring-plum bg-white ring-1" : "border-line hover:border-plum/60 bg-white"
                          } ${s.isConsultation ? "sm:col-span-2" : ""}`}
                        >
                          <span className="flex w-full items-baseline justify-between gap-3">
                            <span className="font-display text-plum text-xl">{s.name}</span>
                            {s.durationMinutes && (
                              <span className="text-ink-muted shrink-0 text-xs tabular-nums">
                                {fmt(strings.minutes, { n: s.durationMinutes })}
                              </span>
                            )}
                          </span>
                          <span className="text-ink-muted mt-1.5 text-sm">{s.isConsultation ? b.service.consultationHint : s.summary}</span>
                          {s.price && <span className="text-champagne-ink mt-3 text-sm">{s.price}</span>}
                        </button>
                      </li>
                    );
                  })}
              </ul>
            )}
          </div>
        )}

        {/* STEP: doctor */}
        {step === "doctor" && service && (
          <div className="mt-8">
            <ul className="grid gap-3 sm:grid-cols-2">
              <li>
                <button
                  type="button"
                  onClick={() => chooseDoctor("any")}
                  aria-pressed={doctorChoice === "any"}
                  className={`h-full w-full border bg-white p-5 text-left ${doctorChoice === "any" ? "border-plum ring-plum ring-1" : "border-line hover:border-plum/60"}`}
                >
                  <span className="font-display text-plum block text-xl">{b.doctor.any}</span>
                  <span className="text-ink-muted mt-1 block text-sm">{b.doctor.anyHint}</span>
                </button>
              </li>
              {eligibleDoctors.map((d) => (
                <li key={d.id}>
                  <button
                    type="button"
                    onClick={() => chooseDoctor(d.id)}
                    aria-pressed={doctorChoice === d.id}
                    className={`flex h-full w-full items-center gap-4 border bg-white p-5 text-left ${doctorChoice === d.id ? "border-plum ring-plum ring-1" : "border-line hover:border-plum/60"}`}
                  >
                    <span
                      aria-hidden
                      className="bg-plum text-champagne grid h-12 w-12 shrink-0 place-items-center overflow-hidden rounded-full text-sm"
                    >
                      {d.photoUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={d.photoUrl} alt="" className="h-full w-full object-cover" />
                      ) : (
                        d.name
                          .replace(/^Dr\.?\s*/, "")
                          .split(" ")
                          .map((x) => x[0])
                          .join("")
                          .slice(0, 2)
                      )}
                    </span>
                    <span>
                      <span className="text-plum block text-lg">{d.name}</span>
                      {d.title && <span className="text-ink-muted block text-sm">{d.title}</span>}
                    </span>
                  </button>
                </li>
              ))}
            </ul>
            <NavButtons back={back} backLabel={b.nav.back} />
          </div>
        )}

        {/* STEP: date & time */}
        {step === "datetime" && service && (
          <div className="mt-8">
            <div className="grid gap-10 md:grid-cols-2 md:gap-8">
              <div>
                {monthState === "error" ? (
                  <ErrorRetry text={b.errors.loadFailed} retry={b.errors.retry} onRetry={() => setYm({ ...ym })} />
                ) : (
                  <Calendar
                    year={ym.y}
                    month={ym.m}
                    available={available}
                    loading={monthState === "loading"}
                    selected={date}
                    today={today}
                    lastBookable={lastBookable}
                    canPrev={canPrev}
                    canNext={canNext}
                    names={strings.dates}
                    strings={b.date}
                    onSelect={(d) => {
                      setDate(d);
                      setSlot(null);
                      setNotice(null);
                    }}
                    onMonthChange={(y, m) => {
                      setYm({ y, m });
                      setAvailable(new Set());
                    }}
                  />
                )}
                {monthState === "idle" && available.size === 0 && (
                  <div className="border-line mt-4 border bg-white p-4 text-sm">
                    <p className="text-ink-muted">{b.date.noneThisMonth}</p>
                    {canNext && (
                      <button type="button" onClick={findNextAvailable} disabled={searchingNext} className="btn btn-secondary btn-sm mt-3">
                        {searchingNext && <span className="spinner" aria-hidden />}
                        {b.date.jumpNext}
                      </button>
                    )}
                  </div>
                )}
                <p className="text-ink-muted mt-4 text-xs">{fmt(b.date.timezoneNote, { tz: tz.replace(/_/g, " ") })}</p>
              </div>

              <div aria-live="polite">
                <h3 className="text-ink text-sm font-medium">{date ? dayKeyLabel(date) : b.time.heading}</h3>
                {!date && <p className="text-ink-muted mt-3 text-sm">{b.time.pickDayFirst}</p>}
                {date && slotsState === "loading" && (
                  <div className="mt-4 grid grid-cols-3 gap-2" role="status" aria-label={b.time.loading}>
                    {Array.from({ length: 9 }).map((_, i) => (
                      <span key={i} className="skeleton h-11" />
                    ))}
                  </div>
                )}
                {date && slotsState === "error" && (
                  <ErrorRetry text={b.errors.loadFailed} retry={b.errors.retry} onRetry={() => loadSlots(date)} />
                )}
                {date && slotsState === "idle" && slots.length === 0 && <p className="text-ink-muted mt-3 text-sm">{b.time.none}</p>}
                {date && slotsState === "idle" && slots.length > 0 && (
                  <fieldset className="mt-4">
                    <legend className="sr-only">{b.time.heading}</legend>
                    {(
                      [
                        [b.time.morning, slots.filter((s) => hourOf(s.start) < 12)],
                        [b.time.afternoon, slots.filter((s) => hourOf(s.start) >= 12 && hourOf(s.start) < 17)],
                        [b.time.evening, slots.filter((s) => hourOf(s.start) >= 17)],
                      ] as [string, Slot[]][]
                    )
                      .filter(([, list]) => list.length)
                      .map(([label, list]) => (
                        <div key={label} className="mb-5">
                          <p className="text-ink-muted mb-2 text-xs">{label}</p>
                          <div className="grid grid-cols-3 gap-2 sm:grid-cols-4 md:grid-cols-3 xl:grid-cols-4">
                            {list.map((s) => {
                              const checked = slot?.start === s.start;
                              return (
                                <label
                                  key={s.start}
                                  className={`has-[:focus-visible]:outline-plum relative grid h-11 cursor-pointer place-items-center rounded-full border text-[0.9375rem] tabular-nums transition-colors duration-150 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 ${
                                    checked ? "border-plum bg-plum text-white" : "border-line-strong text-plum hover:border-plum bg-white"
                                  }`}
                                >
                                  <input
                                    type="radio"
                                    name="slot"
                                    value={s.start}
                                    checked={checked}
                                    onChange={() => setSlot(s)}
                                    className="sr-only"
                                  />
                                  {fmtTime(s.start)}
                                </label>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                  </fieldset>
                )}
              </div>
            </div>
            <NavButtons
              back={back}
              backLabel={b.nav.back}
              next={() => {
                setNotice(null);
                next();
              }}
              nextLabel={b.nav.continue}
              nextDisabled={!slot}
            />
          </div>
        )}

        {/* STEP: details */}
        {step === "details" && (
          <form className="mt-6" noValidate onSubmit={submitDetails}>
            <p className="text-ink-muted">{b.details.intro}</p>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              <Field id="fullName" label={b.details.fullName} error={errText("fullName")} className="sm:col-span-2">
                <input
                  id="f-fullName"
                  className="input"
                  autoComplete="name"
                  value={details.fullName}
                  onChange={(e) => setField("fullName", e.target.value)}
                  onBlur={() => blur("fullName")}
                  aria-invalid={Boolean(fieldErrs.fullName)}
                  aria-describedby={fieldErrs.fullName ? "e-fullName" : undefined}
                  required
                  maxLength={120}
                />
              </Field>
              <Field id="phone" label={b.details.phone} hint={b.details.phoneHint} error={errText("phone")}>
                <input
                  id="f-phone"
                  className="input"
                  type="tel"
                  inputMode="tel"
                  autoComplete="tel"
                  placeholder="+383 …"
                  value={details.phone}
                  onChange={(e) => setField("phone", e.target.value)}
                  onBlur={() => blur("phone")}
                  aria-invalid={Boolean(fieldErrs.phone)}
                  aria-describedby={`h-phone${fieldErrs.phone ? " e-phone" : ""}`}
                  required
                  maxLength={32}
                />
              </Field>
              <Field id="email" label={b.details.email} hint={b.details.emailHint} error={errText("email")}>
                <input
                  id="f-email"
                  className="input"
                  type="email"
                  inputMode="email"
                  autoComplete="email"
                  value={details.email}
                  onChange={(e) => setField("email", e.target.value)}
                  onBlur={() => blur("email")}
                  aria-invalid={Boolean(fieldErrs.email)}
                  aria-describedby={`h-email${fieldErrs.email ? " e-email" : ""}`}
                  required
                  maxLength={200}
                />
              </Field>
              <fieldset className="sm:col-span-2">
                <legend className="field-label">{b.details.returning}</legend>
                <div className="flex flex-wrap gap-2">
                  {(
                    [
                      ["new", b.details.returningNew],
                      ["returning", b.details.returningYes],
                    ] as const
                  ).map(([v, label]) => (
                    <label
                      key={v}
                      className={`has-[:focus-visible]:outline-plum cursor-pointer rounded-full border px-4 py-2 text-sm has-[:focus-visible]:outline has-[:focus-visible]:outline-2 ${details.isReturning === v ? "border-plum bg-plum text-white" : "border-line-strong text-ink bg-white"}`}
                    >
                      <input
                        type="radio"
                        name="returning"
                        value={v}
                        className="sr-only"
                        checked={details.isReturning === v}
                        onChange={() => setField("isReturning", v)}
                      />
                      {label}
                    </label>
                  ))}
                </div>
              </fieldset>
              <Field id="note" label={b.details.note} hint={b.details.noteHint} error={errText("note")} className="sm:col-span-2">
                <textarea
                  id="f-note"
                  className="input"
                  value={details.note}
                  onChange={(e) => setField("note", e.target.value)}
                  onBlur={() => blur("note")}
                  maxLength={1000}
                  aria-describedby={`h-note${fieldErrs.note ? " e-note" : ""}`}
                />
              </Field>
              <fieldset className="sm:col-span-2">
                <legend className="field-label">{b.details.updatesTitle}</legend>
                <p className="text-ink-muted text-sm">{b.details.updatesEmail}</p>
                <div className="mt-3 space-y-3">
                  <label className="flex items-start gap-3 text-sm">
                    <input
                      type="checkbox"
                      className="checkbox"
                      checked={details.consentSms}
                      onChange={(e) => setField("consentSms", e.target.checked)}
                    />
                    <span>{b.details.consentSms}</span>
                  </label>
                  <label className="flex items-start gap-3 text-sm">
                    <input
                      type="checkbox"
                      className="checkbox"
                      checked={details.consentWhatsapp}
                      onChange={(e) => setField("consentWhatsapp", e.target.checked)}
                    />
                    <span>{b.details.consentWhatsapp}</span>
                  </label>
                </div>
              </fieldset>
              <div className="sm:col-span-2">
                <label className="flex items-start gap-3 text-sm">
                  <input
                    id="f-acceptPrivacy"
                    type="checkbox"
                    className="checkbox"
                    checked={details.acceptPrivacy}
                    onChange={(e) => setField("acceptPrivacy", e.target.checked)}
                    aria-invalid={Boolean(fieldErrs.acceptPrivacy)}
                    aria-describedby={fieldErrs.acceptPrivacy ? "e-acceptPrivacy" : undefined}
                    required
                  />
                  <span>
                    {b.details.privacy.split("{link}")[0]}
                    <Link href={config.privacyHref} target="_blank" className="link-quiet text-plum">
                      {b.details.privacyLink}
                    </Link>
                    {b.details.privacy.split("{link}")[1]}
                  </span>
                </label>
                {errText("acceptPrivacy") && (
                  <p id="e-acceptPrivacy" className="field-error">
                    {errText("acceptPrivacy")}
                  </p>
                )}
              </div>
            </div>
            {/* Honeypot: hidden from people and assistive tech */}
            <div aria-hidden className="absolute -left-[9999px] h-px w-px overflow-hidden">
              <label>
                Website
                <input tabIndex={-1} autoComplete="off" name="website" value={honeypot} onChange={(e) => setHoneypot(e.target.value)} />
              </label>
            </div>
            <NavButtons back={back} backLabel={b.nav.back} submit nextLabel={b.nav.continue} />
          </form>
        )}

        {/* STEP: review */}
        {step === "review" && service && slot && (
          <div className="mt-8">
            <dl className="divide-line border-line divide-y border-y">
              <SummaryRow label={b.review.treatment} value={service.name} onEdit={() => goTo("service")} editLabel={b.review.edit} />
              {(showDoctorStep || selectedDoctorName) && (
                <SummaryRow
                  label={b.review.doctor}
                  value={selectedDoctorName ?? b.doctor.any}
                  onEdit={showDoctorStep ? () => goTo("doctor") : undefined}
                  editLabel={b.review.edit}
                />
              )}
              <SummaryRow label={b.review.date} value={fmtDate(slot.start)} onEdit={() => goTo("datetime")} editLabel={b.review.edit} />
              <SummaryRow
                label={b.review.time}
                value={`${fmtTime(slot.start)}${service.durationMinutes ? ` · ${fmt(strings.minutes, { n: service.durationMinutes })}` : ""}`}
                onEdit={() => goTo("datetime")}
                editLabel={b.review.edit}
              />
              <SummaryRow label={b.review.name} value={details.fullName} onEdit={() => goTo("details")} editLabel={b.review.edit} />
              <SummaryRow
                label={b.review.contact}
                value={`${details.phone} · ${details.email}`}
                onEdit={() => goTo("details")}
                editLabel={b.review.edit}
              />
              {details.note.trim() && (
                <SummaryRow label={b.review.note} value={details.note} onEdit={() => goTo("details")} editLabel={b.review.edit} />
              )}
            </dl>

            <p className="border-champagne text-ink-muted mt-6 border-l-2 bg-white px-4 py-3 text-sm">
              {config.autoConfirm ? b.review.autoNote : b.review.approvalNote}
            </p>

            {config.turnstileSiteKey && (
              <div className="mt-6">
                <Turnstile siteKey={config.turnstileSiteKey} onToken={setTurnstileToken} locale={config.locale} />
              </div>
            )}

            {submitError && (
              <div
                ref={errorRef}
                tabIndex={-1}
                role="alert"
                className="border-error bg-error-bg text-error mt-6 border-l-2 px-4 py-3 text-sm outline-none"
              >
                {b.errors[submitError]}
              </div>
            )}

            <div className="mt-8 flex flex-col-reverse gap-3 sm:flex-row sm:items-center sm:justify-between">
              <button type="button" onClick={back} className="btn btn-secondary" disabled={submitting}>
                {b.nav.back}
              </button>
              <button
                type="button"
                onClick={submit}
                className="btn btn-primary"
                disabled={submitting || Boolean(config.turnstileSiteKey && !turnstileToken)}
                aria-busy={submitting}
              >
                {submitting && <span className="spinner" aria-hidden />}
                {submitting ? b.review.submitting : config.autoConfirm ? b.review.submitConfirm : b.review.submitRequest}
              </button>
            </div>
            <p className="text-ink-muted mt-4 text-xs sm:text-right">
              {b.review.terms.split("{link}")[0]}
              <Link href={config.termsHref} target="_blank" className="link-quiet">
                {b.review.termsLink}
              </Link>
              {b.review.terms.split("{link}")[1]}
            </p>
          </div>
        )}
      </div>

      {/* Live summary (desktop) */}
      <aside className="hidden lg:col-span-4 lg:block">
        <div className="border-line sticky top-[calc(var(--gd-header-h)+2rem)] border bg-white p-7">
          <dl className="space-y-4 text-[0.9375rem]">
            <div>
              <dt className="text-ink-muted text-xs">{b.review.treatment}</dt>
              <dd className="font-display text-plum mt-0.5 text-xl">{service?.name ?? "—"}</dd>
            </div>
            {(showDoctorStep || selectedDoctorName) && (
              <div>
                <dt className="text-ink-muted text-xs">{b.review.doctor}</dt>
                <dd className="mt-0.5">{selectedDoctorName ?? (showDoctorStep ? b.doctor.any : "—")}</dd>
              </div>
            )}
            <div>
              <dt className="text-ink-muted text-xs">{b.review.date}</dt>
              <dd className="mt-0.5">{slot ? fmtDate(slot.start) : date ? dayKeyLabel(date) : "—"}</dd>
            </div>
            <div>
              <dt className="text-ink-muted text-xs">{b.review.time}</dt>
              <dd className="mt-0.5 tabular-nums">{slot ? fmtTime(slot.start) : "—"}</dd>
            </div>
          </dl>
          <p className="border-line text-ink-muted mt-6 border-t pt-4 text-xs">
            {config.autoConfirm ? b.review.autoNote : b.review.approvalNote}
          </p>
        </div>
      </aside>
    </div>
  );
}

// ── Pieces ────────────────────────────────────────────────────

function Progress({
  steps,
  current,
  labels,
  progressLabel,
  onJump,
}: {
  steps: StepId[];
  current: number;
  labels: Record<string, string>;
  progressLabel: string;
  onJump: (i: number) => void;
}) {
  return (
    <nav aria-label={progressLabel}>
      <p className="text-ink-muted text-sm sm:hidden">
        {progressLabel} · <span className="text-plum">{labels[steps[current]]}</span>
      </p>
      <div className="bg-line mt-3 h-px sm:hidden" aria-hidden>
        <div className="bg-plum h-px transition-[width] duration-500" style={{ width: `${((current + 1) / steps.length) * 100}%` }} />
      </div>
      <ol className="hidden items-center gap-2 sm:flex">
        {steps.map((s, i) => {
          const state = i < current ? "done" : i === current ? "current" : "todo";
          const content = (
            <>
              <span
                aria-hidden
                className={`grid h-6 w-6 rotate-45 place-items-center border text-[0.7rem] transition-colors ${
                  state === "current"
                    ? "border-plum bg-plum"
                    : state === "done"
                      ? "border-champagne-ink bg-champagne"
                      : "border-line-strong bg-ivory"
                }`}
              >
                <span
                  className={`-rotate-45 tabular-nums ${state === "current" ? "text-white" : state === "done" ? "text-plum" : "text-ink-muted"}`}
                >
                  {i + 1}
                </span>
              </span>
              <span className={state === "current" ? "text-plum" : state === "done" ? "text-ink" : "text-ink-muted"}>{labels[s]}</span>
            </>
          );
          return (
            <li key={s} className="flex items-center gap-2 text-sm" aria-current={state === "current" ? "step" : undefined}>
              {state === "done" ? (
                <button type="button" onClick={() => onJump(i)} className="hover:text-plum flex items-center gap-2.5 rounded">
                  {content}
                </button>
              ) : (
                <span className="flex items-center gap-2.5">{content}</span>
              )}
              {i < steps.length - 1 && <span aria-hidden className="bg-line-strong mx-1 h-px w-6 lg:w-8" />}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

function Field({
  id,
  label,
  hint,
  error,
  className = "",
  children,
}: {
  id: string;
  label: string;
  hint?: string;
  error: string | null;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={className}>
      <label htmlFor={`f-${id}`} className="field-label">
        {label}
      </label>
      {children}
      {hint && (
        <p id={`h-${id}`} className="field-hint">
          {hint}
        </p>
      )}
      {error && (
        <p id={`e-${id}`} className="field-error">
          {error}
        </p>
      )}
    </div>
  );
}

function NavButtons({
  back,
  backLabel,
  next,
  nextLabel,
  nextDisabled,
  submit,
}: {
  back: () => void;
  backLabel: string;
  next?: () => void;
  nextLabel?: string;
  nextDisabled?: boolean;
  submit?: boolean;
}) {
  return (
    <div className="mt-10 flex flex-col-reverse gap-3 sm:flex-row sm:justify-between">
      <button type="button" onClick={back} className="btn btn-secondary">
        {backLabel}
      </button>
      {(next || submit) && (
        <button type={submit ? "submit" : "button"} onClick={next} disabled={nextDisabled} className="btn btn-primary">
          {nextLabel}
        </button>
      )}
    </div>
  );
}

function ErrorRetry({ text, retry, onRetry }: { text: string; retry: string; onRetry: () => void }) {
  return (
    <div role="alert" className="border-error bg-error-bg text-error mt-4 border-l-2 px-4 py-3 text-sm">
      {text}{" "}
      <button type="button" onClick={onRetry} className="link-quiet font-medium">
        {retry}
      </button>
    </div>
  );
}

function SummaryRow({ label, value, onEdit, editLabel }: { label: string; value: string; onEdit?: () => void; editLabel: string }) {
  return (
    <div className="grid grid-cols-[7rem_1fr_auto] items-baseline gap-4 py-4 sm:grid-cols-[9rem_1fr_auto]">
      <dt className="text-ink-muted text-sm">{label}</dt>
      <dd className="break-words">{value}</dd>
      <dd>
        {onEdit && (
          <button type="button" onClick={onEdit} className="link-quiet text-plum text-sm" aria-label={`${editLabel}: ${label}`}>
            {editLabel}
          </button>
        )}
      </dd>
    </div>
  );
}

function icsFile(r: BookingResult, title: string, clinic: string) {
  const f = (iso: string) => iso.replace(/[-:]/g, "").replace(/\.\d{3}/, "");
  const lines = [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//GemDental Care//Booking//EN",
    "BEGIN:VEVENT",
    `UID:${r.reference}@gemdental`,
    `DTSTAMP:${f(new Date().toISOString())}`,
    `DTSTART:${f(r.startsAt)}`,
    `DTEND:${f(r.endsAt)}`,
    `SUMMARY:${title} · ${clinic}`.replace(/[,;]/g, "\\$&"),
    `DESCRIPTION:Ref ${r.reference}`,
    "END:VEVENT",
    "END:VCALENDAR",
  ];
  return `data:text/calendar;charset=utf-8,${encodeURIComponent(lines.join("\r\n"))}`;
}

function Success({
  result,
  serviceName,
  email,
  strings: b,
  fmtDate,
  fmtTime,
  headingRef,
  homeHref,
  clinicName,
  onAnother,
}: {
  result: BookingResult;
  serviceName: string;
  email: string;
  strings: BookingStrings["booking"];
  fmtDate: (iso: string) => string;
  fmtTime: (iso: string) => string;
  headingRef: React.RefObject<HTMLHeadingElement | null>;
  homeHref: string;
  clinicName: string;
  onAnother: () => void;
}) {
  const confirmed = result.status === "confirmed";
  useEffect(() => {
    headingRef.current?.focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [headingRef]);
  return (
    <div className="mx-auto max-w-2xl py-4 text-center" data-booking-status={result.status}>
      <span
        aria-hidden
        className={`mx-auto grid h-16 w-16 rotate-45 place-items-center border-2 ${confirmed ? "border-plum bg-plum" : "border-champagne-ink bg-champagne-soft"}`}
        style={{ animation: "gd-pop 600ms var(--gd-ease-out) both" }}
      >
        <svg className="-rotate-45" width="26" height="20" viewBox="0 0 26 20">
          {confirmed ? (
            <path d="M2 10l7 7L24 2" fill="none" stroke="#fff" strokeWidth="2.5" />
          ) : (
            <>
              <circle cx="13" cy="10" r="8" fill="none" stroke="#8A6A47" strokeWidth="2" />
              <path d="M13 5v5l3 2" fill="none" stroke="#8A6A47" strokeWidth="2" />
            </>
          )}
        </svg>
      </span>
      <h2 ref={headingRef} tabIndex={-1} className="font-display text-plum mt-10 text-3xl outline-none">
        {confirmed ? b.success.confirmedTitle : b.success.pendingTitle}
      </h2>
      <p className="text-ink-muted mx-auto mt-4 max-w-lg">{fmt(confirmed ? b.success.confirmedBody : b.success.pendingBody, { email })}</p>

      <div className="border-line mt-10 border bg-white p-6 text-left sm:p-8">
        <div className="border-line flex flex-wrap items-baseline justify-between gap-2 border-b pb-5">
          <span className="text-ink-muted text-sm">{b.success.reference}</span>
          <span className="text-plum text-2xl font-medium tracking-[0.08em] tabular-nums" data-testid="booking-reference">
            {result.reference}
          </span>
        </div>
        <dl className="mt-5 grid gap-3 text-[0.9375rem] sm:grid-cols-2">
          <div>
            <dt className="text-ink-muted text-xs">{b.review.treatment}</dt>
            <dd>{serviceName}</dd>
          </div>
          {result.doctorName && (
            <div>
              <dt className="text-ink-muted text-xs">{b.review.doctor}</dt>
              <dd>{result.doctorName}</dd>
            </div>
          )}
          <div>
            <dt className="text-ink-muted text-xs">{b.review.date}</dt>
            <dd>{fmtDate(result.startsAt)}</dd>
          </div>
          <div>
            <dt className="text-ink-muted text-xs">{b.review.time}</dt>
            <dd className="tabular-nums">{fmtTime(result.startsAt)}</dd>
          </div>
        </dl>
        <p className="text-ink-muted mt-5 text-xs">{b.success.referenceHint}</p>
      </div>

      <div className="mt-10 text-left">
        <h3 className="text-plum text-sm font-medium">{b.success.next}</h3>
        <ol className="text-ink-muted mt-3 space-y-2">
          {(confirmed ? b.success.nextConfirmed : b.success.nextPending).map((line, i) => (
            <li key={line} className="flex gap-3">
              <span className="font-display text-champagne-ink tabular-nums">{i + 1}.</span>
              {line}
            </li>
          ))}
        </ol>
      </div>

      <div className="mt-10 flex flex-col justify-center gap-3 sm:flex-row">
        {confirmed && (
          <a href={icsFile(result, serviceName, clinicName)} download={`gemdental-${result.reference}.ics`} className="btn btn-primary">
            {b.success.addToCalendar}
          </a>
        )}
        <Link href={homeHref} className="btn btn-secondary">
          {b.success.home}
        </Link>
        <button type="button" onClick={onAnother} className="btn btn-secondary">
          {b.success.another}
        </button>
      </div>
    </div>
  );
}
