"use client";

import { useEffect, useRef, useState } from "react";
import { formatDateKey, formatMonthYear, type DateNames } from "@/lib/i18n/dates";

type Props = {
  year: number;
  month: number; // 1–12
  available: Set<string>;
  loading: boolean;
  selected: string | null;
  today: string;
  lastBookable: string | null;
  canPrev: boolean;
  canNext: boolean;
  names: DateNames;
  strings: { prevMonth: string; nextMonth: string; available: string; unavailable: string; selected: string; loading: string };
  onSelect: (date: string) => void;
  onMonthChange: (year: number, month: number, focusDate?: string) => void;
};

const pad = (n: number) => String(n).padStart(2, "0");
const key = (y: number, m: number, d: number) => `${y}-${pad(m)}-${pad(d)}`;
function shift(dateKey: string, days: number) {
  const [y, m, d] = dateKey.split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return key(dt.getUTCFullYear(), dt.getUTCMonth() + 1, dt.getUTCDate());
}

/**
 * Month calendar following the WAI-ARIA date-grid pattern: one tab stop,
 * arrow keys move by day/week, PageUp/PageDown change month, Home/End jump
 * within the week. Only days the server reports as bookable are enabled.
 */
export function Calendar(p: Props) {
  const { year, month } = p;
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  const firstWeekday = (new Date(Date.UTC(year, month - 1, 1)).getUTCDay() + 6) % 7; // Monday = 0
  const [focusKey, setFocusKey] = useState<string>(() => p.selected ?? key(year, month, 1));
  const gridRef = useRef<HTMLTableElement>(null);
  const shouldFocus = useRef(false);

  // Keep the roving focus inside the visible month.
  useEffect(() => {
    if (!focusKey.startsWith(`${year}-${pad(month)}`)) {
      const firstAvail = [...p.available].sort()[0];
      setFocusKey(p.selected?.startsWith(`${year}-${pad(month)}`) ? p.selected : (firstAvail ?? key(year, month, 1)));
    }
  }, [year, month, p.available, p.selected, focusKey]);

  useEffect(() => {
    if (!shouldFocus.current) return;
    shouldFocus.current = false;
    gridRef.current?.querySelector<HTMLButtonElement>(`[data-date="${focusKey}"]`)?.focus();
  }, [focusKey, year, month]);

  const monthLabel = formatMonthYear(year, month, p.names);
  // Monday-first week
  const weekdays = [1, 2, 3, 4, 5, 6, 0].map((i) => ({ short: p.names.weekdaysShort[i], long: p.names.weekdays[i] }));
  const dayLabel = (k: string) => formatDateKey(k, p.names, "dayMonth");

  const moveFocus = (next: string) => {
    shouldFocus.current = true;
    const [ny, nm] = next.split("-").map(Number);
    if (ny !== year || nm !== month) {
      const forward = next > key(year, month, daysInMonth);
      if ((forward && !p.canNext) || (!forward && !p.canPrev)) return;
      p.onMonthChange(ny, nm, next);
    }
    setFocusKey(next);
  };

  const onKeyDown = (e: React.KeyboardEvent, k: string) => {
    const weekdayIdx = (new Date(`${k}T12:00:00Z`).getUTCDay() + 6) % 7;
    const map: Record<string, number> = { ArrowLeft: -1, ArrowRight: 1, ArrowUp: -7, ArrowDown: 7 };
    if (e.key in map) {
      e.preventDefault();
      moveFocus(shift(k, map[e.key]));
    } else if (e.key === "Home") {
      e.preventDefault();
      moveFocus(shift(k, -weekdayIdx));
    } else if (e.key === "End") {
      e.preventDefault();
      moveFocus(shift(k, 6 - weekdayIdx));
    } else if (e.key === "PageUp" || e.key === "PageDown") {
      e.preventDefault();
      const dir = e.key === "PageUp" ? -1 : 1;
      const d = Number(k.slice(8, 10));
      const t = new Date(Date.UTC(year, month - 1 + dir, 1));
      const dim = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth() + 1, 0)).getUTCDate();
      moveFocus(key(t.getUTCFullYear(), t.getUTCMonth() + 1, Math.min(d, dim)));
    }
  };

  const cells: (string | null)[] = [
    ...Array(firstWeekday).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => key(year, month, i + 1)),
  ];
  while (cells.length % 7) cells.push(null);
  const weeks = Array.from({ length: cells.length / 7 }, (_, i) => cells.slice(i * 7, i * 7 + 7));

  const go = (dir: -1 | 1) => {
    const t = new Date(Date.UTC(year, month - 1 + dir, 1));
    p.onMonthChange(t.getUTCFullYear(), t.getUTCMonth() + 1);
  };

  return (
    <div>
      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          onClick={() => go(-1)}
          disabled={!p.canPrev}
          aria-label={p.strings.prevMonth}
          className="border-line hover:border-plum disabled:hover:border-line grid h-11 w-11 place-items-center rounded-full border disabled:opacity-30"
        >
          <svg width="8" height="12" viewBox="0 0 8 12" aria-hidden>
            <path d="M7 1L2 6l5 5" stroke="currentColor" fill="none" strokeWidth="1.5" />
          </svg>
        </button>
        <h3 className="font-display text-plum text-xl capitalize" aria-live="polite" id="cal-month">
          {monthLabel}
        </h3>
        <button
          type="button"
          onClick={() => go(1)}
          disabled={!p.canNext}
          aria-label={p.strings.nextMonth}
          className="border-line hover:border-plum disabled:hover:border-line grid h-11 w-11 place-items-center rounded-full border disabled:opacity-30"
        >
          <svg width="8" height="12" viewBox="0 0 8 12" aria-hidden>
            <path d="M1 1l5 5-5 5" stroke="currentColor" fill="none" strokeWidth="1.5" />
          </svg>
        </button>
      </div>

      <table
        ref={gridRef}
        role="grid"
        aria-labelledby="cal-month"
        aria-busy={p.loading}
        className="mt-5 w-full table-fixed border-collapse"
      >
        <thead>
          <tr>
            {weekdays.map((w) => (
              <th key={w.long} scope="col" abbr={w.long} className="text-ink-muted pb-2 text-center text-xs font-normal capitalize">
                {w.short}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {weeks.map((week, wi) => (
            <tr key={wi}>
              {week.map((k, di) => {
                if (!k) return <td key={di} />;
                const isAvail = p.available.has(k);
                const isSel = p.selected === k;
                const isToday = k === p.today;
                const day = Number(k.slice(8, 10));
                return (
                  <td key={k} className="p-0.5 text-center">
                    <button
                      type="button"
                      data-date={k}
                      tabIndex={k === focusKey ? 0 : -1}
                      aria-disabled={!isAvail || p.loading}
                      aria-pressed={isSel}
                      aria-label={`${dayLabel(k)}, ${isSel ? p.strings.selected : isAvail ? p.strings.available : p.strings.unavailable}`}
                      onClick={() => isAvail && !p.loading && p.onSelect(k)}
                      onKeyDown={(e) => onKeyDown(e, k)}
                      onFocus={() => setFocusKey(k)}
                      className={[
                        "relative mx-auto grid aspect-square w-full max-w-12 min-w-10 place-items-center rounded-full text-[0.9375rem] tabular-nums transition-colors duration-150",
                        isSel
                          ? "bg-plum text-white"
                          : isAvail && !p.loading
                            ? "text-plum ring-line-strong hover:bg-champagne-soft hover:ring-plum cursor-pointer bg-white ring-1"
                            : "text-ink-muted/45 cursor-default",
                        isToday && !isSel ? "font-semibold" : "",
                      ].join(" ")}
                    >
                      {day}
                      {isToday && (
                        <span
                          aria-hidden
                          className={`absolute bottom-1.5 h-1 w-1 rounded-full ${isSel ? "bg-champagne" : "bg-champagne-ink"}`}
                        />
                      )}
                    </button>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
      {p.loading && (
        <p className="text-ink-muted mt-3 flex items-center gap-2 text-sm" role="status">
          <span className="spinner" aria-hidden /> {p.strings.loading}
        </p>
      )}
    </div>
  );
}
