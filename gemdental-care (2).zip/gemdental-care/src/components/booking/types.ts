import type { PublicDictionary } from "@/lib/i18n/dictionaries/en";

export type BookingService = {
  id: string;
  slug: string;
  name: string;
  summary: string;
  durationMinutes: number | null; // null when the clinic hides durations
  price: string | null;
  isConsultation: boolean;
  doctorIds: string[];
};

export type BookingDoctor = { id: string; slug: string; name: string; title: string; photoUrl: string | null };

export type Slot = { start: string; end: string; doctorIds: string[] };

export type BookingConfig = {
  locale: "sq" | "en";
  localeTag: string;
  timezone: string;
  autoConfirm: boolean;
  phoneCountry: string | null;
  turnstileSiteKey: string | null;
  privacyHref: string;
  termsHref: string;
  homeHref: string;
  clinicName: string;
};

export type BookingStrings = {
  booking: PublicDictionary["booking"];
  errors: PublicDictionary["errors"];
  dates: PublicDictionary["dates"];
  minutes: string;
};

export type Details = {
  fullName: string;
  phone: string;
  email: string;
  note: string;
  isReturning: "new" | "returning" | "unspecified";
  consentSms: boolean;
  consentWhatsapp: boolean;
  acceptPrivacy: boolean;
};

export type BookingResult = {
  status: "confirmed" | "pending";
  reference: string;
  startsAt: string;
  endsAt: string;
  doctorName: string | null;
};
