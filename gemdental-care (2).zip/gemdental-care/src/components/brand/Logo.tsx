/* eslint-disable @next/next/no-img-element */
/**
 * The official GemDental Care lockup. Rendered from a vector trace of the
 * supplied logo artwork; replace the files in /public/brand with the original
 * vector masters when available (docs/BRAND.md).
 */
const RATIO = 716 / 178;

export function Logo({
  tone = "plum",
  height = 40,
  alt = "GemDental Care",
  className,
  priority,
}: {
  tone?: "plum" | "white";
  height?: number;
  alt?: string;
  className?: string;
  priority?: boolean;
}) {
  return (
    <img
      src={`/brand/gemdental-logo-${tone}.svg`}
      alt={alt}
      width={Math.round(height * RATIO)}
      height={height}
      className={className}
      style={{ height, width: "auto" }}
      fetchPriority={priority ? "high" : undefined}
      decoding="async"
    />
  );
}

/** The tooth-and-diamond mark on its own. */
export function Mark({ tone = "plum", size = 32, className }: { tone?: "plum" | "white"; size?: number; className?: string }) {
  return (
    <img src={`/brand/gemdental-mark-${tone}.svg`} alt="" aria-hidden width={size} height={size} className={className} decoding="async" />
  );
}

/**
 * Oversized hairline outline of the mark: the background device used on the
 * official brand artwork.
 */
export function MarkOutline({
  tone = "champagne",
  className,
  style,
}: {
  tone?: "champagne" | "plum";
  className?: string;
  style?: React.CSSProperties;
}) {
  return (
    <img
      src={`/brand/gemdental-mark-outline-${tone}.svg`}
      alt=""
      aria-hidden
      className={className}
      style={style}
      decoding="async"
      loading="lazy"
    />
  );
}
