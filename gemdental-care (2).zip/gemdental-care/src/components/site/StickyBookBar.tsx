"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";

/**
 * Mobile-only booking bar. Appears after the visitor scrolls past the hero and
 * hides on the booking page itself. Never covers content: the page reserves
 * space for it at the bottom.
 */
export function StickyBookBar({ locale, label, call, phone }: { locale: string; label: string; call: string; phone: string | null }) {
  const pathname = usePathname() ?? "";
  const [visible, setVisible] = useState(false);
  const hidden = pathname.includes("/booking");

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 520);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  if (hidden) return null;
  return (
    <>
      <div aria-hidden className="h-20 md:hidden" />
      <div
        className={`border-line bg-ivory/95 fixed inset-x-0 bottom-0 z-30 border-t px-4 pt-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-md transition-transform duration-300 md:hidden ${
          visible ? "translate-y-0" : "translate-y-full"
        }`}
        inert={!visible}
      >
        <div className="flex gap-3">
          {phone && (
            <a href={`tel:${phone}`} className="btn btn-secondary flex-1">
              {call}
            </a>
          )}
          <Link href={`/${locale}/booking`} className="btn btn-primary flex-[2]">
            {label}
          </Link>
        </div>
      </div>
    </>
  );
}
