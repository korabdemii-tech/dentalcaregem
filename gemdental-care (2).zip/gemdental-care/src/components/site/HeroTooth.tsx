"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Transparent, looping 3D tooth animation for the homepage hero.
 *
 * Browsers can't play a transparent MP4, and transparent WebM doesn't work on
 * iPhone, so the video is "stacked": colour in the top half, the alpha mask
 * (as grey) in the bottom half. A tiny WebGL shader combines the two into a
 * transparent canvas, which works in every modern browser.
 *
 * Shows a transparent still instead when the visitor prefers reduced motion,
 * when WebGL isn't available, and while the video loads. Pauses when the hero
 * is scrolled out of view.
 */
const VERT = `
attribute vec2 p;
varying vec2 v;
void main() {
  v = vec2((p.x + 1.0) * 0.5, (1.0 - p.y) * 0.5);
  gl_Position = vec4(p, 0.0, 1.0);
}`;

const FRAG = `
precision mediump float;
varying vec2 v;
uniform sampler2D t;
void main() {
  vec3 c = texture2D(t, vec2(v.x, v.y * 0.5)).rgb;
  float a = texture2D(t, vec2(v.x, 0.5 + v.y * 0.5)).r;
  a = smoothstep(0.03, 0.97, a);
  gl_FragColor = vec4(c * a, a);
}`;

export function HeroTooth({
  sources = [
    { src: "/hero/tooth-stacked.mp4", type: "video/mp4" },
    { src: "/hero/tooth-stacked.webm", type: "video/webm" },
  ],
  poster = "/hero/tooth-poster.webp",
  width = 600,
  height = 720,
  className = "",
}: {
  sources?: { src: string; type: string }[];
  poster?: string;
  width?: number;
  height?: number;
  className?: string;
}) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (!canvas || !video) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;

    const gl = canvas.getContext("webgl", { premultipliedAlpha: true, alpha: true, antialias: false });
    if (!gl) return;

    const compile = (type: number, source: string) => {
      const s = gl.createShader(type)!;
      gl.shaderSource(s, source);
      gl.compileShader(s);
      return s;
    };
    const prog = gl.createProgram()!;
    gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
    gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
    gl.linkProgram(prog);
    if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return;
    gl.useProgram(prog);

    const buf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(prog, "p");
    gl.enableVertexAttribArray(loc);
    gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);

    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.clearColor(0, 0, 0, 0);

    let raf = 0;
    let stopped = false;
    let first = true;
    const draw = () => {
      if (stopped) return;
      if (video.readyState >= 2) {
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, video);
        gl.clear(gl.COLOR_BUFFER_BIT);
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        if (first) {
          first = false;
          setPlaying(true);
        }
      }
      raf = requestAnimationFrame(draw);
    };

    const start = () => {
      video.play().catch(() => {
        /* autoplay refused: keep showing the still */
      });
    };
    const io = new IntersectionObserver(([entry]) => (entry.isIntersecting ? start() : video.pause()), { threshold: 0.05 });
    io.observe(canvas);
    raf = requestAnimationFrame(draw);

    return () => {
      stopped = true;
      cancelAnimationFrame(raf);
      io.disconnect();
      video.pause();
      gl.getExtension("WEBGL_lose_context")?.loseContext();
    };
  }, []);

  return (
    <div className={`relative ${className}`} aria-hidden>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={poster}
        alt=""
        width={width}
        height={height}
        className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-500 ${playing ? "opacity-0" : "opacity-100"}`}
      />
      <canvas
        ref={canvasRef}
        width={width}
        height={height}
        className={`absolute inset-0 h-full w-full object-contain transition-opacity duration-500 ${playing ? "opacity-100" : "opacity-0"}`}
      />
      <video
        ref={videoRef}
        muted
        loop
        playsInline
        preload="auto"
        disablePictureInPicture
        className="pointer-events-none absolute h-px w-px opacity-0"
        tabIndex={-1}
      >
        {sources.map((s) => (
          <source key={s.src} src={s.src} type={s.type} />
        ))}
      </video>
    </div>
  );
}
