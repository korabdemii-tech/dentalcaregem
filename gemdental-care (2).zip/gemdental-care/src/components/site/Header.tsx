"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { Logo } from "@/components/brand/Logo";
import type { Locale } from "@/lib/i18n/config";

type NavStrings = {
  home: string;
  treatments: string;
  results: string;
  about: string;
  doctor: string;
  contact: string;
  book: string;
};

export function Header({
  locale,
  locales,
  nav,
  a11y,
  showResults = false,
}: {
  showResults?: boolean;
  locale: Locale;
  locales: { code: Locale; label: string }[];
  nav: NavStrings;
  a11y: {
    openMenu: string;
    closeMenu: string;
    mainNav: string;
    language: string;
    homeLink: string;
  };
}) {
  const pathname = usePathname() ?? `/${locale}`;
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const toggleRef = useRef<HTMLButtonElement>(null);
  const headerRef = useRef<HTMLElement>(null);
  const [menuTop, setMenuTop] = useState<number | null>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close the menu on navigation.
  useEffect(() => setOpen(false), [pathname]);

  // Mobile menu: lock scroll, close on Escape, keep focus inside.
  useEffect(() => {
    if (!open) return;
    // Start the panel right under the header, wherever it sits (e.g. below the preview ribbon).
    setMenuTop(headerRef.current?.getBoundingClientRect().bottom ?? null);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const first = menuRef.current?.querySelector<HTMLElement>("a,button");
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setOpen(false);
        toggleRef.current?.focus();
      }
      if (e.key === "Tab" && menuRef.current) {
        const items = [...menuRef.current.querySelectorAll<HTMLElement>("a,button")];
        const all = [toggleRef.current!, ...items];
        const idx = all.indexOf(document.activeElement as HTMLElement);
        if (e.shiftKey && idx <= 0) {
          e.preventDefault();
          all[all.length - 1].focus();
        } else if (!e.shiftKey && idx === all.length - 1) {
          e.preventDefault();
          all[0].focus();
        }
      }
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const base = `/${locale}`;
  const links = [
    { href: base, label: nav.home, exact: true },
    { href: `${base}/services`, label: nav.treatments },
    ...(showResults ? [{ href: `${base}/results`, label: nav.results }] : []),
    { href: `${base}/about`, label: nav.about },
    { href: `${base}/team`, label: nav.doctor },
    { href: `${base}/contact`, label: nav.contact },
  ];
  const isActive = (href: string, exact?: boolean) => (exact ? pathname === href : pathname.startsWith(href));
  const pathWithoutLocale = pathname.replace(/^\/(sq|en)(?=\/|$)/, "");
  const switchHref = (code: Locale) => `/${code}${pathWithoutLocale}`;
  const rememberLocale = (code: Locale) => {
    document.cookie = `gd_locale=${code}; path=/; max-age=31536000; samesite=lax`;
  };

  return (
    <>
      <header
        ref={headerRef}
        className={`sticky top-0 z-40 transition-[background-color,border-color,box-shadow] duration-300 ${
          scrolled || open ? "border-line bg-ivory/92 border-b backdrop-blur-md" : "bg-ivory border-b border-transparent"
        }`}
      >
        <div className="container-gd flex h-[var(--gd-header-h)] items-center justify-between gap-6">
          <Link href={base} aria-label={a11y.homeLink} className="shrink-0">
            <Logo height={scrolled ? 34 : 40} priority className="transition-[height] duration-300" alt="" />
          </Link>

          <nav aria-label={a11y.mainNav} className="hidden lg:block">
            <ul className="flex items-center gap-6 text-[0.9375rem] xl:gap-8">
              {links.map((l) => (
                <li key={l.href}>
                  <Link
                    href={l.href}
                    aria-current={isActive(l.href, l.exact) ? "page" : undefined}
                    className="link-underline text-ink hover:text-plum aria-[current=page]:text-plum py-2"
                  >
                    {l.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="flex items-center gap-3">
            {locales.length > 1 && (
              <div className="hidden items-center gap-1 text-sm sm:flex" role="group" aria-label={a11y.language}>
                {locales.map((l, i) => (
                  <span key={l.code} className="flex items-center gap-1">
                    {i > 0 && (
                      <span aria-hidden className="text-line-strong">
                        /
                      </span>
                    )}
                    <Link
                      href={switchHref(l.code)}
                      hrefLang={l.code}
                      lang={l.code}
                      onClick={() => rememberLocale(l.code)}
                      aria-current={l.code === locale ? "true" : undefined}
                      className="text-ink-muted hover:text-plum aria-[current=true]:text-plum rounded px-1.5 py-1 tracking-wide uppercase aria-[current=true]:font-medium"
                      title={l.label}
                    >
                      {l.code}
                    </Link>
                  </span>
                ))}
              </div>
            )}
            <Link href={`${base}/booking`} className="btn btn-primary btn-sm hidden sm:inline-flex">
              {nav.book}
            </Link>
            <button
              ref={toggleRef}
              type="button"
              className="relative -mr-2 grid h-11 w-11 place-items-center rounded-full lg:hidden"
              aria-expanded={open}
              aria-controls="mobile-menu"
              aria-label={open ? a11y.closeMenu : a11y.openMenu}
              onClick={() => setOpen((v) => !v)}
            >
              <span aria-hidden className="relative block h-3 w-6">
                <span
                  className={`bg-plum absolute left-0 block h-px w-6 transition-transform duration-300 ${open ? "top-1.5 rotate-45" : "top-0"}`}
                />
                <span
                  className={`bg-plum absolute left-0 block h-px transition-all duration-300 ${open ? "top-1.5 w-6 -rotate-45" : "top-3 w-4"}`}
                />
              </span>
            </button>
          </div>
        </div>
        <span aria-hidden className="scroll-progress" />
      </header>

      {/* Mobile menu: outside <header> because its backdrop-filter would
          become the containing block for this fixed-position panel. */}
      <div
        id="mobile-menu"
        ref={menuRef}
        style={menuTop !== null ? { top: menuTop } : undefined}
        hidden={!open}
        className="bg-ivory fixed inset-x-0 top-[var(--gd-header-h)] bottom-0 z-40 overflow-y-auto lg:hidden"
      >
        <nav aria-label={a11y.mainNav} className="container-gd flex min-h-full flex-col pt-6 pb-10">
          <ul className="flex flex-col">
            {links.map((l, i) => (
              <li key={l.href} className="menu-item border-line border-b" style={{ ["--i" as string]: i }}>
                <Link
                  href={l.href}
                  aria-current={isActive(l.href, l.exact) ? "page" : undefined}
                  className="font-display text-plum flex items-center justify-between py-4 text-[1.75rem] leading-tight"
                >
                  {l.label}
                  {isActive(l.href, l.exact) && <span aria-hidden className="bg-champagne h-1.5 w-1.5 rotate-45" />}
                </Link>
              </li>
            ))}
          </ul>
          <div className="mt-auto flex flex-col gap-5 pt-10">
            <Link href={`${base}/booking`} className="btn btn-primary w-full">
              {nav.book}
            </Link>
            {locales.length > 1 && (
              <div className="flex items-center justify-center gap-2 text-sm" role="group" aria-label={a11y.language}>
                {locales.map((l) => (
                  <Link
                    key={l.code}
                    href={switchHref(l.code)}
                    hrefLang={l.code}
                    lang={l.code}
                    onClick={() => rememberLocale(l.code)}
                    aria-current={l.code === locale ? "true" : undefined}
                    className="border-line text-ink-muted aria-[current=true]:border-plum aria-[current=true]:text-plum rounded-full border px-4 py-2"
                  >
                    {l.label}
                  </Link>
                ))}
              </div>
            )}
          </div>
        </nav>
      </div>
    </>
  );
}
