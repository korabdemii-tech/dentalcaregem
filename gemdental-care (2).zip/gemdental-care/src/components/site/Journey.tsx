"use client";

import { useEffect, useRef, useState } from "react";

/**
 * Patient journey. A champagne line fills as the section scrolls through the
 * viewport and each step lights up as it is reached. Static when the visitor
 * prefers reduced motion.
 */
export function Journey({ steps }: { steps: { title: string; body: string }[] }) {
  const ref = useRef<HTMLOListElement>(null);
  const [progress, setProgress] = useState(1);

  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const el = ref.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      const p = (vh * 0.7 - r.top) / (r.height * 0.9);
      setProgress(Math.max(0, Math.min(1, p)));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  const n = steps.length;
  return (
    <ol ref={ref} className="relative grid gap-10 lg:grid-cols-5 lg:gap-6">
      {/* Track and fill: vertical on mobile, horizontal on desktop */}
      <span aria-hidden className="bg-line absolute top-2 bottom-2 left-[0.6875rem] w-px lg:hidden" />
      <span
        aria-hidden
        className="bg-champagne-ink absolute top-2 left-[0.6875rem] w-px lg:hidden"
        style={{ height: `calc((100% - 1rem) * ${progress})` }}
      />
      <span aria-hidden className="bg-line absolute top-[0.6875rem] left-[0.6875rem] hidden h-px w-[80%] lg:block" />
      <span
        aria-hidden
        className="bg-champagne-ink absolute top-[0.6875rem] left-[0.6875rem] hidden h-px lg:block"
        style={{ width: `calc(80% * ${progress})` }}
      />
      {steps.map((s, i) => {
        const reached = progress >= (i + 0.2) / n || progress === 1;
        return (
          <li key={s.title} className="relative grid grid-cols-[1.375rem_1fr] gap-x-5 lg:block">
            <span
              aria-hidden
              className={`relative z-10 mt-0.5 block h-[1.375rem] w-[1.375rem] rotate-45 border transition-colors duration-500 lg:mt-0 ${
                reached ? "border-champagne-ink bg-champagne" : "border-line-strong bg-ivory"
              }`}
            />
            <div className="lg:mt-8 lg:pr-4">
              <p className="font-display text-champagne-ink text-xl tabular-nums">{String(i + 1).padStart(2, "0")}</p>
              <h3 className="text-plum mt-1 text-lg font-medium">{s.title}</h3>
              <p className="text-ink-muted mt-2 text-sm">{s.body}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
