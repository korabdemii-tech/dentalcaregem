"use client";

import { useEffect } from "react";
import { initInteractions } from "@/lib/interactions";

/** Mounts the site-wide interaction layer (scroll reveals, spotlight, tilt). */
export function Interactions() {
  useEffect(() => initInteractions(document), []);
  return null;
}
