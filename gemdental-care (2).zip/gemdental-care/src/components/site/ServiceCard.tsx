import Link from "next/link";
import { ImageSlot } from "./ImageSlot";

export function ServiceCard({
  href,
  bookHref,
  name,
  summary,
  duration,
  image,
  labels,
  feature = false,
}: {
  href: string;
  bookHref: string;
  name: string;
  summary: string;
  duration: string | null;
  image: { src: string; width: number; height: number; alt: string } | null;
  labels: { learnMore: string; book: string; placeholder: string };
  feature?: boolean;
}) {
  return (
    <article
      data-spotlight
      className="group border-line hover:border-plum/50 relative flex h-full flex-col border bg-white transition-colors duration-300"
    >
      {/* Without a real photo, phones skip the placeholder to keep the list compact. */}
      <div className={`facet overflow-hidden ${image ? "" : "hidden sm:block"}`}>
        <ImageSlot
          src={image?.src}
          width={image?.width}
          height={image?.height}
          alt={image?.alt ?? ""}
          placeholderLabel={labels.placeholder}
          showLabel={false}
          tone={feature ? "plum" : "cream"}
          className={`${feature ? "aspect-[16/10]" : "aspect-[16/10]"} ease-gd transition-transform duration-700 group-hover:scale-[1.03]`}
          sizes="(min-width:1024px) 33vw, (min-width:640px) 50vw, 100vw"
        />
      </div>
      <div className="flex flex-1 flex-col p-6 sm:p-7">
        <div className="flex items-baseline justify-between gap-4">
          <h3 className="font-display text-plum text-2xl">
            <Link href={href} className="after:absolute after:inset-0 focus-visible:outline-none">
              {name}
            </Link>
          </h3>
          {duration && <span className="text-ink-muted shrink-0 text-xs tabular-nums">{duration}</span>}
        </div>
        <p className="text-ink-muted mt-3 text-[0.9375rem]">{summary}</p>
        <div className="mt-auto flex items-center justify-between gap-4 pt-6 text-sm">
          <span className="link-underline text-plum group-hover:bg-[length:100%_1px]">{labels.learnMore}</span>
          <Link href={bookHref} className="btn btn-secondary btn-sm relative z-10">
            {labels.book}
          </Link>
        </div>
      </div>
      <span aria-hidden className="ring-plum pointer-events-none absolute inset-0 group-has-[a:focus-visible]:ring-2" />
    </article>
  );
}
