"use client";

import { useId, useState } from "react";

export type AccordionItem = { id: string; question: string; answer: string };

/** Accessible accordion (WAI-ARIA pattern): buttons with aria-expanded controlling regions. */
export function Accordion({ items }: { items: AccordionItem[] }) {
  const [open, setOpen] = useState<string | null>(items[0]?.id ?? null);
  const uid = useId();
  return (
    <div className="border-line border-t">
      {items.map((item) => {
        const isOpen = open === item.id;
        const btn = `${uid}-b-${item.id}`;
        const panel = `${uid}-p-${item.id}`;
        return (
          <div key={item.id} className="border-line border-b">
            <h3>
              <button
                id={btn}
                type="button"
                aria-expanded={isOpen}
                aria-controls={panel}
                onClick={() => setOpen(isOpen ? null : item.id)}
                className="group text-ink hover:text-plum flex w-full items-start justify-between gap-6 py-5 text-left text-lg"
              >
                <span>{item.question}</span>
                <span aria-hidden className="relative mt-2.5 h-3 w-3 shrink-0">
                  <span className="bg-plum absolute top-1/2 left-0 h-px w-3" />
                  <span
                    className={`bg-plum absolute top-0 left-1/2 h-3 w-px transition-transform duration-300 ${isOpen ? "scale-y-0" : ""}`}
                  />
                </span>
              </button>
            </h3>
            <div
              id={panel}
              role="region"
              aria-labelledby={btn}
              className={`ease-gd grid transition-[grid-template-rows] duration-300 ${isOpen ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}
              inert={!isOpen}
            >
              <div className="overflow-hidden">
                <p className="measure-wide text-ink-muted pb-6 whitespace-pre-line">{item.answer}</p>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
