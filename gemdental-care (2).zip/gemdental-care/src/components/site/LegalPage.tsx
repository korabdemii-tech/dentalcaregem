import type { LegalDoc } from "@/lib/i18n/legal/en";
import { fmt } from "@/lib/i18n/format";
import { PageHeader } from "./PageHeader";

export function LegalPage({
  title,
  doc,
  vars,
  draftNotice,
  crumbs,
  crumbLabel,
}: {
  title: string;
  doc: LegalDoc;
  vars: Record<string, string>;
  draftNotice: string;
  crumbs: { href: string; label: string }[];
  crumbLabel: string;
}) {
  return (
    <>
      <PageHeader title={title} crumbs={crumbs} crumbLabel={crumbLabel} />
      <section className="section-y !pt-12">
        <div className="container-gd">
          <p role="note" className="measure-wide border-champagne bg-warning-bg text-champagne-ink border p-4 text-sm">
            {draftNotice}
          </p>
          <div className="measure-wide mt-10 space-y-10">
            {doc.sections.map((s) => (
              <section key={s.title}>
                <h2 className="font-display text-plum text-2xl">{s.title}</h2>
                {s.body.map((p) => (
                  <p key={p} className="text-ink-muted mt-4">
                    {fmt(p, vars)}
                  </p>
                ))}
              </section>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
