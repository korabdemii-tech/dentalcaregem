import Image from "next/image";
import { MarkOutline } from "@/components/brand/Logo";

/**
 * A photograph when the clinic has supplied one, otherwise a designed,
 * clearly labelled placeholder in brand colours. Never shows stock people.
 */
export function ImageSlot({
  src,
  alt,
  width,
  height,
  placeholderLabel,
  tone = "cream",
  className = "",
  sizes = "(min-width: 1024px) 50vw, 100vw",
  priority = false,
  showLabel = true,
}: {
  src?: string | null;
  alt: string;
  width?: number;
  height?: number;
  placeholderLabel: string;
  tone?: "cream" | "plum" | "champagne";
  className?: string;
  sizes?: string;
  priority?: boolean;
  showLabel?: boolean;
}) {
  if (src && width && height) {
    return (
      <div className={`bg-cream relative overflow-hidden ${className}`}>
        <Image src={src} alt={alt} fill sizes={sizes} priority={priority} className="object-cover" />
      </div>
    );
  }
  const bg =
    tone === "plum"
      ? "bg-plum text-mauve-light"
      : tone === "champagne"
        ? "bg-champagne-soft text-champagne-ink"
        : "bg-cream text-ink-muted";
  return (
    <div
      className={`relative overflow-hidden ${bg} ${className}`}
      {...(placeholderLabel ? { role: "img", "aria-label": placeholderLabel } : { "aria-hidden": true })}
    >
      <MarkOutline
        tone={tone === "plum" ? "champagne" : "plum"}
        className="pointer-events-none absolute -right-[18%] -bottom-[22%] h-[125%] w-auto max-w-none"
        style={{ opacity: tone === "plum" ? 0.35 : 0.14 }}
      />
      {showLabel && (
        <span className="absolute bottom-4 left-4 flex items-center gap-2 text-xs">
          <span aria-hidden className="inline-block h-px w-6 bg-current opacity-60" />
          {placeholderLabel}
        </span>
      )}
    </div>
  );
}
