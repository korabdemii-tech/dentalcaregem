import Link from "next/link";
import { Logo } from "@/components/brand/Logo";
import type { PublicDictionary } from "@/lib/i18n";
import type { Locale } from "@/lib/i18n/config";
import type { ClinicSettings } from "@/lib/settings";
import { fmt } from "@/lib/i18n/format";
import { formatPhoneDisplay, fullAddress, openingHoursLines, telHref, whatsappHref } from "@/lib/clinic-info";

export function Footer({
  t,
  locale,
  settings,
  showResults = false,
}: {
  t: PublicDictionary;
  locale: Locale;
  settings: ClinicSettings;
  showResults?: boolean;
}) {
  const base = `/${locale}`;
  const address = fullAddress(settings, locale);
  const hours = openingHoursLines(settings, t.days, t.common.closed);
  const social = Object.entries(settings.social ?? {}).filter(([, v]) => Boolean(v)) as [string, string][];
  const tbc = <span className="text-mauve-light/80 italic">{t.common.toBeConfirmed}</span>;

  return (
    <footer className="on-dark bg-plum-deep text-white">
      <div className="container-gd grid gap-12 py-16 md:grid-cols-12 md:py-20">
        <div className="md:col-span-4">
          <Logo tone="white" height={44} />
          <p className="text-mauve-light mt-6 max-w-xs text-sm">{t.footer.tagline}</p>
          <Link href={`${base}/booking`} className="btn btn-champagne btn-sm mt-8">
            {t.nav.book}
          </Link>
        </div>

        <nav aria-label={t.a11y.footerNav} className="md:col-span-2">
          <h2 className="text-champagne text-sm font-medium">{t.footer.explore}</h2>
          <ul className="text-mauve-light mt-4 space-y-2.5 text-sm">
            {[
              [base, t.nav.home],
              [`${base}/services`, t.nav.treatments],
              ...(showResults ? [[`${base}/results`, t.nav.results]] : []),
              [`${base}/about`, t.nav.about],
              [`${base}/team`, t.nav.doctor],
              [`${base}/contact`, t.nav.contact],
            ].map(([href, label]) => (
              <li key={href}>
                <Link href={href} className="link-underline hover:text-white">
                  {label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>

        <div className="md:col-span-3">
          <h2 className="text-champagne text-sm font-medium">{t.footer.visit}</h2>
          <address className="text-mauve-light mt-4 text-sm not-italic">{address || tbc}</address>
          <dl className="text-mauve-light mt-4 space-y-1 text-sm">
            {hours.length ? (
              hours.map((h) => (
                <div key={h.days} className="flex justify-between gap-4">
                  <dt>{h.days}</dt>
                  <dd className="tabular-nums">{h.hours}</dd>
                </div>
              ))
            ) : (
              <div>
                <dt className="sr-only">{t.home.info.hours}</dt>
                <dd>
                  {t.home.info.hours}: {tbc}
                </dd>
              </div>
            )}
          </dl>
        </div>

        <div className="md:col-span-3">
          <h2 className="text-champagne text-sm font-medium">{t.footer.contact}</h2>
          <ul className="text-mauve-light mt-4 space-y-2.5 text-sm">
            <li>
              {settings.phone ? (
                <a href={telHref(settings.phone)} className="link-underline hover:text-white">
                  {formatPhoneDisplay(settings.phone)}
                </a>
              ) : (
                <>
                  {t.contact.phone}: {tbc}
                </>
              )}
            </li>
            {settings.whatsapp && (
              <li>
                <a href={whatsappHref(settings.whatsapp)} className="link-underline hover:text-white" rel="noopener" target="_blank">
                  WhatsApp
                </a>
              </li>
            )}
            <li>
              {settings.email ? (
                <a href={`mailto:${settings.email}`} className="link-underline hover:text-white">
                  {settings.email}
                </a>
              ) : (
                <>
                  {t.contact.email}: {tbc}
                </>
              )}
            </li>
          </ul>
          {social.length > 0 && (
            <ul className="text-mauve-light mt-6 flex flex-wrap gap-4 text-sm">
              {social.map(([name, url]) => (
                <li key={name}>
                  <a href={url} target="_blank" rel="noopener" className="link-underline capitalize hover:text-white">
                    {name}
                  </a>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
      <div className="border-t border-white/10">
        <div className="container-gd text-mauve-light flex flex-col gap-3 py-6 text-xs sm:flex-row sm:items-center sm:justify-between">
          <p>{fmt(t.footer.rights, { year: new Date().getFullYear() })}</p>
          <ul className="flex gap-5">
            <li>
              <Link href={`${base}/privacy`} className="link-underline hover:text-white">
                {t.footer.privacy}
              </Link>
            </li>
            <li>
              <Link href={`${base}/terms`} className="link-underline hover:text-white">
                {t.footer.terms}
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}
