import Link from "next/link";
import { MarkOutline } from "@/components/brand/Logo";

export function PageHeader({
  title,
  lead,
  crumbs,
  crumbLabel,
}: {
  title: string;
  lead?: string;
  crumbs?: { href: string; label: string }[];
  crumbLabel: string;
}) {
  return (
    <section className="border-line relative overflow-hidden border-b">
      <MarkOutline className="pointer-events-none absolute -top-1/3 right-[-8%] h-[190%] w-auto max-w-none opacity-50" />
      <div className="container-gd relative pt-10 pb-14 md:pt-14 md:pb-20">
        {crumbs && crumbs.length > 0 && (
          <nav aria-label={crumbLabel} className="text-ink-muted mb-8 text-sm">
            <ol className="flex flex-wrap items-center gap-2">
              {crumbs.map((c, i) => (
                <li key={c.href} className="flex items-center gap-2">
                  {i > 0 && <span aria-hidden className="bg-champagne-ink/70 h-1 w-1 rotate-45" />}
                  <Link href={c.href} className="link-quiet">
                    {c.label}
                  </Link>
                </li>
              ))}
            </ol>
          </nav>
        )}
        <h1 className="font-display text-plum max-w-3xl text-4xl text-balance">{title}</h1>
        {lead && <p className="measure-wide text-ink-muted mt-6 text-lg">{lead}</p>}
      </div>
    </section>
  );
}
