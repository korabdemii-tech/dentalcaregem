import Link from "next/link";
import type { AppointmentRow } from "@/lib/admin/queries";
import type { AdminDictionary } from "@/lib/i18n/dictionaries/admin-en";
import { pick, type Locale } from "@/lib/i18n/config";
import { fmtDay, fmtTime } from "@/lib/admin/format";
import { StatusBadge } from "./fields";

/** Responsive appointment list: a table on wide screens, stacked rows on phones. */
export function AppointmentList({
  rows,
  a,
  tz,
  tag,
  locale,
  empty,
  showDate = true,
}: {
  rows: AppointmentRow[];
  a: AdminDictionary;
  tz: string;
  tag: string;
  locale: Locale;
  empty: string;
  showDate?: boolean;
}) {
  if (!rows.length)
    return (
      <p className="border-line-strong bg-ivory text-ink-muted rounded-md border border-dashed px-4 py-6 text-center text-sm">{empty}</p>
    );
  return (
    <div className="border-line overflow-hidden rounded-lg border bg-white">
      <table className="w-full text-left text-sm">
        <thead className="bg-ivory text-ink-muted hidden text-xs md:table-header-group">
          <tr>
            <th scope="col" className="px-4 py-2.5 font-normal">
              {a.appointments.when}
            </th>
            <th scope="col" className="px-4 py-2.5 font-normal">
              {a.appointments.patient}
            </th>
            <th scope="col" className="px-4 py-2.5 font-normal">
              {a.appointments.treatment}
            </th>
            <th scope="col" className="px-4 py-2.5 font-normal">
              {a.appointments.doctor}
            </th>
            <th scope="col" className="px-4 py-2.5 font-normal">
              {a.appointments.status}
            </th>
          </tr>
        </thead>
        <tbody className="divide-line divide-y">
          {rows.map((r) => (
            <tr key={r.id} className="hover:bg-ivory relative grid grid-cols-[auto_1fr] gap-x-4 px-4 py-3 md:table-row md:p-0">
              <td className="row-span-2 tabular-nums md:px-4 md:py-3">
                {showDate && <span className="text-ink-muted block text-xs">{fmtDay(r.startsAt, tz, tag)}</span>}
                <span className="text-plum font-medium">{fmtTime(r.startsAt, tz, tag)}</span>
              </td>
              <td className="md:px-4 md:py-3">
                <Link href={`/admin/appointments/${r.id}`} className="text-ink hover:text-plum font-medium after:absolute after:inset-0">
                  {r.patientName}
                </Link>
                <span className="text-ink-muted block text-xs">{r.reference}</span>
              </td>
              <td className="text-ink-muted md:text-ink col-start-2 md:px-4 md:py-3">{pick(r.serviceName, locale)}</td>
              <td className="hidden md:table-cell md:px-4 md:py-3">{r.doctorName}</td>
              <td className="col-start-2 mt-1 md:mt-0 md:px-4 md:py-3">
                <StatusBadge status={r.status} label={a.status[r.status]} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
