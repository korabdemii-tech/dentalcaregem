"use client";

import { createContext, useActionState, useContext, useEffect, useRef, startTransition } from "react";
import type { ActionState } from "@/lib/admin/action";

type Action = (prev: ActionState, form: FormData) => Promise<ActionState>;

const PendingContext = createContext(false);

/**
 * Form bound to a dashboard server action.
 *
 * Submits through onSubmit (not the `action` prop) so React does not reset the
 * fields afterwards: when the server reports a validation error, everything
 * the user typed is still there. Shows a live status message and marks
 * invalid fields with aria-invalid + an error message.
 */
export function AdminForm({
  action,
  children,
  className = "",
  resetOnSuccess = false,
  confirmText,
  id,
}: {
  action: Action;
  children: React.ReactNode;
  className?: string;
  resetOnSuccess?: boolean;
  confirmText?: string;
  id?: string;
}) {
  const [state, formAction, pending] = useActionState(action, {});
  const ref = useRef<HTMLFormElement>(null);

  useEffect(() => {
    if (state.ok && resetOnSuccess) ref.current?.reset();
  }, [state, resetOnSuccess]);

  useEffect(() => {
    const form = ref.current;
    if (!form) return;
    form.querySelectorAll("[aria-invalid]").forEach((el) => el.removeAttribute("aria-invalid"));
    form.querySelectorAll("[data-error-for]").forEach((el) => el.remove());
    let first: HTMLElement | null = null;
    for (const [name, msg] of Object.entries(state.errors ?? {})) {
      if (!msg) continue;
      const field = form.querySelector<HTMLElement>(`[name="${CSS.escape(name)}"]`);
      if (!field) continue;
      field.setAttribute("aria-invalid", "true");
      const p = document.createElement("p");
      p.className = "field-error";
      p.dataset.errorFor = name;
      p.id = `err-${id ?? "f"}-${name}`;
      p.textContent = msg;
      field.setAttribute("aria-describedby", p.id);
      (field.closest("label") ?? field).insertAdjacentElement("afterend", p);
      first ??= field;
    }
    first?.focus();
  }, [state, id]);

  return (
    <form
      ref={ref}
      id={id}
      className={className}
      noValidate
      onSubmit={(e) => {
        e.preventDefault();
        if (pending) return;
        if (confirmText && !window.confirm(confirmText)) return;
        const submitter = (e.nativeEvent as SubmitEvent).submitter as HTMLElement | null;
        const data = new FormData(e.currentTarget, submitter);
        startTransition(() => formAction(data));
      }}
    >
      <PendingContext value={pending}>{children}</PendingContext>
      {state.message && !pending ? (
        <p
          key={state.at}
          role={state.ok ? "status" : "alert"}
          className={`mt-4 rounded-md px-3 py-2 text-sm ${state.ok ? "bg-success-bg text-success" : "bg-error-bg text-error"}`}
        >
          {state.message}
        </p>
      ) : (
        <p role="status" aria-live="polite" className="sr-only" />
      )}
    </form>
  );
}

export function SubmitButton({
  children,
  pendingLabel,
  variant = "primary",
  className = "",
  name,
  value,
}: {
  children: React.ReactNode;
  pendingLabel?: string;
  variant?: "primary" | "secondary" | "danger" | "champagne";
  className?: string;
  name?: string;
  value?: string;
}) {
  const pending = useContext(PendingContext);
  return (
    <button
      type="submit"
      name={name}
      value={value}
      disabled={pending}
      aria-busy={pending}
      className={`btn btn-${variant} btn-sm ${className}`}
    >
      {pending && <span className="spinner" aria-hidden />}
      {pending && pendingLabel ? pendingLabel : children}
    </button>
  );
}
