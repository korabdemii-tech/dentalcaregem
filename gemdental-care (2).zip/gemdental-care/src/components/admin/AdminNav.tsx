"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

export type NavItem = { href: string; label: string; badge?: number };

export function AdminNav({ items, label }: { items: NavItem[]; label: string }) {
  const pathname = usePathname() ?? "/admin";
  return (
    <nav aria-label={label}>
      <ul className="space-y-0.5">
        {items.map((i) => {
          const active = i.href === "/admin" ? pathname === "/admin" : pathname === i.href || pathname.startsWith(`${i.href}/`);
          return (
            <li key={i.href}>
              <Link
                href={i.href}
                aria-current={active ? "page" : undefined}
                className="text-mauve-light flex items-center justify-between rounded-md px-3 py-2 hover:bg-white/5 hover:text-white aria-[current=page]:bg-white/10 aria-[current=page]:text-white"
              >
                {i.label}
                {i.badge ? (
                  <span className="bg-champagne text-plum-deep rounded-full px-2 text-xs font-medium tabular-nums">{i.badge}</span>
                ) : null}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
