/** Small server-friendly form field helpers for the dashboard. */
export function TextField({
  name,
  label,
  defaultValue,
  type = "text",
  hint,
  required,
  className = "",
  ...rest
}: {
  name: string;
  label: string;
  defaultValue?: string | number | null;
  type?: string;
  hint?: string;
  required?: boolean;
  className?: string;
} & Omit<React.InputHTMLAttributes<HTMLInputElement>, "name" | "defaultValue" | "type">) {
  const id = `fld-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">
        {label}
        {required && (
          <span aria-hidden className="text-error">
            {" "}
            *
          </span>
        )}
      </label>
      <input
        id={id}
        name={name}
        type={type}
        defaultValue={defaultValue ?? ""}
        required={required}
        className="input"
        aria-describedby={hint ? `${id}-hint` : undefined}
        {...rest}
      />
      {hint && (
        <p id={`${id}-hint`} className="field-hint">
          {hint}
        </p>
      )}
    </div>
  );
}

export function TextArea({
  name,
  label,
  defaultValue,
  hint,
  rows = 4,
  className = "",
  required,
}: {
  name: string;
  label: string;
  defaultValue?: string | null;
  hint?: string;
  rows?: number;
  className?: string;
  required?: boolean;
}) {
  const id = `fld-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">
        {label}
        {required && (
          <span aria-hidden className="text-error">
            {" "}
            *
          </span>
        )}
      </label>
      <textarea
        id={id}
        name={name}
        rows={rows}
        defaultValue={defaultValue ?? ""}
        className="input"
        aria-describedby={hint ? `${id}-hint` : undefined}
      />
      {hint && (
        <p id={`${id}-hint`} className="field-hint">
          {hint}
        </p>
      )}
    </div>
  );
}

export function Checkbox({
  name,
  label,
  defaultChecked,
  hint,
  disabled,
}: {
  name: string;
  label: string;
  defaultChecked?: boolean;
  hint?: string;
  disabled?: boolean;
}) {
  return (
    <label className="flex items-start gap-3 text-sm">
      <input type="checkbox" name={name} defaultChecked={defaultChecked} disabled={disabled} className="checkbox" />
      <span>
        {label}
        {hint && <span className="text-ink-muted mt-0.5 block text-xs">{hint}</span>}
      </span>
    </label>
  );
}

export function Select({
  name,
  label,
  defaultValue,
  options,
  className = "",
  hint,
}: {
  name: string;
  label: string;
  defaultValue?: string;
  options: { value: string; label: string }[];
  className?: string;
  hint?: string;
}) {
  const id = `fld-${name}`;
  return (
    <div className={className}>
      <label htmlFor={id} className="field-label">
        {label}
      </label>
      <select id={id} name={name} defaultValue={defaultValue} className="input">
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      {hint && <p className="field-hint">{hint}</p>}
    </div>
  );
}

export function Card({
  title,
  children,
  className = "",
  actions,
}: {
  title?: string;
  children: React.ReactNode;
  className?: string;
  actions?: React.ReactNode;
}) {
  return (
    <section className={`border-line rounded-lg border bg-white p-5 sm:p-6 ${className}`}>
      {(title || actions) && (
        <div className="mb-5 flex flex-wrap items-center justify-between gap-3">
          {title && <h2 className="text-plum text-lg font-medium">{title}</h2>}
          {actions}
        </div>
      )}
      {children}
    </section>
  );
}

export function StatusBadge({ status, label }: { status: string; label: string }) {
  const styles: Record<string, string> = {
    pending: "bg-warning-bg text-champagne-ink ring-champagne",
    confirmed: "bg-success-bg text-success ring-success/30",
    cancelled: "bg-cream text-ink-muted ring-line-strong line-through decoration-ink-muted/40",
    completed: "bg-cream text-plum ring-line-strong",
    no_show: "bg-error-bg text-error ring-error/30",
    reschedule_requested: "bg-warning-bg text-champagne-ink ring-champagne",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs whitespace-nowrap ring-1 ${styles[status] ?? "bg-cream ring-line"}`}
    >
      {label}
    </span>
  );
}

export function PageTitle({ title, lead, actions }: { title: string; lead?: string; actions?: React.ReactNode }) {
  return (
    <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="font-display text-plum text-3xl">{title}</h1>
        {lead && <p className="text-ink-muted mt-2 max-w-2xl text-sm">{lead}</p>}
      </div>
      {actions}
    </div>
  );
}
