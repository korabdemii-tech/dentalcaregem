import "server-only";
import type { Metadata } from "next";
import { env } from "@/lib/env";
import { enabledLocales, LOCALE_TAG, pick, type Locale } from "@/lib/i18n/config";
import type { ClinicSettings } from "@/lib/settings";

/** Canonical URL, hreflang alternates and Open Graph for a localized path ("" = home). */
export function pageMetadata({
  locale,
  path,
  title,
  description,
  image,
  noindex,
}: {
  locale: Locale;
  path: string;
  title: string;
  description: string;
  image?: string | null;
  noindex?: boolean;
}): Metadata {
  const site = env.siteUrl;
  const url = `${site}/${locale}${path}`;
  const languages: Record<string, string> = {};
  for (const l of enabledLocales()) languages[LOCALE_TAG[l]] = `${site}/${l}${path}`;
  languages["x-default"] = `${site}/${enabledLocales()[0]}${path}`;
  const og = image ? `${site}${image}` : `${site}/brand/og-default.png`;
  return {
    title,
    description,
    metadataBase: new URL(site),
    alternates: { canonical: url, languages },
    openGraph: {
      type: "website",
      url,
      siteName: "GemDental Care",
      title,
      description,
      locale: LOCALE_TAG[locale].replace("-", "_"),
      images: [{ url: og, width: 1200, height: 630, alt: "GemDental Care" }],
    },
    twitter: { card: "summary_large_image", title, description, images: [og] },
    robots: noindex ? { index: false, follow: false } : undefined,
  };
}

/**
 * schema.org Dentist (a LocalBusiness subtype), built only from confirmed
 * clinic settings. Fields that are not set are omitted, never invented.
 */
export function dentistJsonLd(settings: ClinicSettings, locale: Locale) {
  const site = env.siteUrl;
  const data: Record<string, unknown> = {
    "@context": "https://schema.org",
    "@type": "Dentist",
    "@id": `${site}/#clinic`,
    name: settings.clinicName,
    url: `${site}/${locale}`,
    logo: `${site}/brand/gemdental-logo-plum.svg`,
    image: `${site}/brand/og-default.png`,
  };
  if (settings.phone) data.telephone = settings.phone;
  if (settings.email) data.email = settings.email;
  const street = pick(settings.addressLine, locale);
  if (street) {
    data.address = {
      "@type": "PostalAddress",
      streetAddress: street,
      ...(settings.city ? { addressLocality: settings.city } : {}),
      ...(settings.postalCode ? { postalCode: settings.postalCode } : {}),
      ...(settings.country ? { addressCountry: settings.country } : {}),
    };
  }
  if (settings.latitude && settings.longitude)
    data.geo = { "@type": "GeoCoordinates", latitude: Number(settings.latitude), longitude: Number(settings.longitude) };
  if (settings.openingHours?.length) {
    const names = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    data.openingHoursSpecification = settings.openingHours
      .filter((h): h is { day: number; open: string; close: string } => !("closed" in h))
      .map((h) => ({ "@type": "OpeningHoursSpecification", dayOfWeek: names[h.day], opens: h.open, closes: h.close }));
  }
  const sameAs = Object.values(settings.social ?? {}).filter(Boolean);
  if (sameAs.length) data.sameAs = sameAs;
  return data;
}

/** Serialize JSON-LD safely for a <script> tag. */
export function jsonLd(data: unknown) {
  return { __html: JSON.stringify(data).replace(/</g, "\\u003c") };
}
