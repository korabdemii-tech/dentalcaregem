/**
 * Default message templates. The clinic can override any of them from the
 * dashboard (Notifications → Templates); overrides are stored in
 * notification_templates. Placeholders use {curly} names, see TEMPLATE_VARIABLES.
 */
import type { Locale } from "@/lib/i18n/config";

export type NotificationEvent = "request_received" | "confirmed" | "reminder" | "cancelled" | "rescheduled";
export type Channel = "email" | "sms" | "whatsapp";

export const NOTIFICATION_EVENTS: NotificationEvent[] = ["request_received", "confirmed", "reminder", "cancelled", "rescheduled"];
export const CHANNELS: Channel[] = ["email", "sms", "whatsapp"];

export const TEMPLATE_VARIABLES = [
  "firstName",
  "fullName",
  "service",
  "doctor",
  "date",
  "time",
  "reference",
  "clinicName",
  "clinicPhone",
  "contactLine",
  "bookingUrl",
] as const;

export type TemplateVars = Record<(typeof TEMPLATE_VARIABLES)[number], string>;

type Tpl = { subject?: string; body: string };

const details: Record<Locale, string> = {
  en: "Treatment: {service}\nDoctor: {doctor}\nDate: {date}\nTime: {time}\nReference: {reference}",
  sq: "Trajtimi: {service}\nMjeku: {doctor}\nData: {date}\nOra: {time}\nReferenca: {reference}",
};

export const DEFAULT_TEMPLATES: Record<NotificationEvent, Record<Exclude<Channel, "whatsapp">, Record<Locale, Tpl>>> = {
  request_received: {
    email: {
      en: {
        subject: "We've received your appointment request",
        body: `Hello {firstName},\n\nWe've received your appointment request at {clinicName}.\n\n${details.en}\n\nThis is a request, not yet a confirmed appointment. We'll contact you once your appointment has been confirmed.\n\n{clinicName}`,
      },
      sq: {
        subject: "Kërkesa juaj për termin u pranua",
        body: `Përshëndetje {firstName},\n\nKemi pranuar kërkesën tuaj për termin në {clinicName}.\n\n${details.sq}\n\nKjo është një kërkesë dhe termini ende nuk është konfirmuar. Do t'ju kontaktojmë sapo termini juaj të konfirmohet.\n\n{clinicName}`,
      },
    },
    sms: {
      en: { body: "{clinicName}: we received your request for {service} on {date} at {time} (ref {reference}). We'll confirm it soon." },
      sq: {
        body: "{clinicName}: e morëm kërkesën tuaj për {service} më {date} në orën {time} (ref. {reference}). Do ta konfirmojmë së shpejti.",
      },
    },
  },
  confirmed: {
    email: {
      en: {
        subject: "Your appointment is confirmed",
        body: `Hello {firstName},\n\nYour appointment at {clinicName} is confirmed.\n\n${details.en}\n\nIf you need to change or cancel it, please contact us{contactLine}.\n\n{clinicName}`,
      },
      sq: {
        subject: "Termini juaj është konfirmuar",
        body: `Përshëndetje {firstName},\n\nTermini juaj në {clinicName} është konfirmuar.\n\n${details.sq}\n\nNëse dëshironi ta ndryshoni ose ta anuloni, ju lutemi na kontaktoni{contactLine}.\n\n{clinicName}`,
      },
    },
    sms: {
      en: { body: "{clinicName}: your appointment for {service} on {date} at {time} is confirmed (ref {reference})." },
      sq: { body: "{clinicName}: termini juaj për {service} më {date} në orën {time} është konfirmuar (ref. {reference})." },
    },
  },
  reminder: {
    email: {
      en: {
        subject: "Reminder: your appointment on {date}",
        body: `Hello {firstName},\n\nThis is a reminder of your appointment at {clinicName}.\n\n${details.en}\n\nIf you can no longer attend, please let us know{contactLine}.\n\n{clinicName}`,
      },
      sq: {
        subject: "Kujtesë: termini juaj më {date}",
        body: `Përshëndetje {firstName},\n\nJu kujtojmë për terminin tuaj në {clinicName}.\n\n${details.sq}\n\nNëse nuk mund të vini, ju lutemi na njoftoni{contactLine}.\n\n{clinicName}`,
      },
    },
    sms: {
      en: { body: "{clinicName} reminder: {service} on {date} at {time} (ref {reference})." },
      sq: { body: "Kujtesë nga {clinicName}: {service} më {date} në orën {time} (ref. {reference})." },
    },
  },
  cancelled: {
    email: {
      en: {
        subject: "Your appointment has been cancelled",
        body: `Hello {firstName},\n\nYour appointment at {clinicName} on {date} at {time} (reference {reference}) has been cancelled.\n\nTo choose a new time, visit {bookingUrl} or contact us{contactLine}.\n\n{clinicName}`,
      },
      sq: {
        subject: "Termini juaj është anuluar",
        body: `Përshëndetje {firstName},\n\nTermini juaj në {clinicName} më {date} në orën {time} (referenca {reference}) është anuluar.\n\nPër të zgjedhur një orar të ri, vizitoni {bookingUrl} ose na kontaktoni{contactLine}.\n\n{clinicName}`,
      },
    },
    sms: {
      en: { body: "{clinicName}: your appointment on {date} at {time} (ref {reference}) has been cancelled." },
      sq: { body: "{clinicName}: termini juaj më {date} në orën {time} (ref. {reference}) është anuluar." },
    },
  },
  rescheduled: {
    email: {
      en: {
        subject: "Your appointment has a new time",
        body: `Hello {firstName},\n\nYour appointment at {clinicName} has been moved. Here are the new details:\n\n${details.en}\n\nIf the new time doesn't suit you, please contact us{contactLine}.\n\n{clinicName}`,
      },
      sq: {
        subject: "Termini juaj ka një orar të ri",
        body: `Përshëndetje {firstName},\n\nTermini juaj në {clinicName} është zhvendosur. Ja të dhënat e reja:\n\n${details.sq}\n\nNëse orari i ri nuk ju përshtatet, ju lutemi na kontaktoni{contactLine}.\n\n{clinicName}`,
      },
    },
    sms: {
      en: { body: "{clinicName}: your appointment is moved to {date} at {time} (ref {reference})." },
      sq: { body: "{clinicName}: termini juaj u zhvendos më {date} në orën {time} (ref. {reference})." },
    },
  },
};

export function renderTemplate(text: string, vars: Partial<TemplateVars>): string {
  return text.replace(/\{(\w+)\}/g, (m, key: string) => (key in vars ? String(vars[key as keyof TemplateVars] ?? "") : m));
}

export function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}

/** Minimal branded HTML wrapper for email clients. Body text is escaped. */
export function emailHtml(subject: string, body: string, clinicName: string): string {
  const paragraphs = escapeHtml(body)
    .split(/\n{2,}/)
    .map((p) => `<p style="margin:0 0 16px;line-height:1.6">${p.replace(/\n/g, "<br>")}</p>`)
    .join("");
  return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>${escapeHtml(subject)}</title></head>
<body style="margin:0;background:#F3EEEB;font-family:Helvetica,Arial,sans-serif;color:#382A35">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:32px 16px">
<table role="presentation" width="100%" style="max-width:560px;background:#FFFFFF;border:1px solid #E6DCD3">
<tr><td style="background:#4F3F4A;padding:22px 28px;color:#FFFFFF;font-size:18px;letter-spacing:.02em">${escapeHtml(clinicName)}</td></tr>
<tr><td style="height:3px;background:#DFCBAF"></td></tr>
<tr><td style="padding:28px;font-size:15px">${paragraphs}</td></tr>
</table></td></tr></table></body></html>`;
}
