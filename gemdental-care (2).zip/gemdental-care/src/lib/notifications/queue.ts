import "server-only";
import { and, eq, gt, inArray, lte, sql } from "drizzle-orm";
import { db, schema, type DB } from "@/lib/db";
import { env } from "@/lib/env";
import { getSettings, type ClinicSettings } from "@/lib/settings";
import { isLocale, pick, LOCALE_TAG, defaultLocale, type Locale } from "@/lib/i18n/config";
import { formatDate, formatTime } from "@/lib/time";
import { DEFAULT_TEMPLATES, emailHtml, renderTemplate, type Channel, type NotificationEvent, type TemplateVars } from "./templates";
import { channelProvider, deliver } from "./providers";

type Tx = Parameters<Parameters<DB["transaction"]>[0]>[0];
type Conn = DB | Tx;

const MAX_ATTEMPTS = 6;

async function loadAppointmentBundle(conn: Conn, appointmentId: string) {
  const rows = await conn
    .select({
      appointment: schema.appointments,
      patient: schema.patients,
      service: schema.services,
      doctor: schema.doctors,
    })
    .from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.patients.id, schema.appointments.patientId))
    .innerJoin(schema.services, eq(schema.services.id, schema.appointments.serviceId))
    .innerJoin(schema.doctors, eq(schema.doctors.id, schema.appointments.doctorId))
    .where(eq(schema.appointments.id, appointmentId));
  return rows[0] ?? null;
}

function contactLine(locale: Locale, phone: string | null) {
  if (!phone) return "";
  return locale === "sq" ? ` në ${phone}` : ` on ${phone}`;
}

export function buildVars(
  bundle: NonNullable<Awaited<ReturnType<typeof loadAppointmentBundle>>>,
  settings: ClinicSettings,
  locale: Locale,
): TemplateVars {
  const tag = LOCALE_TAG[locale];
  const tz = settings.timezone;
  const { appointment, patient, service, doctor } = bundle;
  return {
    firstName: patient.fullName.trim().split(/\s+/)[0] ?? patient.fullName,
    fullName: patient.fullName,
    service: pick(service.name, locale),
    doctor: doctor.fullName,
    date: formatDate(appointment.startsAt, tz, tag),
    time: formatTime(appointment.startsAt, tz, tag),
    reference: appointment.reference,
    clinicName: settings.clinicName,
    clinicPhone: settings.phone ?? "",
    contactLine: contactLine(locale, settings.phone),
    bookingUrl: `${env.siteUrl}/${locale}/booking`,
  };
}

async function templateFor(conn: Conn, event: NotificationEvent, channel: Channel, locale: Locale) {
  const override = await conn
    .select()
    .from(schema.notificationTemplates)
    .where(
      and(
        eq(schema.notificationTemplates.event, event),
        eq(schema.notificationTemplates.channel, channel),
        eq(schema.notificationTemplates.locale, locale),
      ),
    );
  if (override[0]) return { enabled: override[0].enabled, subject: override[0].subject, body: override[0].body };
  if (channel === "whatsapp") return { enabled: true, subject: null, body: "" };
  const d = DEFAULT_TEMPLATES[event][channel][locale];
  return { enabled: true, subject: d.subject ?? null, body: d.body };
}

/**
 * Write outbox rows for an appointment event. Call inside the same transaction
 * that changes the appointment (transactional outbox): if the change rolls back,
 * no message is queued. A unique dedupe key per logical message means running
 * this twice never produces two messages.
 */
export async function enqueueNotifications(
  conn: Conn,
  appointmentId: string,
  event: NotificationEvent,
  opts: { variant?: string; settings?: ClinicSettings } = {},
) {
  const bundle = await loadAppointmentBundle(conn, appointmentId);
  if (!bundle) return;
  const settings = opts.settings ?? (await getSettings());
  const locale: Locale = isLocale(bundle.appointment.locale) ? bundle.appointment.locale : defaultLocale();
  const vars = buildVars(bundle, settings, locale);
  const variant = opts.variant ?? "";

  const plan: { channel: Channel; recipient: string | null; consent: boolean }[] = [
    { channel: "email", recipient: bundle.patient.email, consent: true },
    { channel: "sms", recipient: bundle.patient.phone, consent: bundle.patient.consentSms },
    { channel: "whatsapp", recipient: bundle.patient.phone, consent: bundle.patient.consentWhatsapp },
  ];

  for (const item of plan) {
    if (!item.consent) continue; // no opt-in: nothing is sent and nothing is recorded
    const tpl = await templateFor(conn, event, item.channel, locale);
    const enabledInClinic = settings.channelsEnabled[item.channel];
    const provider = channelProvider(item.channel);
    let status: "queued" | "skipped" = "queued";
    let reason: string | null = null;
    if (!enabledInClinic) [status, reason] = ["skipped", "Channel turned off in clinic settings"];
    else if (!tpl.enabled) [status, reason] = ["skipped", "Template turned off"];
    else if (provider === "none") [status, reason] = ["skipped", "Provider not configured (pending integration)"];
    else if (!item.recipient) [status, reason] = ["skipped", "No recipient"];
    else if (item.channel === "whatsapp" && provider === "real" && !settings.whatsappTemplates[event])
      [status, reason] = ["skipped", "No approved WhatsApp template set for this event"];

    const subject = tpl.subject ? renderTemplate(tpl.subject, vars) : null;
    const body =
      item.channel === "whatsapp" && !tpl.body
        ? `[WhatsApp template "${settings.whatsappTemplates[event] ?? "not set"}"] ${vars.firstName}, ${vars.service}, ${vars.date}, ${vars.time}, ${vars.reference}`
        : renderTemplate(tpl.body, vars);

    await conn
      .insert(schema.notifications)
      .values({
        appointmentId,
        event,
        channel: item.channel,
        dedupeKey: `${appointmentId}:${event}:${item.channel}:${variant}`,
        recipient: item.recipient,
        locale,
        subject,
        body,
        status,
        lastError: reason,
      })
      .onConflictDoNothing({ target: schema.notifications.dedupeKey });
  }
}

/** Is a queued message still relevant at send time? (e.g. no reminder for a cancelled visit) */
function stillRelevant(event: NotificationEvent, status: string, startsAt: Date) {
  if (event === "reminder") return status === "confirmed" && startsAt.getTime() > Date.now();
  if (event === "confirmed" || event === "rescheduled") return status !== "cancelled";
  return true;
}

/**
 * Deliver queued messages. Safe to run concurrently from several processes:
 * rows are claimed with FOR UPDATE SKIP LOCKED and a short lease, so a message
 * is only ever handed to one worker at a time.
 */
export async function processNotificationQueue(opts: { limit?: number; appointmentId?: string } = {}) {
  const limit = opts.limit ?? 25;
  const claimed = await db().execute<{ id: string }>(sql`
    UPDATE notifications SET status = 'sending', locked_until = now() + interval '2 minutes',
      attempts = attempts + 1, updated_at = now()
    WHERE id IN (
      SELECT id FROM notifications
      WHERE ((status = 'queued' AND next_attempt_at <= now()) OR (status = 'sending' AND locked_until < now()))
      ${opts.appointmentId ? sql`AND appointment_id = ${opts.appointmentId}` : sql``}
      ORDER BY next_attempt_at
      LIMIT ${limit}
      FOR UPDATE SKIP LOCKED
    )
    RETURNING id
  `);
  const ids = claimed.rows.map((r) => r.id);
  if (!ids.length) return { processed: 0, sent: 0, failed: 0 };

  const settings = await getSettings();
  const rows = await db()
    .select({ n: schema.notifications, a: schema.appointments })
    .from(schema.notifications)
    .innerJoin(schema.appointments, eq(schema.appointments.id, schema.notifications.appointmentId))
    .where(inArray(schema.notifications.id, ids));

  let sent = 0;
  let failed = 0;
  for (const { n, a } of rows) {
    if (!stillRelevant(n.event, a.status, a.startsAt)) {
      await db()
        .update(schema.notifications)
        .set({ status: "skipped", lastError: "No longer relevant (appointment changed)", lockedUntil: null, updatedAt: new Date() })
        .where(eq(schema.notifications.id, n.id));
      continue;
    }
    const locale = isLocale(n.locale) ? n.locale : defaultLocale();
    let whatsapp: { template: string; language: string; params: string[] } | undefined;
    if (n.channel === "whatsapp") {
      const bundle = await loadAppointmentBundle(db(), a.id);
      const template = settings.whatsappTemplates[n.event];
      if (bundle && template) {
        const v = buildVars(bundle, settings, locale);
        whatsapp = { template, language: env.whatsapp.languageFor(locale), params: [v.firstName, v.service, v.date, v.time, v.reference] };
      }
    }
    const result = await deliver(n.channel, {
      to: n.recipient ?? "",
      subject: n.subject,
      body: n.body ?? "",
      html: n.channel === "email" ? emailHtml(n.subject ?? "", n.body ?? "", settings.clinicName) : undefined,
      idempotencyKey: n.dedupeKey,
      whatsapp,
    });
    if (result.kind === "sent" || result.kind === "logged") {
      sent++;
      await db()
        .update(schema.notifications)
        .set({
          status: result.kind,
          providerMessageId: result.kind === "sent" ? result.providerMessageId : null,
          sentAt: new Date(),
          lastError: null,
          lockedUntil: null,
          updatedAt: new Date(),
        })
        .where(eq(schema.notifications.id, n.id));
    } else {
      const giveUp = !result.retryable || n.attempts >= MAX_ATTEMPTS;
      if (giveUp) failed++;
      const backoffMin = Math.min(240, 2 ** n.attempts); // 2, 4, 8 … minutes
      await db()
        .update(schema.notifications)
        .set({
          status: giveUp ? "failed" : "queued",
          lastError: result.error.slice(0, 500),
          nextAttemptAt: new Date(Date.now() + backoffMin * 60_000),
          lockedUntil: null,
          updatedAt: new Date(),
        })
        .where(eq(schema.notifications.id, n.id));
    }
  }
  return { processed: rows.length, sent, failed };
}

/**
 * Queue reminders that are now due. Idempotent: each (appointment, rule,
 * start time) gets one dedupe key, so running the job every few minutes is safe.
 * A reminder is skipped when the confirmation itself went out within half of
 * the reminder's lead time (the patient was just told).
 */
export async function scheduleDueReminders(now = new Date()) {
  const settings = await getSettings();
  let queued = 0;
  for (const rule of settings.reminders.filter((r) => r.enabled && r.minutesBefore > 0)) {
    const windowEnd = new Date(now.getTime() + rule.minutesBefore * 60_000);
    const due = await db()
      .select({ id: schema.appointments.id, startsAt: schema.appointments.startsAt, confirmedAt: schema.appointments.confirmedAt })
      .from(schema.appointments)
      .where(
        and(
          eq(schema.appointments.status, "confirmed"),
          gt(schema.appointments.startsAt, now),
          lte(schema.appointments.startsAt, windowEnd),
        ),
      );
    for (const a of due) {
      const sendAt = a.startsAt.getTime() - rule.minutesBefore * 60_000;
      const confirmed = a.confirmedAt?.getTime() ?? 0;
      if (confirmed > sendAt + (rule.minutesBefore * 60_000) / 2) continue;
      await enqueueNotifications(db(), a.id, "reminder", { variant: `${rule.key}:${a.startsAt.toISOString()}`, settings });
      queued++;
    }
  }
  return { checked: queued };
}
