import "server-only";
import { env } from "@/lib/env";
import type { Channel } from "./templates";

export type SendInput = {
  to: string;
  subject?: string | null;
  body: string;
  html?: string;
  /** Stable key so providers that support it can drop duplicate submissions. */
  idempotencyKey: string;
  whatsapp?: { template: string; language: string; params: string[] };
};

export type SendResult =
  { kind: "sent"; providerMessageId: string | null } | { kind: "logged" } | { kind: "failed"; error: string; retryable: boolean };

/** Is a real (or development log) provider configured for this channel? */
export function channelProvider(channel: Channel): "real" | "log" | "none" {
  if (channel === "email") {
    const p = env.email.provider;
    if (p === "resend") return env.email.resendKey && env.email.from ? "real" : "none";
    return p === "log" ? "log" : "none";
  }
  if (channel === "sms") {
    const p = env.sms.provider;
    if (p === "twilio") return env.sms.sid && env.sms.token && (env.sms.from || env.sms.messagingServiceSid) ? "real" : "none";
    return p === "log" ? "log" : "none";
  }
  const p = env.whatsapp.provider;
  if (p === "meta") return env.whatsapp.phoneNumberId && env.whatsapp.token ? "real" : "none";
  return p === "log" ? "log" : "none";
}

function classifyHttp(status: number) {
  return status === 429 || status >= 500;
}

async function sendEmail(input: SendInput): Promise<SendResult> {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${env.email.resendKey}`,
      "Content-Type": "application/json",
      "Idempotency-Key": input.idempotencyKey,
    },
    body: JSON.stringify({
      from: env.email.from,
      to: [input.to],
      subject: input.subject ?? "",
      text: input.body,
      html: input.html,
      reply_to: env.email.replyTo || undefined,
    }),
    signal: AbortSignal.timeout(15_000),
  });
  const data = (await res.json().catch(() => ({}))) as { id?: string; message?: string };
  if (!res.ok) return { kind: "failed", error: `Resend ${res.status}: ${data.message ?? "error"}`, retryable: classifyHttp(res.status) };
  return { kind: "sent", providerMessageId: data.id ?? null };
}

async function sendSms(input: SendInput): Promise<SendResult> {
  const params = new URLSearchParams({ To: input.to, Body: input.body });
  if (env.sms.messagingServiceSid) params.set("MessagingServiceSid", env.sms.messagingServiceSid);
  else params.set("From", env.sms.from);
  const auth = Buffer.from(`${env.sms.sid}:${env.sms.token}`).toString("base64");
  const res = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${encodeURIComponent(env.sms.sid)}/Messages.json`, {
    method: "POST",
    headers: { Authorization: `Basic ${auth}`, "Content-Type": "application/x-www-form-urlencoded" },
    body: params,
    signal: AbortSignal.timeout(15_000),
  });
  const data = (await res.json().catch(() => ({}))) as { sid?: string; message?: string };
  if (!res.ok) return { kind: "failed", error: `Twilio ${res.status}: ${data.message ?? "error"}`, retryable: classifyHttp(res.status) };
  return { kind: "sent", providerMessageId: data.sid ?? null };
}

async function sendWhatsapp(input: SendInput): Promise<SendResult> {
  if (!input.whatsapp) return { kind: "failed", error: "No approved WhatsApp template configured", retryable: false };
  const res = await fetch(`https://graph.facebook.com/v21.0/${encodeURIComponent(env.whatsapp.phoneNumberId)}/messages`, {
    method: "POST",
    headers: { Authorization: `Bearer ${env.whatsapp.token}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      messaging_product: "whatsapp",
      to: input.to.replace(/^\+/, ""),
      type: "template",
      template: {
        name: input.whatsapp.template,
        language: { code: input.whatsapp.language },
        components: [{ type: "body", parameters: input.whatsapp.params.map((text) => ({ type: "text", text })) }],
      },
    }),
    signal: AbortSignal.timeout(15_000),
  });
  const data = (await res.json().catch(() => ({}))) as { messages?: { id: string }[]; error?: { message?: string } };
  if (!res.ok)
    return { kind: "failed", error: `WhatsApp ${res.status}: ${data.error?.message ?? "error"}`, retryable: classifyHttp(res.status) };
  // "Accepted" by Meta. Delivery/read receipts arrive later via webhook (see docs/INTEGRATIONS.md).
  return { kind: "sent", providerMessageId: data.messages?.[0]?.id ?? null };
}

export async function deliver(channel: Channel, input: SendInput): Promise<SendResult> {
  const mode = channelProvider(channel);
  if (mode === "none") return { kind: "failed", error: "Provider not configured", retryable: false };
  if (mode === "log") {
    console.info(
      `[notifications:log] ${channel} → ${maskRecipient(input.to)}\n  subject: ${input.subject ?? "-"}\n  ${input.body.replace(/\n/g, "\n  ")}`,
    );
    return { kind: "logged" };
  }
  try {
    if (channel === "email") return await sendEmail(input);
    if (channel === "sms") return await sendSms(input);
    return await sendWhatsapp(input);
  } catch (err) {
    return { kind: "failed", error: err instanceof Error ? err.message : "Network error", retryable: true };
  }
}

/** Keep logs free of full contact details. */
export function maskRecipient(to: string) {
  if (to.includes("@")) {
    const [u, d] = to.split("@");
    return `${u.slice(0, 2)}***@${d}`;
  }
  return `${to.slice(0, 4)}***${to.slice(-2)}`;
}
