/**
 * Timezone helpers built on the platform Intl API (no dependencies).
 *
 * All instants are stored in UTC (timestamptz). Clinic schedules are expressed
 * as wall-clock minutes in the clinic's IANA timezone, so we convert between the
 * two here. Correct across DST changes: wall times that do not exist on a
 * spring-forward day are reported as such and never offered as slots.
 */

const dtfCache = new Map<string, Intl.DateTimeFormat>();

function partsFormatter(tz: string) {
  let f = dtfCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", {
      timeZone: tz,
      hourCycle: "h23",
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      weekday: "short",
    });
    dtfCache.set(tz, f);
  }
  return f;
}

const WEEKDAYS: Record<string, number> = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

export type ZonedParts = {
  year: number;
  month: number; // 1–12
  day: number;
  hour: number;
  minute: number;
  second: number;
  weekday: number; // 0 = Sunday
};

export function zonedParts(instant: Date | number, tz: string): ZonedParts {
  const p: Record<string, string> = {};
  for (const part of partsFormatter(tz).formatToParts(new Date(instant))) p[part.type] = part.value;
  return {
    year: Number(p.year),
    month: Number(p.month),
    day: Number(p.day),
    hour: Number(p.hour),
    minute: Number(p.minute),
    second: Number(p.second),
    weekday: WEEKDAYS[p.weekday],
  };
}

/** Offset of `tz` from UTC at the given instant, in milliseconds. */
export function tzOffsetMs(instant: number, tz: string): number {
  const z = zonedParts(instant, tz);
  const asUtc = Date.UTC(z.year, z.month - 1, z.day, z.hour, z.minute, z.second);
  return asUtc - Math.floor(instant / 1000) * 1000;
}

/** "2026-10-08" for an instant, as seen in `tz`. */
export function zonedDateKey(instant: Date | number, tz: string): string {
  const z = zonedParts(instant, tz);
  return `${z.year}-${pad(z.month)}-${pad(z.day)}`;
}

/** Minutes after local midnight for an instant, as seen in `tz`. */
export function zonedMinutes(instant: Date | number, tz: string): number {
  const z = zonedParts(instant, tz);
  return z.hour * 60 + z.minute;
}

/**
 * Convert a wall-clock time in `tz` to a UTC instant.
 * Returns null when that wall time does not exist (DST gap).
 */
export function zonedToUtc(dateKey: string, minutesAfterMidnight: number, tz: string): Date | null {
  const { y, m, d } = parseDateKey(dateKey);
  const h = Math.floor(minutesAfterMidnight / 60);
  const mi = minutesAfterMidnight % 60;
  const naive = Date.UTC(y, m - 1, d, h, mi);
  let utc = naive - tzOffsetMs(naive, tz);
  const off2 = tzOffsetMs(utc, tz);
  utc = naive - off2;
  // Verify round-trip; a mismatch means the wall time is skipped by DST.
  const back = zonedParts(utc, tz);
  if (back.year !== y || back.month !== m || back.day !== d || back.hour !== h || back.minute !== mi) {
    return null;
  }
  return new Date(utc);
}

/** Start of the local day (00:00) in `tz`, as a UTC instant. */
export function startOfZonedDay(dateKey: string, tz: string): Date {
  // Midnight can be skipped by DST in a few zones; walk forward until valid.
  for (let m = 0; m < 180; m += 15) {
    const d = zonedToUtc(dateKey, m, tz);
    if (d) return d;
  }
  throw new Error(`Cannot resolve start of day ${dateKey} in ${tz}`);
}

export function parseDateKey(key: string): { y: number; m: number; d: number } {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (!match) throw new Error(`Invalid date key: ${key}`);
  return { y: Number(match[1]), m: Number(match[2]), d: Number(match[3]) };
}

export function isValidDateKey(key: string): boolean {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key);
  if (!m) return false;
  const dt = new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3])));
  return dt.getUTCFullYear() === Number(m[1]) && dt.getUTCMonth() === Number(m[2]) - 1 && dt.getUTCDate() === Number(m[3]);
}

/** Calendar arithmetic on date keys (timezone independent). */
export function addDays(key: string, days: number): string {
  const { y, m, d } = parseDateKey(key);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return `${dt.getUTCFullYear()}-${pad(dt.getUTCMonth() + 1)}-${pad(dt.getUTCDate())}`;
}

export function weekdayOf(key: string): number {
  const { y, m, d } = parseDateKey(key);
  return new Date(Date.UTC(y, m - 1, d)).getUTCDay();
}

export function daysInMonth(year: number, month: number): number {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}

export function compareDateKeys(a: string, b: string): number {
  return a < b ? -1 : a > b ? 1 : 0;
}

export function minutesToHHMM(min: number): string {
  return `${pad(Math.floor(min / 60))}:${pad(min % 60)}`;
}

export function hhmmToMinutes(v: string): number | null {
  const m = /^([01]\d|2[0-3]):([0-5]\d)$/.exec(v.trim());
  if (!m) return v.trim() === "24:00" ? 1440 : null;
  return Number(m[1]) * 60 + Number(m[2]);
}

function pad(n: number) {
  return String(n).padStart(2, "0");
}

/** Locale-aware formatting in the clinic timezone. */
export function formatDate(instant: Date, tz: string, localeTag: string, opts?: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat(localeTag, {
    timeZone: tz,
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric",
    ...opts,
  }).format(instant);
}

export function formatTime(instant: Date, tz: string, localeTag: string) {
  return new Intl.DateTimeFormat(localeTag, { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(instant);
}
