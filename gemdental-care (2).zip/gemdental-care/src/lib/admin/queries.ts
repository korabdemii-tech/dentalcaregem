import "server-only";
import { and, asc, count, desc, eq, gte, ilike, inArray, lt, or, gt, sql, type SQL } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { BLOCKING_STATUSES } from "@/lib/db/schema";
import { getSettings } from "@/lib/settings";
import { addDays, startOfZonedDay, zonedDateKey } from "@/lib/time";
import { getDaySlots } from "@/lib/booking/availability-service";

export type AppointmentRow = {
  id: string;
  reference: string;
  status: (typeof schema.appointmentStatus.enumValues)[number];
  startsAt: Date;
  endsAt: Date;
  source: string;
  patientName: string;
  patientPhone: string;
  serviceName: Record<string, string>;
  doctorId: string;
  doctorName: string;
};

const rowSelect = {
  id: schema.appointments.id,
  reference: schema.appointments.reference,
  status: schema.appointments.status,
  startsAt: schema.appointments.startsAt,
  endsAt: schema.appointments.endsAt,
  source: schema.appointments.source,
  patientName: schema.patients.fullName,
  patientPhone: schema.patients.phone,
  serviceName: schema.services.name,
  doctorId: schema.appointments.doctorId,
  doctorName: schema.doctors.fullName,
};

function baseQuery() {
  return db()
    .select(rowSelect)
    .from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.patients.id, schema.appointments.patientId))
    .innerJoin(schema.services, eq(schema.services.id, schema.appointments.serviceId))
    .innerJoin(schema.doctors, eq(schema.doctors.id, schema.appointments.doctorId));
}

export async function appointmentsInRange(from: Date, to: Date, doctorId?: string): Promise<AppointmentRow[]> {
  const where = [lt(schema.appointments.startsAt, to), gt(schema.appointments.endsAt, from)];
  if (doctorId) where.push(eq(schema.appointments.doctorId, doctorId));
  return (await baseQuery()
    .where(and(...where))
    .orderBy(asc(schema.appointments.startsAt))) as AppointmentRow[];
}

export async function listAppointments(f: {
  status?: string;
  q?: string;
  from?: Date;
  to?: Date;
  upcoming?: boolean;
  limit?: number;
  offset?: number;
}) {
  const where: SQL[] = [];
  const statuses = schema.appointmentStatus.enumValues as readonly string[];
  if (f.status && statuses.includes(f.status)) where.push(eq(schema.appointments.status, f.status as AppointmentRow["status"]));
  if (f.from) where.push(gte(schema.appointments.startsAt, f.from));
  if (f.to) where.push(lt(schema.appointments.startsAt, f.to));
  if (f.upcoming) where.push(gte(schema.appointments.startsAt, new Date()));
  if (f.q) {
    const q = `%${f.q.replace(/[%_\\]/g, (c) => `\\${c}`)}%`;
    where.push(
      or(
        ilike(schema.patients.fullName, q),
        ilike(schema.patients.email, q),
        ilike(schema.patients.phone, q),
        ilike(schema.appointments.reference, q),
      )!,
    );
  }
  const rows = (await baseQuery()
    .where(where.length ? and(...where) : undefined)
    .orderBy(f.upcoming ? asc(schema.appointments.startsAt) : desc(schema.appointments.startsAt))
    .limit(f.limit ?? 50)
    .offset(f.offset ?? 0)) as AppointmentRow[];
  return rows;
}

export async function appointmentDetail(id: string) {
  const rows = await db()
    .select({ a: schema.appointments, p: schema.patients, s: schema.services, d: schema.doctors })
    .from(schema.appointments)
    .innerJoin(schema.patients, eq(schema.patients.id, schema.appointments.patientId))
    .innerJoin(schema.services, eq(schema.services.id, schema.appointments.serviceId))
    .innerJoin(schema.doctors, eq(schema.doctors.id, schema.appointments.doctorId))
    .where(eq(schema.appointments.id, id));
  if (!rows[0]) return null;
  const [messages, history] = await Promise.all([
    db()
      .select()
      .from(schema.notifications)
      .where(eq(schema.notifications.appointmentId, id))
      .orderBy(desc(schema.notifications.createdAt)),
    db()
      .select()
      .from(schema.auditLogs)
      .where(and(eq(schema.auditLogs.entityType, "appointment"), eq(schema.auditLogs.entityId, id)))
      .orderBy(desc(schema.auditLogs.createdAt))
      .limit(50),
  ]);
  return { ...rows[0], messages, history };
}

export async function overviewStats() {
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = zonedDateKey(new Date(), tz);
  const dayStart = startOfZonedDay(today, tz);
  const dayEnd = startOfZonedDay(addDays(today, 1), tz);
  const weekEnd = startOfZonedDay(addDays(today, 8), tz);
  const now = new Date();
  const active = inArray(schema.appointments.status, [...BLOCKING_STATUSES]);

  const c = async (where: SQL | undefined) => (await db().select({ n: count() }).from(schema.appointments).where(where))[0].n;
  const [todayCount, upcoming, pending, confirmed, cancelled, failures] = await Promise.all([
    c(
      and(
        gte(schema.appointments.startsAt, dayStart),
        lt(schema.appointments.startsAt, dayEnd),
        sql`${schema.appointments.status} <> 'cancelled'`,
      ),
    ),
    c(and(active, gte(schema.appointments.startsAt, now), lt(schema.appointments.startsAt, weekEnd))),
    c(and(eq(schema.appointments.status, "pending"), gte(schema.appointments.startsAt, now))),
    c(and(eq(schema.appointments.status, "confirmed"), gte(schema.appointments.startsAt, now))),
    c(and(eq(schema.appointments.status, "cancelled"), gte(schema.appointments.cancelledAt, new Date(Date.now() - 30 * 86_400_000)))),
    db()
      .select({ n: count() })
      .from(schema.notifications)
      .where(and(eq(schema.notifications.status, "failed"), gte(schema.notifications.updatedAt, new Date(Date.now() - 14 * 86_400_000))))
      .then((r) => r[0].n),
  ]);

  // Open slots today, measured with the consultation (or first bookable) treatment.
  let openSlots: number | null = null;
  const svc =
    (
      await db()
        .select()
        .from(schema.services)
        .where(and(eq(schema.services.isConsultation, true), eq(schema.services.bookable, true)))
    )[0] ??
    (
      await db().select().from(schema.services).where(eq(schema.services.bookable, true)).orderBy(asc(schema.services.sortOrder)).limit(1)
    )[0];
  const doctors = await db().select({ id: schema.doctors.id }).from(schema.doctors).where(eq(schema.doctors.active, true));
  if (svc && doctors.length) {
    const slots = await getDaySlots({
      service: svc,
      doctorIds: doctors.map((d) => d.id),
      date: today,
      settings: { ...settings, minNoticeMinutes: 0 },
    });
    openSlots = slots.length;
  }

  const [pendingList, todayList] = await Promise.all([
    baseQuery()
      .where(and(eq(schema.appointments.status, "pending"), gte(schema.appointments.startsAt, now)))
      .orderBy(asc(schema.appointments.startsAt))
      .limit(8) as Promise<AppointmentRow[]>,
    baseQuery()
      .where(and(gte(schema.appointments.startsAt, dayStart), lt(schema.appointments.startsAt, dayEnd)))
      .orderBy(asc(schema.appointments.startsAt)) as Promise<AppointmentRow[]>,
  ]);

  return {
    settings,
    todayCount,
    upcoming,
    pending,
    confirmed,
    cancelled,
    failures,
    openSlots,
    pendingList,
    todayList,
    slotService: svc ?? null,
  };
}

export async function doctorsList() {
  return db().select().from(schema.doctors).orderBy(asc(schema.doctors.sortOrder), asc(schema.doctors.fullName));
}

export async function exceptionsInRange(from: Date, to: Date) {
  return db()
    .select()
    .from(schema.availabilityExceptions)
    .where(and(lt(schema.availabilityExceptions.startsAt, to), gt(schema.availabilityExceptions.endsAt, from)))
    .orderBy(asc(schema.availabilityExceptions.startsAt));
}
