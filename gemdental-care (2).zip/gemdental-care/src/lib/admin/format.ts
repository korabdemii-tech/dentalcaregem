export function dt(instant: Date, tz: string, tag: string, opts: Intl.DateTimeFormatOptions = {}) {
  return new Intl.DateTimeFormat(tag, { timeZone: tz, ...opts }).format(instant);
}
export const fmtDay = (d: Date, tz: string, tag: string) => dt(d, tz, tag, { weekday: "short", day: "numeric", month: "short" });
export const fmtTime = (d: Date, tz: string, tag: string) => dt(d, tz, tag, { hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
export const fmtDateTime = (d: Date, tz: string, tag: string) =>
  dt(d, tz, tag, {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  });
