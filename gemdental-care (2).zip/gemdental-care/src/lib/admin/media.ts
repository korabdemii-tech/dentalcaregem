import "server-only";
import sharp from "sharp";
import { db, schema } from "@/lib/db";

export const MAX_UPLOAD_BYTES = 8 * 1024 * 1024;
const ALLOWED = new Set(["jpeg", "png", "webp"]);

export type UploadResult = { ok: true; id: string } | { ok: false; reason: "type" | "size" | "empty" };

/**
 * Store an uploaded image. The file type is checked by decoding the image
 * itself (not the browser-supplied MIME type), EXIF metadata such as GPS is
 * stripped, the image is auto-rotated and resized to at most 2400 px, and
 * saved as WebP.
 */
export async function storeImageUpload(
  file: FormDataEntryValue | null,
  opts: { alt?: Record<string, string>; authentic?: boolean; label?: string } = {},
): Promise<UploadResult> {
  if (!file || typeof file === "string" || file.size === 0) return { ok: false, reason: "empty" };
  if (file.size > MAX_UPLOAD_BYTES) return { ok: false, reason: "size" };
  const input = Buffer.from(await file.arrayBuffer());
  let meta;
  try {
    meta = await sharp(input, { limitInputPixels: 50_000_000 }).metadata();
  } catch {
    return { ok: false, reason: "type" };
  }
  if (!meta.format || !ALLOWED.has(meta.format)) return { ok: false, reason: "type" };
  return { ok: true, id: await storeImageBuffer(input, opts) };
}

/** Normalise and store an image that is already known to be valid (used by uploads and the photo import). */
export async function storeImageBuffer(
  input: Buffer,
  opts: { alt?: Record<string, string>; authentic?: boolean; label?: string } = {},
): Promise<string> {
  const { data, info } = await sharp(input, { limitInputPixels: 50_000_000 })
    .rotate()
    .resize({ width: 2400, height: 2400, fit: "inside", withoutEnlargement: true })
    .webp({ quality: 82 })
    .toBuffer({ resolveWithObject: true });
  const [row] = await db()
    .insert(schema.media)
    .values({
      mime: "image/webp",
      bytes: data,
      width: info.width,
      height: info.height,
      sizeBytes: data.length,
      alt: opts.alt ?? {},
      authentic: opts.authentic ?? true,
      label: opts.label ?? null,
    })
    .returning({ id: schema.media.id });
  return row.id;
}
