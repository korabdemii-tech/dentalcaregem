import "server-only";
import { cookies } from "next/headers";
import adminEn, { type AdminDictionary } from "@/lib/i18n/dictionaries/admin-en";
import adminSq from "@/lib/i18n/dictionaries/admin-sq";
import { defaultLocale, isLocale, LOCALE_TAG, type Locale } from "@/lib/i18n/config";

export const ADMIN_LOCALE_COOKIE = "gd_admin_locale";

/** Dashboard language: explicit cookie, then the user's saved preference, then the launch language. */
export async function adminLocale(userLocale?: string | null): Promise<Locale> {
  const c = (await cookies()).get(ADMIN_LOCALE_COOKIE)?.value;
  if (isLocale(c)) return c;
  if (isLocale(userLocale)) return userLocale;
  return defaultLocale();
}

export async function getAdminDict(userLocale?: string | null): Promise<{ a: AdminDictionary; locale: Locale; tag: string }> {
  const locale = await adminLocale(userLocale);
  return { a: locale === "sq" ? adminSq : adminEn, locale, tag: LOCALE_TAG[locale] };
}

export type { AdminDictionary };
