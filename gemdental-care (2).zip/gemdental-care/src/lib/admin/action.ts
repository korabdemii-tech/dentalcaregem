import "server-only";
import { refresh } from "next/cache";
import { unstable_rethrow } from "next/navigation";
import { requireUser, type AdminUser } from "@/lib/auth/session";
import { can, type Permission } from "@/lib/auth/permissions";
import { getAdminDict, type AdminDictionary } from "./i18n";

export type ActionState = {
  ok?: boolean;
  message?: string;
  errors?: Record<string, string | undefined>;
  /** Changes on every submit so the UI can re-announce identical messages. */
  at?: number;
  data?: Record<string, unknown>;
};

/**
 * Wrap a dashboard server action: authenticates against the database,
 * checks the role permission on the server, translates messages, refreshes the
 * page on success, and never leaks internal errors to the browser.
 */
export function adminAction(
  permission: Permission,
  fn: (ctx: { user: AdminUser; a: AdminDictionary; form: FormData }) => Promise<ActionState | void>,
) {
  return async (_prev: ActionState, form: FormData): Promise<ActionState> => {
    const user = await requireUser();
    const { a } = await getAdminDict(user.locale);
    if (!can(user.role, permission)) return { ok: false, message: a.common.permissionDenied, at: Date.now() };
    try {
      const res = (await fn({ user, a, form })) ?? { ok: true, message: a.common.saved };
      if (res.ok !== false) refresh();
      return { ...res, at: Date.now() };
    } catch (err) {
      unstable_rethrow(err); // let redirect()/forbidden() through
      console.error("[admin action]", err instanceof Error ? err.message : err);
      return { ok: false, message: a.common.serverError, at: Date.now() };
    }
  };
}

export function str(form: FormData, key: string, max = 5000): string {
  const v = form.get(key);
  return typeof v === "string" ? v.trim().slice(0, max) : "";
}
export function bool(form: FormData, key: string): boolean {
  const v = form.get(key);
  return v === "on" || v === "true" || v === "1";
}
export function int(form: FormData, key: string, min: number, max: number): number | null {
  const n = Number(str(form, key));
  return Number.isInteger(n) && n >= min && n <= max ? n : null;
}
export function lines(form: FormData, key: string): string[] {
  return str(form, key, 8000)
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean)
    .slice(0, 40);
}
export const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
