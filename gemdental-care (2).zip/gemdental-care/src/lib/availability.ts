/**
 * Pure availability engine. No I/O: give it the schedule, the busy times and
 * "now", and it returns the bookable start times. The same function is used to
 * show slots to patients and to re-validate a slot inside the booking
 * transaction, so what the patient sees and what the server accepts cannot
 * drift apart.
 */
import { addDays, compareDateKeys, weekdayOf, zonedDateKey, zonedToUtc } from "./time";

export type Interval = { start: Date; end: Date };

export type WorkingBlock = { weekday: number; startMinute: number; endMinute: number };

export type AvailabilityInput = {
  /** Local calendar day in the clinic timezone, "YYYY-MM-DD". */
  date: string;
  timezone: string;
  /** Doctor's weekly pattern (all weekdays; filtered here). */
  workingHours: WorkingBlock[];
  /** Length of the treatment itself. */
  durationMinutes: number;
  /** Clean-up / preparation time after the treatment that also blocks the chair. */
  bufferMinutes: number;
  /** Grid on which start times are offered (e.g. every 15 minutes). */
  slotIntervalMinutes: number;
  /** Existing active appointments for the doctor: [startsAt, blockedUntil). */
  busy: Interval[];
  /** Holidays, time off, clinic closures and manual blocks. */
  exceptions: Interval[];
  now: Date;
  minNoticeMinutes: number;
  horizonDays: number;
};

export type Slot = { start: Date; end: Date; blockedUntil: Date };

function overlaps(aStart: number, aEnd: number, b: Interval) {
  return aStart < b.end.getTime() && b.start.getTime() < aEnd;
}

/** Is `date` inside the bookable window (today … today + horizon) in the clinic timezone? */
export function isWithinHorizon(date: string, now: Date, tz: string, horizonDays: number): boolean {
  const today = zonedDateKey(now, tz);
  const last = addDays(today, horizonDays);
  return compareDateKeys(date, today) >= 0 && compareDateKeys(date, last) <= 0;
}

export function computeSlots(input: AvailabilityInput): Slot[] {
  const { date, timezone, durationMinutes, bufferMinutes, slotIntervalMinutes, busy, exceptions, now, minNoticeMinutes, horizonDays } =
    input;

  if (durationMinutes <= 0 || slotIntervalMinutes <= 0) return [];
  if (!isWithinHorizon(date, now, timezone, horizonDays)) return [];

  const weekday = weekdayOf(date);
  const blocks = input.workingHours
    .filter((w) => w.weekday === weekday && w.endMinute > w.startMinute)
    .sort((a, b) => a.startMinute - b.startMinute);

  const earliest = now.getTime() + minNoticeMinutes * 60_000;
  const durMs = durationMinutes * 60_000;
  const bufMs = bufferMinutes * 60_000;
  const seen = new Set<number>();
  const slots: Slot[] = [];

  for (const block of blocks) {
    // Align the first start to the slot grid measured from midnight.
    const first = Math.ceil(block.startMinute / slotIntervalMinutes) * slotIntervalMinutes;
    for (let m = first; m + durationMinutes <= block.endMinute; m += slotIntervalMinutes) {
      const start = zonedToUtc(date, m, timezone);
      if (!start) continue; // DST gap
      const s = start.getTime();
      const e = s + durMs;
      // The appointment itself must end inside working time (wall-clock check
      // above) and must not straddle a DST change in an unexpected way.
      const endWall = zonedToUtc(date, m + durationMinutes, timezone);
      if (!endWall || endWall.getTime() !== e) continue;
      if (s < earliest) continue;
      const blockedUntil = e + bufMs;
      if (busy.some((b) => overlaps(s, blockedUntil, b))) continue;
      if (exceptions.some((x) => overlaps(s, e, x))) continue;
      if (seen.has(s)) continue;
      seen.add(s);
      slots.push({ start: new Date(s), end: new Date(e), blockedUntil: new Date(blockedUntil) });
    }
  }
  return slots.sort((a, b) => a.start.getTime() - b.start.getTime());
}

/** Date keys of every day in a month, "YYYY-MM-01" … */
export function monthDays(year: number, month: number): string[] {
  const out: string[] = [];
  const first = `${year}-${String(month).padStart(2, "0")}-01`;
  for (let i = 0; i < 31; i++) {
    const k = addDays(first, i);
    if (Number(k.slice(5, 7)) !== month) break;
    out.push(k);
  }
  return out;
}
