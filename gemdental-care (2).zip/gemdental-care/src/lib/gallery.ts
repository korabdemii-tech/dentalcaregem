import "server-only";
import { cache } from "react";
import { getMediaMeta, getPublishedCases, getPublishedGallery, mediaUrl } from "@/lib/content";
import { pick, type Locale } from "@/lib/i18n/config";
import type { ResultConcern } from "@/lib/db/schema";
import type { CaseItem, GalleryStrings, PhotoItem } from "@/components/gallery/types";
import type { PublicDictionary } from "@/lib/i18n/dictionaries/en";

/**
 * Everything the public results gallery needs, resolved for one language:
 * only published cases/photos with a consent record, and only images that exist.
 */
export const getGalleryData = cache(async (locale: Locale) => {
  const [cases, photos] = await Promise.all([getPublishedCases(), getPublishedGallery()]);
  const meta = await getMediaMeta([...cases.flatMap((c) => [c.beforeMediaId, c.afterMediaId]), ...photos.map((p) => p.mediaId)]);
  const img = (id: string | null) => {
    const m = id ? meta.get(id) : undefined;
    return m && id ? { src: mediaUrl(id)!, width: m.width, height: m.height, alt: pick(m.alt, locale) } : null;
  };

  const caseItems: CaseItem[] = [];
  for (const c of cases) {
    const before = img(c.beforeMediaId);
    const after = img(c.afterMediaId);
    if (!before || !after) continue;
    caseItems.push({
      id: c.id,
      title: pick(c.title, locale),
      description: pick(c.description, locale),
      concern: (c.concern as ResultConcern | null) ?? null,
      before,
      after,
    });
  }

  const toPhoto = (p: (typeof photos)[number]): PhotoItem | null => {
    const image = img(p.mediaId);
    return image ? { id: p.id, caption: pick(p.caption, locale), image } : null;
  };
  const smiles = photos
    .filter((p) => p.kind === "smile")
    .map(toPhoto)
    .filter((p): p is PhotoItem => !!p);
  const gems = photos
    .filter((p) => p.kind === "gems")
    .map(toPhoto)
    .filter((p): p is PhotoItem => !!p);

  return { cases: caseItems, smiles, gems, hasAny: caseItems.length + smiles.length + gems.length > 0 };
});

/** Interface strings for the gallery components, from the public dictionary. */
export function galleryStrings(r: PublicDictionary["results"]): GalleryStrings {
  return {
    before: r.before,
    after: r.after,
    dragHint: r.dragHint,
    all: r.all,
    filterLabel: r.filterLabel,
    concerns: r.concerns,
    openFull: r.openFull,
    close: r.close,
    prev: r.prev,
    next: r.next,
    counter: r.counter,
    compareLabel: r.compareLabel,
    magnifyHint: r.magnifyHint,
    viewer: r.viewer,
  };
}
