import "server-only";
import { and, eq, inArray, sql } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { audit } from "@/lib/audit";

/**
 * Irreversibly remove a patient's personal data while keeping anonymous
 * appointment statistics (date, treatment, status). Used for erasure requests
 * and by the retention job.
 */
export async function anonymisePatient(patientId: string, actor: { id: string | null; label: string }) {
  await db().transaction(async (tx) => {
    await tx
      .update(schema.patients)
      .set({
        fullName: "Anonymised patient",
        email: `erased+${patientId.slice(0, 8)}@invalid.example`,
        phone: "+000",
        consentSms: false,
        consentWhatsapp: false,
        isReturning: null,
        updatedAt: new Date(),
      })
      .where(eq(schema.patients.id, patientId));
    const appts = await tx
      .select({ id: schema.appointments.id })
      .from(schema.appointments)
      .where(eq(schema.appointments.patientId, patientId));
    const ids = appts.map((x) => x.id);
    if (ids.length) {
      await tx
        .update(schema.appointments)
        .set({ patientNote: null, adminNotes: null, cancelReason: null })
        .where(inArray(schema.appointments.id, ids));
      await tx
        .update(schema.notifications)
        .set({ recipient: null, subject: null, body: null })
        .where(inArray(schema.notifications.appointmentId, ids));
    }
    await audit(
      { actorId: actor.id, actorLabel: actor.label, action: "patient.anonymised", entityType: "patient", entityId: patientId },
      tx,
    );
  });
}

/** Anonymise patients with no appointment newer than the retention period. */
export async function runRetention(months: number) {
  const rows = await db().execute<{ id: string }>(sql`
    SELECT p.id FROM patients p
    WHERE p.full_name <> 'Anonymised patient'
      AND NOT EXISTS (
        SELECT 1 FROM appointments a
        WHERE a.patient_id = p.id AND a.ends_at > now() - make_interval(months => ${months})
      )
      AND p.created_at < now() - make_interval(months => ${months})
    LIMIT 500
  `);
  for (const r of rows.rows) await anonymisePatient(r.id, { id: null, label: "system (retention)" });
  // Delivered message bodies are no longer needed after 90 days.
  await db()
    .update(schema.notifications)
    .set({ body: null, subject: null })
    .where(
      and(
        sql`${schema.notifications.createdAt} < now() - interval '90 days'`,
        inArray(schema.notifications.status, ["sent", "logged", "skipped", "failed"]),
      ),
    );
  return { anonymised: rows.rows.length };
}
