import { parsePhoneNumberFromString } from "libphonenumber-js/min";
import type { ClinicSettings } from "@/lib/settings";
import { pick, type Locale } from "@/lib/i18n/config";

export type HoursLine = { days: string; hours: string | null };

/** Group consecutive days with identical hours: "Monday – Friday 09:00–18:00". Week starts Monday. */
export function openingHoursLines(settings: ClinicSettings, dayNames: string[], closedLabel: string): HoursLine[] {
  const rows = settings.openingHours;
  if (!rows?.length) return [];
  const order = [1, 2, 3, 4, 5, 6, 0];
  const byDay = new Map(rows.map((r) => [r.day, "closed" in r ? null : `${r.open}–${r.close}`]));
  const lines: HoursLine[] = [];
  let i = 0;
  while (i < order.length) {
    const value = byDay.has(order[i]) ? byDay.get(order[i])! : null;
    let j = i;
    while (j + 1 < order.length && (byDay.has(order[j + 1]) ? byDay.get(order[j + 1])! : null) === value) j++;
    const label = i === j ? dayNames[order[i]] : `${dayNames[order[i]]} – ${dayNames[order[j]]}`;
    lines.push({ days: label, hours: value ?? closedLabel });
    i = j + 1;
  }
  return lines;
}

export function telHref(phone: string) {
  return `tel:${phone.replace(/[^\d+]/g, "")}`;
}
export function whatsappHref(phone: string) {
  return `https://wa.me/${phone.replace(/\D/g, "")}`;
}
export function directionsHref(settings: ClinicSettings, locale: Locale) {
  if (settings.mapsUrl) return settings.mapsUrl;
  if (settings.latitude && settings.longitude)
    return `https://www.google.com/maps/dir/?api=1&destination=${settings.latitude},${settings.longitude}`;
  const addr = fullAddress(settings, locale);
  return addr ? `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(addr)}` : null;
}
export function fullAddress(settings: ClinicSettings, locale: Locale) {
  const line = pick(settings.addressLine, locale);
  if (!line) return "";
  return [line, [settings.postalCode, settings.city].filter(Boolean).join(" ")].filter(Boolean).join(", ");
}
/** E.164 → international display format, e.g. +383 44 123 456. */
export function formatPhoneDisplay(phone: string) {
  return parsePhoneNumberFromString(phone)?.formatInternational() ?? phone;
}
