/**
 * Locale-independent date formatting for the browser.
 *
 * Some browsers ship without Albanian date data (for example Chromium builds
 * with reduced ICU, including some Android versions), so names come from our
 * dictionaries and Intl is only used for numeric parts in the clinic timezone,
 * which every browser supports.
 */
export type DateNames = {
  months: string[]; // January … December
  weekdays: string[]; // Sunday … Saturday
  weekdaysShort: string[]; // Sunday … Saturday
  /** Placeholders: {weekday} {day} {month} {year} */
  full: string;
  dayMonth: string;
  monthYear: string;
};

const fmtCache = new Map<string, Intl.DateTimeFormat>();
function numericParts(instant: Date, tz: string) {
  let f = fmtCache.get(tz);
  if (!f) {
    f = new Intl.DateTimeFormat("en-US", { timeZone: tz, year: "numeric", month: "numeric", day: "numeric", weekday: "short" });
    fmtCache.set(tz, f);
  }
  const p = Object.fromEntries(f.formatToParts(instant).map((x) => [x.type, x.value]));
  const wd = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(p.weekday);
  return { y: Number(p.year), m: Number(p.month), d: Number(p.day), wd };
}

function fill(pattern: string, names: DateNames, y: number, m: number, d: number, wd: number) {
  return pattern
    .replace("{weekday}", names.weekdays[wd])
    .replace("{day}", String(d))
    .replace("{month}", names.months[m - 1])
    .replace("{year}", String(y));
}

/** "Friday 9 October 2026" for an instant, in the clinic timezone. */
export function formatInstant(
  instant: Date | string,
  tz: string,
  names: DateNames,
  pattern: keyof Pick<DateNames, "full" | "dayMonth"> = "full",
) {
  const { y, m, d, wd } = numericParts(new Date(instant), tz);
  return fill(names[pattern], names, y, m, d, wd);
}

/** Same, for a calendar date key "YYYY-MM-DD" (no timezone involved). */
export function formatDateKey(key: string, names: DateNames, pattern: keyof Pick<DateNames, "full" | "dayMonth"> = "dayMonth") {
  const [y, m, d] = key.split("-").map(Number);
  const wd = new Date(Date.UTC(y, m - 1, d)).getUTCDay();
  return fill(names[pattern], names, y, m, d, wd);
}

export function formatMonthYear(year: number, month: number, names: DateNames) {
  return names.monthYear.replace("{month}", names.months[month - 1]).replace("{year}", String(year));
}

/** 24-hour time "14:30" in the clinic timezone (numeric only, works everywhere). */
export function formatClock(instant: Date | string, tz: string) {
  return new Intl.DateTimeFormat("en-GB", { timeZone: tz, hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(new Date(instant));
}

/** Capitalise the first letter when a date stands on its own ("e premte" → "E premte"). */
export function capFirst(s: string) {
  return s ? s[0].toLocaleUpperCase() + s.slice(1) : s;
}
