import "server-only";
import { notFound } from "next/navigation";
import en from "./dictionaries/en";
import sq from "./dictionaries/sq";
import { enabledLocales, isLocale, type Locale } from "./config";
import type { PublicDictionary } from "./dictionaries/en";

const DICTS: Record<Locale, PublicDictionary> = { en, sq };

export function getDictionary(locale: Locale): PublicDictionary {
  return DICTS[locale];
}

/** Validate a [locale] route param; 404 for unknown or disabled languages. */
export function resolveLocale(param: string): Locale {
  if (!isLocale(param) || !enabledLocales().includes(param)) notFound();
  return param;
}

export type { PublicDictionary };
