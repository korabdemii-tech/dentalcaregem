export const SUPPORTED_LOCALES = ["sq", "en"] as const;
export type Locale = (typeof SUPPORTED_LOCALES)[number];

export function isLocale(v: unknown): v is Locale {
  return typeof v === "string" && (SUPPORTED_LOCALES as readonly string[]).includes(v);
}

/** Enabled locales, in priority order. The first one is the launch language. */
export function enabledLocales(): Locale[] {
  const raw = (process.env.LOCALES ?? "sq,en").split(",").map((s) => s.trim());
  const list = raw.filter(isLocale);
  return list.length ? list : ["sq", "en"];
}

export function defaultLocale(): Locale {
  return enabledLocales()[0];
}

/** BCP-47 tags used for Intl formatting and hreflang. */
export const LOCALE_TAG: Record<Locale, string> = {
  sq: "sq-AL",
  en: "en-GB",
};

export const LOCALE_LABEL: Record<Locale, string> = {
  sq: "Shqip",
  en: "English",
};

/** A piece of content stored in more than one language. */
export type Localized = Partial<Record<Locale, string>>;

/** Pick the best translation, falling back to the launch language, then any. */
export function pick(value: Localized | null | undefined, locale: Locale): string {
  if (!value) return "";
  return value[locale] || value[defaultLocale()] || Object.values(value).find(Boolean) || "";
}

export function pickList(value: Partial<Record<Locale, string[]>> | null | undefined, locale: Locale): string[] {
  if (!value) return [];
  const v = value[locale]?.length ? value[locale] : value[defaultLocale()];
  return (v ?? []).filter(Boolean);
}
