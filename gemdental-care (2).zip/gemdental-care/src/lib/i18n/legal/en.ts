/**
 * DRAFT legal copy. Placeholders in {braces} are filled from clinic settings.
 * Must be reviewed by the clinic (and ideally a lawyer) for its jurisdiction.
 */
export type LegalDoc = { sections: { title: string; body: string[] }[] };

export const privacyEn: LegalDoc = {
  sections: [
    {
      title: "Who we are",
      body: [
        'This website is operated by {entity} ("GemDental Care", "we"). For any question about your personal data, contact us at {privacyEmail}.',
      ],
    },
    {
      title: "What we collect",
      body: [
        "When you book an appointment we collect your name, phone number, email address, the treatment and time you choose, whether you have visited before, and any note you add.",
        "We do not ask for medical history through this website. Please do not include detailed health information in the note field.",
        "If you opt in, we also record your consent to receive appointment messages by SMS or WhatsApp, and when you gave it.",
        "For security, our servers process technical data such as your IP address to prevent abuse. We store it only in a one-way, pseudonymised form for rate limiting.",
      ],
    },
    {
      title: "Why we use it",
      body: [
        "To arrange, confirm, remind you of and manage your appointment, and to contact you about it. The basis for this is taking steps at your request before providing care, and your consent where you opt in to SMS or WhatsApp messages.",
      ],
    },
    {
      title: "Who we share it with",
      body: [
        "Only with service providers that help us run the booking system on our behalf, such as our hosting provider and the providers that deliver email, SMS or WhatsApp messages. They may only use your data to provide that service. We do not sell your data or use it for advertising.",
        "[Clinic to list providers and their locations, e.g. hosting region, email provider.]",
      ],
    },
    {
      title: "How long we keep it",
      body: [
        "Booking records are kept for {retention} months after your last appointment, unless the law requires us to keep them longer, after which they are deleted or anonymised.",
      ],
    },
    {
      title: "Your rights",
      body: [
        "Depending on the law that applies, you may ask to access, correct or delete your data, to restrict or object to its use, and to withdraw consent for SMS or WhatsApp messages at any time. Contact {privacyEmail}. You may also complain to the data protection authority in your country.",
      ],
    },
    {
      title: "Cookies",
      body: [
        "This website uses only strictly necessary cookies: one remembers your language choice, and staff sign-in uses a security cookie. We do not use analytics or advertising cookies.",
      ],
    },
  ],
};

export const termsEn: LegalDoc = {
  sections: [
    {
      title: "Booking through this website",
      body: [
        "When you book online you choose a treatment and a time that is shown as available. Depending on the clinic's settings, your booking is either confirmed straight away or sent as a request for the clinic to approve. The final booking screen and the messages you receive always say which applies.",
        "A request is not a confirmed appointment until you receive confirmation.",
      ],
    },
    {
      title: "Changes and cancellations",
      body: [
        "[Clinic to confirm: how patients can change or cancel, the notice period, and any fee for late cancellation or missed appointments.]",
      ],
    },
    {
      title: "Treatments and prices",
      body: [
        "Treatment descriptions on this website are general information. The right treatment for you is decided by the dentist after an examination. Prices, where shown, are indicative and are confirmed before treatment begins.",
      ],
    },
    {
      title: "Emergencies",
      body: [
        "Online booking is not suitable for medical emergencies. If you have difficulty breathing or swallowing, or swelling that spreads quickly, contact emergency services.",
      ],
    },
    {
      title: "Contact",
      body: ["{entity}. Questions about these conditions: {privacyEmail}."],
    },
  ],
};
