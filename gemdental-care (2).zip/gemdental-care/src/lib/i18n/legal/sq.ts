/** VERSION PARAPRAK. Rishikoni me klinikën dhe një jurist para publikimit. */
import type { LegalDoc } from "./en";

export const privacySq: LegalDoc = {
  sections: [
    {
      title: "Kush jemi",
      body: [
        'Kjo faqe menaxhohet nga {entity} ("GemDental Care", "ne"). Për çdo pyetje rreth të dhënave tuaja personale, na shkruani në {privacyEmail}.',
      ],
    },
    {
      title: "Çfarë mbledhim",
      body: [
        "Kur rezervoni një termin, mbledhim emrin, numrin e telefonit, adresën e emailit, trajtimin dhe orarin që zgjidhni, nëse na keni vizituar më parë dhe çdo shënim që shtoni.",
        "Përmes kësaj faqeje nuk kërkojmë historinë mjekësore. Ju lutemi mos shkruani informacione të detajuara shëndetësore te fusha e shënimit.",
        "Nëse pranoni, regjistrojmë edhe pëlqimin tuaj për të marrë mesazhe për terminin me SMS ose WhatsApp, si dhe kohën kur e keni dhënë.",
        "Për siguri, serverët tanë përpunojnë të dhëna teknike si adresa IP për të parandaluar abuzimet. E ruajmë vetëm në formë të pseudonimizuar dhe të pakthyeshme për kufizimin e kërkesave.",
      ],
    },
    {
      title: "Pse i përdorim",
      body: [
        "Për të caktuar, konfirmuar, kujtuar dhe menaxhuar terminin tuaj dhe për t'ju kontaktuar rreth tij. Baza për këtë është ndërmarrja e hapave me kërkesën tuaj para ofrimit të kujdesit, si dhe pëlqimi juaj kur zgjidhni mesazhet me SMS ose WhatsApp.",
      ],
    },
    {
      title: "Me kë i ndajmë",
      body: [
        "Vetëm me ofruesit e shërbimeve që na ndihmojnë të mbajmë sistemin e rezervimeve në emrin tonë, si ofruesi i hostingut dhe ofruesit që dërgojnë email, SMS ose mesazhe WhatsApp. Ata mund t'i përdorin të dhënat vetëm për të ofruar atë shërbim. Ne nuk i shesim të dhënat tuaja dhe nuk i përdorim për reklama.",
        "[Klinika duhet të rendisë ofruesit dhe vendndodhjen e tyre, p.sh. rajonin e hostingut, ofruesin e emailit.]",
      ],
    },
    {
      title: "Sa kohë i ruajmë",
      body: [
        "Të dhënat e rezervimeve ruhen për {retention} muaj pas terminit tuaj të fundit, përveç kur ligji kërkon ruajtje më të gjatë, dhe më pas fshihen ose anonimizohen.",
      ],
    },
    {
      title: "Të drejtat tuaja",
      body: [
        "Në varësi të ligjit që zbatohet, mund të kërkoni qasje, korrigjim ose fshirje të të dhënave, kufizimin ose kundërshtimin e përdorimit të tyre dhe të tërhiqni në çdo kohë pëlqimin për mesazhet me SMS ose WhatsApp. Na shkruani në {privacyEmail}. Mund të ankoheni edhe te autoriteti për mbrojtjen e të dhënave në shtetin tuaj.",
      ],
    },
    {
      title: "Cookies",
      body: [
        "Kjo faqe përdor vetëm cookies të domosdoshme: njëra mban mend gjuhën që keni zgjedhur, ndërsa hyrja e stafit përdor një cookie sigurie. Nuk përdorim cookies analitike apo reklamuese.",
      ],
    },
  ],
};

export const termsSq: LegalDoc = {
  sections: [
    {
      title: "Rezervimi përmes kësaj faqeje",
      body: [
        "Kur rezervoni online, zgjidhni një trajtim dhe një orar që shfaqet i lirë. Sipas cilësimeve të klinikës, rezervimi juaj ose konfirmohet menjëherë, ose dërgohet si kërkesë që klinika ta miratojë. Ekrani i fundit i rezervimit dhe mesazhet që merrni tregojnë gjithmonë se cili rast vlen.",
        "Kërkesa nuk është termin i konfirmuar derisa të merrni konfirmimin.",
      ],
    },
    {
      title: "Ndryshimet dhe anulimet",
      body: [
        "[Klinika duhet të konfirmojë: si mund ta ndryshojnë ose anulojnë pacientët terminin, afatin e njoftimit dhe çdo tarifë për anulim të vonë ose mosparaqitje.]",
      ],
    },
    {
      title: "Trajtimet dhe çmimet",
      body: [
        "Përshkrimet e trajtimeve në këtë faqe janë informacion i përgjithshëm. Trajtimin e duhur për ju e vendos dentisti pas kontrollit. Çmimet, kur shfaqen, janë orientuese dhe konfirmohen para fillimit të trajtimit.",
      ],
    },
    {
      title: "Urgjencat",
      body: [
        "Rezervimi online nuk është i përshtatshëm për urgjenca mjekësore. Nëse keni vështirësi në frymëmarrje ose gëlltitje, ose ënjtje që përhapet shpejt, kontaktoni shërbimin e urgjencës.",
      ],
    },
    {
      title: "Kontakti",
      body: ["{entity}. Pyetje rreth këtyre kushteve: {privacyEmail}."],
    },
  ],
};
