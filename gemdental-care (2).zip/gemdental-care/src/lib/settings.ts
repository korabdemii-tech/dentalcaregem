import "server-only";
import { cache } from "react";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";

export type ClinicSettings = typeof schema.clinicSettings.$inferSelect;

/** Clinic settings singleton (row id = 1), created with safe defaults on first use. */
export const getSettings = cache(async (): Promise<ClinicSettings> => {
  const rows = await db().select().from(schema.clinicSettings).where(eq(schema.clinicSettings.id, 1));
  if (rows[0]) return rows[0];
  const inserted = await db().insert(schema.clinicSettings).values({ id: 1 }).onConflictDoNothing().returning();
  if (inserted[0]) return inserted[0];
  const again = await db().select().from(schema.clinicSettings).where(eq(schema.clinicSettings.id, 1));
  return again[0];
});
