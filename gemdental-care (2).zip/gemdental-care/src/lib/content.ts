import "server-only";
import { cache } from "react";
import { and, asc, eq, inArray } from "drizzle-orm";
import { db, schema } from "@/lib/db";

export type Service = typeof schema.services.$inferSelect;
export type Doctor = typeof schema.doctors.$inferSelect;

export function mediaUrl(id: string | null | undefined): string | null {
  return id ? `/media/${id}` : null;
}

export const getPublishedServices = cache(async () =>
  db().select().from(schema.services).where(eq(schema.services.published, true)).orderBy(asc(schema.services.sortOrder)),
);

export const getServiceBySlug = cache(async (slug: string) => {
  const rows = await db()
    .select()
    .from(schema.services)
    .where(and(eq(schema.services.slug, slug), eq(schema.services.published, true)));
  return rows[0] ?? null;
});

export const getPublishedDoctors = cache(async () =>
  db().select().from(schema.doctors).where(eq(schema.doctors.published, true)).orderBy(asc(schema.doctors.sortOrder)),
);

export const getDoctorsForService = cache(async (serviceId: string) => {
  const assigned = await db()
    .select({ id: schema.doctorServices.doctorId })
    .from(schema.doctorServices)
    .where(eq(schema.doctorServices.serviceId, serviceId));
  const all = await getPublishedDoctors();
  if (!assigned.length) return all.filter((d) => d.active);
  const ids = new Set(assigned.map((a) => a.id));
  return all.filter((d) => d.active && ids.has(d.id));
});

export const getPublishedFaqs = cache(async () =>
  db()
    .select()
    .from(schema.faqs)
    .where(and(eq(schema.faqs.published, true), eq(schema.faqs.verified, true)))
    .orderBy(asc(schema.faqs.sortOrder)),
);

export const getPublishedTestimonials = cache(async () =>
  db()
    .select()
    .from(schema.testimonials)
    .where(and(eq(schema.testimonials.published, true), eq(schema.testimonials.verified, true)))
    .orderBy(asc(schema.testimonials.sortOrder)),
);

export const getPublishedCases = cache(async () =>
  db()
    .select()
    .from(schema.resultCases)
    .where(and(eq(schema.resultCases.published, true), eq(schema.resultCases.consentObtained, true)))
    .orderBy(asc(schema.resultCases.sortOrder)),
);

export const SITE_IMAGE_SLOTS = ["about", "about-secondary", "contact"] as const;
export type SiteImageSlot = (typeof SITE_IMAGE_SLOTS)[number];

export type SiteImage = { url: string; width: number; height: number; alt: Record<string, string>; authentic: boolean };

export const getSiteImages = cache(async (): Promise<Partial<Record<SiteImageSlot, SiteImage>>> => {
  const rows = await db()
    .select({ slot: schema.siteImages.slot, media: schema.media })
    .from(schema.siteImages)
    .innerJoin(schema.media, eq(schema.media.id, schema.siteImages.mediaId));
  const out: Partial<Record<SiteImageSlot, SiteImage>> = {};
  for (const r of rows)
    out[r.slot as SiteImageSlot] = {
      url: `/media/${r.media.id}`,
      width: r.media.width,
      height: r.media.height,
      alt: r.media.alt as Record<string, string>,
      authentic: r.media.authentic,
    };
  return out;
});

/** Width/height/alt for a list of media ids (no image bytes). */
export async function getMediaMeta(ids: (string | null | undefined)[]) {
  const list = ids.filter(Boolean) as string[];
  if (!list.length) return new Map<string, { width: number; height: number; alt: Record<string, string>; authentic: boolean }>();
  const rows = await db()
    .select({
      id: schema.media.id,
      width: schema.media.width,
      height: schema.media.height,
      alt: schema.media.alt,
      authentic: schema.media.authentic,
    })
    .from(schema.media)
    .where(inArray(schema.media.id, list));
  return new Map(
    rows.map((r) => [r.id, { width: r.width, height: r.height, alt: r.alt as Record<string, string>, authentic: r.authentic }]),
  );
}

export const getPublishedGallery = cache(async () =>
  db()
    .select()
    .from(schema.galleryPhotos)
    .where(and(eq(schema.galleryPhotos.published, true), eq(schema.galleryPhotos.consentObtained, true)))
    .orderBy(asc(schema.galleryPhotos.sortOrder)),
);
