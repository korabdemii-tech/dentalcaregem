import "server-only";

/**
 * Centralised, validated access to server-side configuration.
 * Values are read lazily so that `next build` works without a database.
 */
function read(name: string, fallback?: string): string {
  const v = process.env[name];
  if (v === undefined || v === "") {
    if (fallback !== undefined) return fallback;
    throw new Error(`Missing required environment variable ${name}. See .env.example.`);
  }
  return v;
}

export const env = {
  get siteUrl() {
    return read("SITE_URL", "http://localhost:3000").replace(/\/$/, "");
  },
  get databaseUrl() {
    return read("DATABASE_URL");
  },
  get appSecret() {
    const s = read("APP_SECRET");
    if (s.length < 32) throw new Error("APP_SECRET must be at least 32 characters.");
    return s;
  },
  get cronSecret() {
    return read("CRON_SECRET", "");
  },
  get isProd() {
    return process.env.NODE_ENV === "production";
  },
  email: {
    get provider() {
      return read("EMAIL_PROVIDER", "none") as "resend" | "log" | "none";
    },
    get resendKey() {
      return read("RESEND_API_KEY", "");
    },
    get from() {
      return read("EMAIL_FROM", "");
    },
    get replyTo() {
      return read("EMAIL_REPLY_TO", "");
    },
  },
  sms: {
    get provider() {
      return read("SMS_PROVIDER", "none") as "twilio" | "log" | "none";
    },
    get sid() {
      return read("TWILIO_ACCOUNT_SID", "");
    },
    get token() {
      return read("TWILIO_AUTH_TOKEN", "");
    },
    get from() {
      return read("TWILIO_FROM_NUMBER", "");
    },
    get messagingServiceSid() {
      return read("TWILIO_MESSAGING_SERVICE_SID", "");
    },
  },
  whatsapp: {
    get provider() {
      return read("WHATSAPP_PROVIDER", "none") as "meta" | "log" | "none";
    },
    get phoneNumberId() {
      return read("WHATSAPP_PHONE_NUMBER_ID", "");
    },
    get token() {
      return read("WHATSAPP_ACCESS_TOKEN", "");
    },
    languageFor(locale: string) {
      return read(`WHATSAPP_TEMPLATE_LANGUAGE_${locale.toUpperCase()}`, locale);
    },
  },
  turnstile: {
    get siteKey() {
      return read("NEXT_PUBLIC_TURNSTILE_SITE_KEY", "");
    },
    get secret() {
      return read("TURNSTILE_SECRET_KEY", "");
    },
  },
};
