/**
 * Small, dependency-free interaction layer driven by data attributes, so the
 * same code works for server-rendered markup anywhere on the site:
 *
 *   data-reveal[="fade"|"zoom"|"unveil"]  animate in when scrolled into view
 *   data-spotlight                         champagne light follows the pointer
 *   data-tilt                              gentle 3D tilt toward the pointer
 *   data-parallax + [data-depth]           layered depth inside a container
 *
 * Content is never hidden without JavaScript, and nothing moves when the
 * visitor prefers reduced motion. Pointer effects only run on fine pointers.
 */
export function initInteractions(doc: Document = document): () => void {
  const win = doc.defaultView!;
  const reduce = win.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const fine = win.matchMedia("(hover: hover) and (pointer: fine)").matches;
  const cleanups: (() => void)[] = [];

  // ── Scroll reveal ──────────────────────────────────────────
  if (!reduce && "IntersectionObserver" in win) {
    const pending = new Set<Element>();
    const show = (el: Element) => {
      el.classList.add("is-in");
      pending.delete(el);
      io.unobserve(el);
    };
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) if (e.isIntersecting) show(e.target);
      },
      { rootMargin: "0px 0px -8% 0px", threshold: 0.08 },
    );
    const seen = new WeakSet<Element>();
    const scan = () => {
      const vh = win.innerHeight;
      const starting = !doc.documentElement.classList.contains("gd-reveal");
      doc.querySelectorAll("[data-reveal]:not(.is-in)").forEach((el) => {
        if (seen.has(el)) return;
        seen.add(el);
        const r = el.getBoundingClientRect();
        // On screen (or already scrolled past) when we start: show at once, no flash.
        if (starting && r.top < vh) el.classList.add("is-in");
        else {
          pending.add(el);
          io.observe(el);
        }
      });
    };
    scan();
    doc.documentElement.classList.add("gd-reveal");

    // Safety net for jumps (anchor links, fast flings): anything the visitor
    // has already scrolled past is shown, so scrolling back never finds gaps.
    let ticking = false;
    const onScroll = () => {
      if (ticking) return;
      ticking = true;
      win.requestAnimationFrame(() => {
        ticking = false;
        for (const el of pending) if (el.getBoundingClientRect().top < 0) show(el);
      });
    };
    win.addEventListener("scroll", onScroll, { passive: true });

    let queued = false;
    const mo = new MutationObserver(() => {
      if (queued) return;
      queued = true;
      win.requestAnimationFrame(() => {
        queued = false;
        scan();
      });
    });
    mo.observe(doc.body, { childList: true, subtree: true });
    cleanups.push(() => {
      io.disconnect();
      mo.disconnect();
      win.removeEventListener("scroll", onScroll);
    });
  }

  if (reduce || !fine) return () => cleanups.forEach((c) => c());

  // ── Pointer effects (delegated) ────────────────────────────
  let tiltEl: HTMLElement | null = null;
  let parallaxEl: HTMLElement | null = null;
  let frame = 0;
  let last: PointerEvent | null = null;

  const resetTilt = () => {
    if (!tiltEl) return;
    tiltEl.classList.remove("is-tilting");
    tiltEl.style.setProperty("--rx", "0deg");
    tiltEl.style.setProperty("--ry", "0deg");
    tiltEl = null;
  };
  const resetParallax = () => {
    if (!parallaxEl) return;
    parallaxEl.querySelectorAll<HTMLElement>("[data-depth]").forEach((d) => {
      d.style.setProperty("--px", "0");
      d.style.setProperty("--py", "0");
    });
    parallaxEl = null;
  };

  const apply = () => {
    frame = 0;
    const e = last;
    if (!e) return;
    const target = e.target instanceof Element ? e.target : null;

    const spot = target?.closest<HTMLElement>("[data-spotlight]");
    if (spot) {
      const r = spot.getBoundingClientRect();
      spot.style.setProperty("--mx", `${e.clientX - r.left}px`);
      spot.style.setProperty("--my", `${e.clientY - r.top}px`);
    }

    const tilt = target?.closest<HTMLElement>("[data-tilt]") ?? null;
    if (tilt !== tiltEl) resetTilt();
    if (tilt) {
      tiltEl = tilt;
      const r = tilt.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width - 0.5;
      const y = (e.clientY - r.top) / r.height - 0.5;
      const max = Number(tilt.dataset.tilt) || 6;
      tilt.classList.add("is-tilting");
      tilt.style.setProperty("--rx", `${(-y * max).toFixed(2)}deg`);
      tilt.style.setProperty("--ry", `${(x * max).toFixed(2)}deg`);
    }

    const par = target?.closest<HTMLElement>("[data-parallax]") ?? null;
    if (par !== parallaxEl) resetParallax();
    if (par) {
      parallaxEl = par;
      const r = par.getBoundingClientRect();
      const x = ((e.clientX - r.left) / r.width - 0.5) * 2;
      const y = ((e.clientY - r.top) / r.height - 0.5) * 2;
      par.querySelectorAll<HTMLElement>("[data-depth]").forEach((d) => {
        d.style.setProperty("--px", x.toFixed(3));
        d.style.setProperty("--py", y.toFixed(3));
      });
    }
  };

  const onMove = (e: PointerEvent) => {
    if (e.pointerType !== "mouse") return;
    last = e;
    if (!frame) frame = win.requestAnimationFrame(apply);
  };
  const onLeave = () => {
    resetTilt();
    resetParallax();
  };
  doc.addEventListener("pointermove", onMove, { passive: true });
  doc.documentElement.addEventListener("pointerleave", onLeave);
  cleanups.push(() => {
    doc.removeEventListener("pointermove", onMove);
    doc.documentElement.removeEventListener("pointerleave", onLeave);
    if (frame) win.cancelAnimationFrame(frame);
  });

  return () => cleanups.forEach((c) => c());
}
