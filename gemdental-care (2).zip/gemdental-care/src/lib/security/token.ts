import "server-only";
import { createHmac, timingSafeEqual, createHash, randomBytes } from "node:crypto";
import { env } from "@/lib/env";

function b64url(buf: Buffer) {
  return buf.toString("base64url");
}

function hmac(data: string) {
  return createHmac("sha256", env.appSecret).update(data).digest();
}

/** Sign a small JSON payload. Not encrypted: never put secrets inside. */
export function signToken(payload: Record<string, unknown>): string {
  const body = b64url(Buffer.from(JSON.stringify(payload)));
  return `${body}.${b64url(hmac(body))}`;
}

export function verifyToken<T = Record<string, unknown>>(token: string | undefined | null): T | null {
  if (!token || typeof token !== "string") return null;
  const [body, sig] = token.split(".");
  if (!body || !sig) return null;
  const expected = hmac(body);
  const given = Buffer.from(sig, "base64url");
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    return JSON.parse(Buffer.from(body, "base64url").toString("utf8")) as T;
  } catch {
    return null;
  }
}

export function sha256(input: string): string {
  return createHash("sha256").update(input).digest("hex");
}

/** Keyed hash for values like IP addresses that we must not store in clear. */
export function pseudonymize(input: string): string {
  return createHmac("sha256", env.appSecret).update(`pseudo:${input}`).digest("hex").slice(0, 32);
}

export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}
