import "server-only";
import { env } from "@/lib/env";

/**
 * Client IP for rate limiting. Production must run behind a reverse proxy that
 * sets these headers from the real connection (Vercel, Cloudflare, or Nginx with
 * `proxy_set_header X-Real-IP $remote_addr`) and strips client-supplied
 * values; see docs/DEPLOYMENT.md.
 */
export function clientIp(headers: Headers): string {
  const real = headers.get("x-real-ip") ?? headers.get("cf-connecting-ip");
  if (real) return real.trim();
  const xff = headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return headers.get("x-real-ip") ?? "unknown";
}

/**
 * CSRF defence for JSON route handlers: browsers always send Origin on
 * cross-site POSTs, so reject requests whose Origin is not our own site.
 */
export function isSameOrigin(req: Request): boolean {
  const origin = req.headers.get("origin");
  if (!origin) return false;
  try {
    const o = new URL(origin);
    const self = new URL(req.url);
    const site = new URL(env.siteUrl);
    const host = req.headers.get("x-forwarded-host") ?? req.headers.get("host") ?? self.host;
    return o.host === host || o.host === site.host;
  } catch {
    return false;
  }
}
