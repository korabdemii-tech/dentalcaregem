import "server-only";
import { timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env";

/** Scheduled-job endpoints require "Authorization: Bearer <CRON_SECRET>". */
export function isCronAuthorized(req: Request): boolean {
  const secret = env.cronSecret;
  if (!secret) return false;
  const given = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  const a = Buffer.from(given);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}
