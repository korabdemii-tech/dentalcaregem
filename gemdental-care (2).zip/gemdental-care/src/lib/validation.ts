/**
 * Validation shared by the browser (instant feedback) and the server (the
 * authority). Error messages are translation keys, resolved by the UI.
 */
import { z } from "zod";
import { parsePhoneNumberFromString, type CountryCode } from "libphonenumber-js/min";

export function normalizePhone(raw: string, defaultCountry?: string | null): string | null {
  const value = raw.trim();
  if (!value) return null;
  const parsed = parsePhoneNumberFromString(
    value.startsWith("00") ? `+${value.slice(2)}` : value,
    (defaultCountry || undefined) as CountryCode | undefined,
  );
  if (!parsed || !parsed.isValid()) return null;
  return parsed.number; // E.164
}

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

export const patientDetailsSchema = (defaultCountry?: string | null) =>
  z.object({
    fullName: z
      .string()
      .trim()
      .min(2, "errors.nameRequired")
      .max(120, "errors.nameTooLong")
      .refine((v) => /\p{L}/u.test(v), "errors.nameRequired"),
    phone: z
      .string()
      .trim()
      .min(1, "errors.phoneRequired")
      .max(32, "errors.phoneInvalid")
      .refine((v) => normalizePhone(v, defaultCountry) !== null, "errors.phoneInvalid"),
    email: z
      .string()
      .trim()
      .min(1, "errors.emailRequired")
      .max(200, "errors.emailInvalid")
      .refine((v) => EMAIL_RE.test(v), "errors.emailInvalid"),
    note: z.string().trim().max(1000, "errors.noteTooLong").optional().default(""),
    isReturning: z.enum(["new", "returning", "unspecified"]).optional().default("unspecified"),
    consentSms: z.boolean().optional().default(false),
    consentWhatsapp: z.boolean().optional().default(false),
    acceptPrivacy: z.literal(true, { error: "errors.privacyRequired" }),
  });

export type PatientDetails = z.infer<ReturnType<typeof patientDetailsSchema>>;

export const bookingRequestSchema = (defaultCountry?: string | null) =>
  z.object({
    serviceId: z.uuid(),
    doctorId: z.union([z.uuid(), z.literal("any")]),
    start: z.iso.datetime({ offset: true }),
    locale: z.enum(["sq", "en"]),
    idempotencyKey: z
      .string()
      .min(16)
      .max(80)
      .regex(/^[A-Za-z0-9_-]+$/),
    sessionToken: z.string().min(10).max(500),
    turnstileToken: z.string().max(4000).optional(),
    /** Honeypot: humans never see or fill this field. */
    website: z.string().max(0).optional().default(""),
    patient: patientDetailsSchema(defaultCountry),
  });

export type BookingRequest = z.infer<ReturnType<typeof bookingRequestSchema>>;

/** Map zod issues to { fieldPath: translationKey }. */
export function fieldErrors(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const path = issue.path.join(".");
    if (!out[path]) out[path] = issue.message.startsWith("errors.") ? issue.message : "errors.invalid";
  }
  return out;
}
