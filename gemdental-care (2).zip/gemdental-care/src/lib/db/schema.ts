import {
  pgTable,
  pgEnum,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  primaryKey,
  uniqueIndex,
  index,
  customType,
  smallint,
  bigserial,
} from "drizzle-orm/pg-core";
import type { Localized } from "@/lib/i18n/config";

const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });

export type LocalizedList = Partial<Record<"sq" | "en", string[]>>;

// ─── Enums ────────────────────────────────────────────────────

export const appointmentStatus = pgEnum("appointment_status", [
  "pending",
  "confirmed",
  "cancelled",
  "completed",
  "no_show",
  "reschedule_requested",
]);

/** Statuses that occupy a slot in the calendar. Mirrors the DB exclusion constraint. */
export const BLOCKING_STATUSES = ["pending", "confirmed", "reschedule_requested"] as const;

export const adminRole = pgEnum("admin_role", ["owner", "manager", "staff"]);

export const exceptionKind = pgEnum("availability_exception_kind", [
  "closure", // whole clinic closed (doctor_id is null)
  "holiday",
  "time_off",
  "block", // ad-hoc blocked time
]);

export const notificationEvent = pgEnum("notification_event", ["request_received", "confirmed", "reminder", "cancelled", "rescheduled"]);

export const notificationChannel = pgEnum("notification_channel", ["email", "sms", "whatsapp"]);

export const notificationStatus = pgEnum("notification_status", [
  "queued",
  "sending",
  "sent", // accepted by the provider
  "failed", // gave up after retries
  "skipped", // channel not configured, no consent or no address
  "logged", // development log provider, nothing delivered
]);

// ─── Clinic configuration ─────────────────────────────────────

export type OpeningHoursRow = { day: number; open: string; close: string } | { day: number; closed: true };
export type ReminderRule = { key: string; minutesBefore: number; enabled: boolean };
export type SocialLinks = { instagram?: string; facebook?: string; tiktok?: string; linkedin?: string };

export const clinicSettings = pgTable("clinic_settings", {
  id: smallint("id").primaryKey().default(1),
  clinicName: text("clinic_name").notNull().default("GemDental Care"),
  phone: text("phone"), // E.164
  whatsapp: text("whatsapp"), // E.164
  email: text("email"),
  addressLine: jsonb("address_line").$type<Localized>(),
  city: text("city"),
  postalCode: text("postal_code"),
  country: text("country"), // ISO 3166-1 alpha-2
  mapsUrl: text("maps_url"),
  latitude: text("latitude"),
  longitude: text("longitude"),
  openingHours: jsonb("opening_hours").$type<OpeningHoursRow[]>(),
  social: jsonb("social").$type<SocialLinks>().notNull().default({}),
  timezone: text("timezone").notNull().default("Europe/Belgrade"),
  // Booking policy
  autoConfirm: boolean("auto_confirm").notNull().default(false),
  minNoticeMinutes: integer("min_notice_minutes").notNull().default(120),
  horizonDays: integer("horizon_days").notNull().default(60),
  slotIntervalMinutes: integer("slot_interval_minutes").notNull().default(15),
  onlineBookingEnabled: boolean("online_booking_enabled").notNull().default(true),
  bookingPolicy: jsonb("booking_policy").$type<Localized>(),
  // Notifications
  channelsEnabled: jsonb("channels_enabled")
    .$type<{ email: boolean; sms: boolean; whatsapp: boolean }>()
    .notNull()
    .default({ email: true, sms: false, whatsapp: false }),
  reminders: jsonb("reminders")
    .$type<ReminderRule[]>()
    .notNull()
    .default([
      { key: "24h", minutesBefore: 1440, enabled: true },
      { key: "2h", minutesBefore: 120, enabled: false },
    ]),
  whatsappTemplates: jsonb("whatsapp_templates").$type<Partial<Record<string, string>>>().notNull().default({}),
  // Privacy
  dataRetentionMonths: integer("data_retention_months").notNull().default(36),
  privacyContactEmail: text("privacy_contact_email"),
  legalEntityName: text("legal_entity_name"),
  /** Shows a discreet "preview" ribbon on the public site while content is unconfirmed. */
  previewNotice: boolean("preview_notice").notNull().default(true),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

// ─── Media (clinic images, stored in Postgres) ────────────────

export const media = pgTable("media", {
  id: uuid("id").primaryKey().defaultRandom(),
  mime: text("mime").notNull(),
  bytes: bytea("bytes").notNull(),
  width: integer("width").notNull(),
  height: integer("height").notNull(),
  sizeBytes: integer("size_bytes").notNull(),
  alt: jsonb("alt").$type<Localized>().notNull().default({}),
  /** Is this an authentic GemDental photo (true) or temporary imagery (false)? */
  authentic: boolean("authentic").notNull().default(true),
  label: text("label"),
  createdAt: ts("created_at").notNull().defaultNow(),
});

/** Named image slots on the public site (hero, about, …). */
export const siteImages = pgTable("site_images", {
  slot: text("slot").primaryKey(),
  mediaId: uuid("media_id").references(() => media.id, { onDelete: "set null" }),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

// ─── Doctors & services ───────────────────────────────────────

export const doctors = pgTable("doctors", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  fullName: text("full_name").notNull(),
  title: jsonb("title").$type<Localized>().notNull().default({}),
  bio: jsonb("bio").$type<Localized>().notNull().default({}),
  education: jsonb("education").$type<LocalizedList>().notNull().default({}),
  specialties: jsonb("specialties").$type<LocalizedList>().notNull().default({}),
  experience: jsonb("experience").$type<Localized>().notNull().default({}),
  languages: jsonb("languages").$type<LocalizedList>().notNull().default({}),
  qualifications: jsonb("qualifications").$type<LocalizedList>().notNull().default({}),
  photoMediaId: uuid("photo_media_id").references(() => media.id, { onDelete: "set null" }),
  /** Accepts online bookings. */
  active: boolean("active").notNull().default(true),
  /** Profile visible on the public site. */
  published: boolean("published").notNull().default(true),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const services = pgTable("services", {
  id: uuid("id").primaryKey().defaultRandom(),
  slug: text("slug").notNull().unique(),
  name: jsonb("name").$type<Localized>().notNull(),
  summary: jsonb("summary").$type<Localized>().notNull().default({}),
  description: jsonb("description").$type<Localized>().notNull().default({}),
  imageMediaId: uuid("image_media_id").references(() => media.id, { onDelete: "set null" }),
  durationMinutes: integer("duration_minutes").notNull().default(30),
  bufferMinutes: integer("buffer_minutes").notNull().default(0),
  /** Free text so the clinic controls wording, e.g. "from €40". */
  price: jsonb("price").$type<Localized>(),
  priceVisible: boolean("price_visible").notNull().default(false),
  durationVisible: boolean("duration_visible").notNull().default(true),
  /** The clinic has confirmed it offers this treatment. Unconfirmed services can never be published. */
  confirmed: boolean("confirmed").notNull().default(false),
  published: boolean("published").notNull().default(false),
  bookable: boolean("bookable").notNull().default(true),
  /** The "I'm not sure, I need a consultation" option. */
  isConsultation: boolean("is_consultation").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: ts("created_at").notNull().defaultNow(),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

export const doctorServices = pgTable(
  "doctor_services",
  {
    doctorId: uuid("doctor_id")
      .notNull()
      .references(() => doctors.id, { onDelete: "cascade" }),
    serviceId: uuid("service_id")
      .notNull()
      .references(() => services.id, { onDelete: "cascade" }),
  },
  (t) => [primaryKey({ columns: [t.doctorId, t.serviceId] })],
);

/** Weekly working pattern. Several rows per weekday express breaks (09:00–13:00, 14:00–18:00). */
export const workingHours = pgTable(
  "working_hours",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    doctorId: uuid("doctor_id")
      .notNull()
      .references(() => doctors.id, { onDelete: "cascade" }),
    weekday: smallint("weekday").notNull(), // 0 = Sunday … 6 = Saturday
    startMinute: integer("start_minute").notNull(), // minutes after local midnight
    endMinute: integer("end_minute").notNull(),
  },
  (t) => [index("working_hours_doctor_idx").on(t.doctorId, t.weekday)],
);

export const availabilityExceptions = pgTable(
  "availability_exceptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    doctorId: uuid("doctor_id").references(() => doctors.id, { onDelete: "cascade" }), // null = whole clinic
    kind: exceptionKind("kind").notNull(),
    startsAt: ts("starts_at").notNull(),
    endsAt: ts("ends_at").notNull(),
    reason: text("reason"),
    createdBy: uuid("created_by"),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [index("availability_exceptions_range_idx").on(t.startsAt, t.endsAt)],
);

// ─── Patients & appointments ──────────────────────────────────

export const patients = pgTable(
  "patients",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    fullName: text("full_name").notNull(),
    phone: text("phone").notNull(), // E.164
    email: text("email").notNull(), // lower-cased
    preferredLocale: text("preferred_locale").notNull().default("sq"),
    isReturning: boolean("is_returning"),
    consentSms: boolean("consent_sms").notNull().default(false),
    consentWhatsapp: boolean("consent_whatsapp").notNull().default(false),
    consentUpdatedAt: ts("consent_updated_at"),
    privacyAcceptedAt: ts("privacy_accepted_at"),
    createdAt: ts("created_at").notNull().defaultNow(),
    updatedAt: ts("updated_at").notNull().defaultNow(),
  },
  (t) => [index("patients_email_idx").on(t.email), index("patients_phone_idx").on(t.phone)],
);

export const appointments = pgTable(
  "appointments",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    reference: text("reference").notNull().unique(),
    patientId: uuid("patient_id")
      .notNull()
      .references(() => patients.id, { onDelete: "restrict" }),
    doctorId: uuid("doctor_id")
      .notNull()
      .references(() => doctors.id, { onDelete: "restrict" }),
    serviceId: uuid("service_id")
      .notNull()
      .references(() => services.id, { onDelete: "restrict" }),
    startsAt: ts("starts_at").notNull(),
    endsAt: ts("ends_at").notNull(),
    /** endsAt + service buffer. The range [startsAt, blockedUntil) is what may not overlap. */
    blockedUntil: ts("blocked_until").notNull(),
    status: appointmentStatus("status").notNull().default("pending"),
    source: text("source").notNull().default("online"), // online | admin
    patientNote: text("patient_note"),
    adminNotes: text("admin_notes"),
    locale: text("locale").notNull().default("sq"),
    idempotencyKey: text("idempotency_key").unique(),
    confirmedAt: ts("confirmed_at"),
    cancelledAt: ts("cancelled_at"),
    cancelReason: text("cancel_reason"),
    createdBy: uuid("created_by"),
    createdAt: ts("created_at").notNull().defaultNow(),
    updatedAt: ts("updated_at").notNull().defaultNow(),
  },
  (t) => [
    index("appointments_doctor_time_idx").on(t.doctorId, t.startsAt),
    index("appointments_status_idx").on(t.status, t.startsAt),
    index("appointments_patient_idx").on(t.patientId),
    // Double-booking protection lives in migration 0001_booking_constraints.sql:
    //   EXCLUDE USING gist (doctor_id WITH =, tstzrange(starts_at, blocked_until) WITH &&)
    //   WHERE (status IN ('pending','confirmed','reschedule_requested'))
  ],
);

// ─── Notifications ────────────────────────────────────────────

export const notificationTemplates = pgTable(
  "notification_templates",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    event: notificationEvent("event").notNull(),
    channel: notificationChannel("channel").notNull(),
    locale: text("locale").notNull(),
    subject: text("subject"),
    body: text("body").notNull(),
    enabled: boolean("enabled").notNull().default(true),
    updatedBy: uuid("updated_by"),
    updatedAt: ts("updated_at").notNull().defaultNow(),
  },
  (t) => [uniqueIndex("notification_templates_uq").on(t.event, t.channel, t.locale)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    appointmentId: uuid("appointment_id")
      .notNull()
      .references(() => appointments.id, { onDelete: "cascade" }),
    event: notificationEvent("event").notNull(),
    channel: notificationChannel("channel").notNull(),
    /** Unique per logical message: prevents duplicates when jobs are retried or re-run. */
    dedupeKey: text("dedupe_key").notNull().unique(),
    recipient: text("recipient"),
    locale: text("locale").notNull(),
    subject: text("subject"),
    body: text("body"),
    status: notificationStatus("status").notNull().default("queued"),
    attempts: integer("attempts").notNull().default(0),
    nextAttemptAt: ts("next_attempt_at").notNull().defaultNow(),
    lockedUntil: ts("locked_until"),
    lastError: text("last_error"),
    providerMessageId: text("provider_message_id"),
    sentAt: ts("sent_at"),
    createdAt: ts("created_at").notNull().defaultNow(),
    updatedAt: ts("updated_at").notNull().defaultNow(),
  },
  (t) => [index("notifications_queue_idx").on(t.status, t.nextAttemptAt), index("notifications_appointment_idx").on(t.appointmentId)],
);

// ─── Content ──────────────────────────────────────────────────

export const faqs = pgTable("faqs", {
  id: uuid("id").primaryKey().defaultRandom(),
  topic: text("topic").notNull(),
  question: jsonb("question").$type<Localized>().notNull(),
  answer: jsonb("answer").$type<Localized>().notNull(),
  /** Answer has been checked by the clinic. Only verified answers can be published. */
  verified: boolean("verified").notNull().default(false),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  updatedAt: ts("updated_at").notNull().defaultNow(),
});

export const testimonials = pgTable("testimonials", {
  id: uuid("id").primaryKey().defaultRandom(),
  authorName: text("author_name").notNull(),
  body: text("body").notNull(),
  locale: text("locale").notNull().default("sq"),
  rating: smallint("rating"),
  source: text("source").notNull(), // e.g. "Google", "In-clinic form"
  sourceUrl: text("source_url"),
  reviewDate: text("review_date"),
  /** Clinic confirmed this is a genuine review and the author agreed to publication. */
  verified: boolean("verified").notNull().default(false),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const resultCases = pgTable("result_cases", {
  id: uuid("id").primaryKey().defaultRandom(),
  serviceId: uuid("service_id").references(() => services.id, { onDelete: "set null" }),
  title: jsonb("title").$type<Localized>().notNull().default({}),
  description: jsonb("description").$type<Localized>().notNull().default({}),
  beforeMediaId: uuid("before_media_id").references(() => media.id, { onDelete: "set null" }),
  afterMediaId: uuid("after_media_id").references(() => media.id, { onDelete: "set null" }),
  /** What the patient came in with, used to filter the results gallery. */
  concern: text("concern").$type<ResultConcern>(),
  consentObtained: boolean("consent_obtained").notNull().default(false),
  consentDate: text("consent_date"),
  consentReference: text("consent_reference"), // where the signed form is filed
  approvedBy: text("approved_by"),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const RESULT_CONCERNS = ["missing", "spacing", "colour", "shape"] as const;
export type ResultConcern = (typeof RESULT_CONCERNS)[number];

export const GALLERY_KINDS = ["smile", "gems"] as const;
export type GalleryKind = (typeof GALLERY_KINDS)[number];

/** Single clinic photographs (finished smiles, tooth gems). Same consent rules as result cases. */
export const galleryPhotos = pgTable("gallery_photos", {
  id: uuid("id").primaryKey().defaultRandom(),
  mediaId: uuid("media_id")
    .notNull()
    .references(() => media.id, { onDelete: "cascade" }),
  kind: text("kind").$type<GalleryKind>().notNull().default("smile"),
  caption: jsonb("caption").$type<Localized>().notNull().default({}),
  consentObtained: boolean("consent_obtained").notNull().default(false),
  consentDate: text("consent_date"),
  consentReference: text("consent_reference"),
  approvedBy: text("approved_by"),
  published: boolean("published").notNull().default(false),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: ts("created_at").notNull().defaultNow(),
});

// ─── Administration ───────────────────────────────────────────

export const adminUsers = pgTable("admin_users", {
  id: uuid("id").primaryKey().defaultRandom(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  passwordHash: text("password_hash").notNull(),
  role: adminRole("role").notNull().default("staff"),
  active: boolean("active").notNull().default(true),
  failedLogins: integer("failed_logins").notNull().default(0),
  lockedUntil: ts("locked_until"),
  lastLoginAt: ts("last_login_at"),
  locale: text("locale").notNull().default("sq"),
  createdAt: ts("created_at").notNull().defaultNow(),
});

export const sessions = pgTable(
  "sessions",
  {
    /** SHA-256 of the session token; the raw token only lives in the cookie. */
    id: text("id").primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => adminUsers.id, { onDelete: "cascade" }),
    expiresAt: ts("expires_at").notNull(),
    createdAt: ts("created_at").notNull().defaultNow(),
    userAgent: text("user_agent"),
  },
  (t) => [index("sessions_user_idx").on(t.userId)],
);

export const auditLogs = pgTable(
  "audit_logs",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    actorId: uuid("actor_id"),
    actorLabel: text("actor_label").notNull(), // "system", "patient (online)", or admin email
    action: text("action").notNull(),
    entityType: text("entity_type").notNull(),
    entityId: text("entity_id"),
    details: jsonb("details").$type<Record<string, unknown>>().notNull().default({}),
    createdAt: ts("created_at").notNull().defaultNow(),
  },
  (t) => [index("audit_logs_created_idx").on(t.createdAt), index("audit_logs_entity_idx").on(t.entityType, t.entityId)],
);

export const rateLimits = pgTable("rate_limits", {
  key: text("key").primaryKey(),
  windowStart: ts("window_start").notNull(),
  count: integer("count").notNull().default(0),
});
