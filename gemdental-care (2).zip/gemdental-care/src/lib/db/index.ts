import "server-only";
import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
import * as schema from "./schema";

export type DB = NodePgDatabase<typeof schema>;

const globalForDb = globalThis as unknown as { __gdPool?: Pool; __gdDb?: DB };

function create(): DB {
  const url = process.env.DATABASE_URL;
  if (!url) throw new Error("DATABASE_URL is not set. See .env.example.");
  const pool =
    globalForDb.__gdPool ??
    new Pool({
      connectionString: url,
      max: Number(process.env.DATABASE_POOL_MAX ?? 10),
      ssl: process.env.DATABASE_SSL === "require" ? { rejectUnauthorized: true } : undefined,
    });
  globalForDb.__gdPool = pool;
  return drizzle(pool, { schema });
}

/** Lazily-created shared database client (one pool per server process). */
export function db(): DB {
  if (!globalForDb.__gdDb) globalForDb.__gdDb = create();
  return globalForDb.__gdDb;
}

export { schema };
