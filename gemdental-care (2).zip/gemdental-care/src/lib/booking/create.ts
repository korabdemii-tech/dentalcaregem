import "server-only";
import { and, eq, sql } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { getSettings, type ClinicSettings } from "@/lib/settings";
import { zonedDateKey } from "@/lib/time";
import { normalizePhone } from "@/lib/validation";
import { audit } from "@/lib/audit";
import { enqueueNotifications } from "@/lib/notifications/queue";
import { eligibleDoctors, getDaySlots, type Tx } from "./availability-service";
import { newReference } from "./reference";
import { PG_EXCLUSION_VIOLATION, PG_UNIQUE_VIOLATION, pgCode, pgConstraint } from "./errors";

export type BookingOutcome =
  | {
      ok: true;
      status: "confirmed" | "pending";
      appointmentId: string;
      reference: string;
      startsAt: string;
      endsAt: string;
      doctorId: string;
      serviceId: string;
      replayed: boolean;
    }
  | { ok: false; code: "SLOT_UNAVAILABLE" | "SERVICE_UNAVAILABLE" | "DOCTOR_UNAVAILABLE" | "BOOKING_DISABLED" };

export type NewBooking = {
  serviceId: string;
  doctorId: string | "any";
  start: Date;
  locale: "sq" | "en";
  idempotencyKey?: string;
  source: "online" | "admin";
  /** Admin-created bookings may be confirmed straight away. */
  forceStatus?: "confirmed" | "pending";
  actor?: { id: string | null; label: string };
  patient: {
    fullName: string;
    phone: string;
    email: string;
    note?: string;
    isReturning?: "new" | "returning" | "unspecified";
    consentSms?: boolean;
    consentWhatsapp?: boolean;
    privacyAccepted?: boolean;
  };
  /** Admins may book outside regular availability (still never overlapping). */
  ignoreSchedule?: boolean;
  durationOverrideMinutes?: number;
};

/** Serialise all booking writes for one doctor inside the current transaction. */
async function lockDoctor(tx: Tx, doctorId: string) {
  await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${"doctor:" + doctorId}, 0))`);
}

async function existingByIdempotencyKey(key: string): Promise<BookingOutcome | null> {
  const rows = await db().select().from(schema.appointments).where(eq(schema.appointments.idempotencyKey, key));
  const a = rows[0];
  if (!a) return null;
  return {
    ok: true,
    status: a.status === "confirmed" ? "confirmed" : "pending",
    appointmentId: a.id,
    reference: a.reference,
    startsAt: a.startsAt.toISOString(),
    endsAt: a.endsAt.toISOString(),
    doctorId: a.doctorId,
    serviceId: a.serviceId,
    replayed: true,
  };
}

async function upsertPatient(tx: Tx, p: NewBooking["patient"], phoneE164: string, locale: string) {
  const email = p.email.trim().toLowerCase();
  const now = new Date();
  const found = await tx
    .select()
    .from(schema.patients)
    .where(and(eq(schema.patients.email, email), eq(schema.patients.phone, phoneE164)))
    .limit(1);
  const consent = {
    consentSms: Boolean(p.consentSms),
    consentWhatsapp: Boolean(p.consentWhatsapp),
    consentUpdatedAt: now,
  };
  const isReturning = p.isReturning === "returning" ? true : p.isReturning === "new" ? false : null;
  if (found[0]) {
    await tx
      .update(schema.patients)
      .set({
        fullName: p.fullName.trim(),
        preferredLocale: locale,
        ...consent,
        ...(isReturning !== null ? { isReturning } : {}),
        ...(p.privacyAccepted ? { privacyAcceptedAt: now } : {}),
        updatedAt: now,
      })
      .where(eq(schema.patients.id, found[0].id));
    return found[0].id;
  }
  const [created] = await tx
    .insert(schema.patients)
    .values({
      fullName: p.fullName.trim(),
      phone: phoneE164,
      email,
      preferredLocale: locale,
      isReturning,
      ...consent,
      privacyAcceptedAt: p.privacyAccepted ? now : null,
    })
    .returning({ id: schema.patients.id });
  return created.id;
}

/**
 * Create an appointment. The slot is re-validated against live data inside a
 * transaction that holds a per-doctor advisory lock, and the database's
 * exclusion constraint is the final guard: two overlapping active
 * appointments for the same doctor cannot both be stored.
 */
export async function createBooking(input: NewBooking, settingsIn?: ClinicSettings): Promise<BookingOutcome> {
  const settings = settingsIn ?? (await getSettings());
  if (input.source === "online" && !settings.onlineBookingEnabled) return { ok: false, code: "BOOKING_DISABLED" };

  if (input.idempotencyKey) {
    const prior = await existingByIdempotencyKey(input.idempotencyKey);
    if (prior) return prior;
  }

  const serviceRows = await db().select().from(schema.services).where(eq(schema.services.id, input.serviceId));
  const service = serviceRows[0];
  const serviceOk = service && (input.source === "admin" ? true : service.published && service.bookable);
  if (!service || !serviceOk) return { ok: false, code: "SERVICE_UNAVAILABLE" };

  const doctors = await eligibleDoctors(service.id);
  let candidates = doctors.map((d) => d.id);
  if (input.doctorId !== "any") {
    if (!candidates.includes(input.doctorId)) {
      if (input.source !== "admin") return { ok: false, code: "DOCTOR_UNAVAILABLE" };
    }
    candidates = [input.doctorId];
  }
  if (!candidates.length) return { ok: false, code: "DOCTOR_UNAVAILABLE" };

  const phone = normalizePhone(input.patient.phone, settings.country);
  if (!phone) throw new Error("Phone must be validated before createBooking");
  const date = zonedDateKey(input.start, settings.timezone);
  const startIso = input.start.toISOString();
  const duration = input.durationOverrideMinutes ?? service.durationMinutes;
  const status: "confirmed" | "pending" = input.forceStatus ?? (settings.autoConfirm ? "confirmed" : "pending");

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const result = await db().transaction(async (tx) => {
        if (input.idempotencyKey) {
          // Serialise retries of the same request, then check whether it already succeeded.
          await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${"idem:" + input.idempotencyKey}, 0))`);
          const prior = await tx
            .select({ id: schema.appointments.id })
            .from(schema.appointments)
            .where(eq(schema.appointments.idempotencyKey, input.idempotencyKey));
          if (prior[0]) return "replay" as const;
        }
        let chosen: string | null = null;
        for (const doctorId of candidates) {
          await lockDoctor(tx, doctorId);
          if (input.ignoreSchedule) {
            chosen = doctorId;
            break;
          }
          const slots = await getDaySlots({ service, doctorIds: [doctorId], date, settings, conn: tx });
          if (slots.some((s) => s.start === startIso)) {
            chosen = doctorId;
            break;
          }
        }
        if (!chosen) return null;

        const patientId = await upsertPatient(tx, input.patient, phone, input.locale);
        const endsAt = new Date(input.start.getTime() + duration * 60_000);
        const blockedUntil = new Date(endsAt.getTime() + service.bufferMinutes * 60_000);
        const now = new Date();
        const [appt] = await tx
          .insert(schema.appointments)
          .values({
            reference: newReference(),
            patientId,
            doctorId: chosen,
            serviceId: service.id,
            startsAt: input.start,
            endsAt,
            blockedUntil,
            status,
            source: input.source,
            patientNote: input.patient.note?.trim() || null,
            locale: input.locale,
            idempotencyKey: input.idempotencyKey ?? null,
            confirmedAt: status === "confirmed" ? now : null,
            createdBy: input.actor?.id ?? null,
          })
          .returning();

        await enqueueNotifications(tx, appt.id, status === "confirmed" ? "confirmed" : "request_received", { settings });
        await audit(
          {
            actorId: input.actor?.id ?? null,
            actorLabel: input.actor?.label ?? "patient (online booking)",
            action: "appointment.created",
            entityType: "appointment",
            entityId: appt.id,
            details: { reference: appt.reference, status, source: input.source, startsAt: startIso },
          },
          tx,
        );
        return appt;
      });

      if (!result) return { ok: false, code: "SLOT_UNAVAILABLE" };
      if (result === "replay") {
        const prior = await existingByIdempotencyKey(input.idempotencyKey!);
        if (prior) return prior;
        return { ok: false, code: "SLOT_UNAVAILABLE" };
      }
      return {
        ok: true,
        status,
        appointmentId: result.id,
        reference: result.reference,
        startsAt: result.startsAt.toISOString(),
        endsAt: result.endsAt.toISOString(),
        doctorId: result.doctorId,
        serviceId: result.serviceId,
        replayed: false,
      };
    } catch (err) {
      const code = pgCode(err);
      if (code === PG_EXCLUSION_VIOLATION) return { ok: false, code: "SLOT_UNAVAILABLE" };
      if (code === PG_UNIQUE_VIOLATION) {
        const constraint = pgConstraint(err) ?? "";
        if (constraint.includes("idempotency") && input.idempotencyKey) {
          const prior = await existingByIdempotencyKey(input.idempotencyKey);
          if (prior) return prior;
        }
        if (constraint.includes("reference") && attempt === 0) continue; // astronomically rare: regenerate
      }
      throw err;
    }
  }
  return { ok: false, code: "SLOT_UNAVAILABLE" };
}
