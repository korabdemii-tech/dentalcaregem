import "server-only";
import { and, eq, gt, inArray, isNull, lt, or, asc, ne } from "drizzle-orm";
import { db, schema, type DB } from "@/lib/db";
import { BLOCKING_STATUSES } from "@/lib/db/schema";
import { computeSlots, isWithinHorizon, monthDays, type Interval, type WorkingBlock } from "@/lib/availability";
import { addDays, startOfZonedDay, zonedDateKey } from "@/lib/time";
import { getSettings, type ClinicSettings } from "@/lib/settings";

export type Tx = Parameters<Parameters<DB["transaction"]>[0]>[0];
type Conn = DB | Tx;

export type BookableService = typeof schema.services.$inferSelect;

/** Services that patients can book online right now. */
export async function bookableServices(conn: Conn = db()) {
  return conn
    .select()
    .from(schema.services)
    .where(and(eq(schema.services.published, true), eq(schema.services.bookable, true)))
    .orderBy(asc(schema.services.sortOrder));
}

/**
 * Doctors who can perform a service: active doctors explicitly assigned to it,
 * or every active doctor when the service has no assignments yet.
 */
export async function eligibleDoctors(serviceId: string, conn: Conn = db()) {
  const assigned = await conn
    .select({ doctorId: schema.doctorServices.doctorId })
    .from(schema.doctorServices)
    .where(eq(schema.doctorServices.serviceId, serviceId));
  const where = assigned.length
    ? and(
        eq(schema.doctors.active, true),
        inArray(
          schema.doctors.id,
          assigned.map((a) => a.doctorId),
        ),
      )
    : eq(schema.doctors.active, true);
  return conn.select().from(schema.doctors).where(where).orderBy(asc(schema.doctors.sortOrder));
}

type DoctorContext = {
  workingHours: WorkingBlock[];
  busy: Interval[];
  exceptions: Interval[];
};

/** Load everything that affects availability for some doctors over a UTC range. */
export async function loadDoctorContexts(
  doctorIds: string[],
  from: Date,
  to: Date,
  conn: Conn = db(),
  opts: { excludeAppointmentId?: string } = {},
): Promise<Map<string, DoctorContext>> {
  const map = new Map<string, DoctorContext>();
  for (const id of doctorIds) map.set(id, { workingHours: [], busy: [], exceptions: [] });
  if (!doctorIds.length) return map;

  const [hours, appts, exceptions] = await Promise.all([
    conn.select().from(schema.workingHours).where(inArray(schema.workingHours.doctorId, doctorIds)),
    conn
      .select({
        doctorId: schema.appointments.doctorId,
        startsAt: schema.appointments.startsAt,
        blockedUntil: schema.appointments.blockedUntil,
      })
      .from(schema.appointments)
      .where(
        and(
          inArray(schema.appointments.doctorId, doctorIds),
          inArray(schema.appointments.status, [...BLOCKING_STATUSES]),
          lt(schema.appointments.startsAt, to),
          gt(schema.appointments.blockedUntil, from),
          opts.excludeAppointmentId ? ne(schema.appointments.id, opts.excludeAppointmentId) : undefined,
        ),
      ),
    conn
      .select()
      .from(schema.availabilityExceptions)
      .where(
        and(
          or(isNull(schema.availabilityExceptions.doctorId), inArray(schema.availabilityExceptions.doctorId, doctorIds)),
          lt(schema.availabilityExceptions.startsAt, to),
          gt(schema.availabilityExceptions.endsAt, from),
        ),
      ),
  ]);

  for (const h of hours) map.get(h.doctorId)?.workingHours.push(h);
  for (const a of appts) map.get(a.doctorId)?.busy.push({ start: a.startsAt, end: a.blockedUntil });
  for (const x of exceptions) {
    const iv = { start: x.startsAt, end: x.endsAt };
    if (x.doctorId) map.get(x.doctorId)?.exceptions.push(iv);
    else for (const ctx of map.values()) ctx.exceptions.push(iv);
  }
  return map;
}

export type SlotOption = { start: string; end: string; doctorIds: string[] };

function slotsForDay(date: string, service: BookableService, settings: ClinicSettings, ctx: DoctorContext, now: Date) {
  return computeSlots({
    date,
    timezone: settings.timezone,
    workingHours: ctx.workingHours,
    durationMinutes: service.durationMinutes,
    bufferMinutes: service.bufferMinutes,
    slotIntervalMinutes: settings.slotIntervalMinutes,
    busy: ctx.busy,
    exceptions: ctx.exceptions,
    now,
    minNoticeMinutes: settings.minNoticeMinutes,
    horizonDays: settings.horizonDays,
  });
}

/** Available start times on one local day, merged across the chosen doctor(s). */
export async function getDaySlots(params: {
  service: BookableService;
  doctorIds: string[];
  date: string;
  now?: Date;
  settings?: ClinicSettings;
  conn?: Conn;
  excludeAppointmentId?: string;
}): Promise<SlotOption[]> {
  const settings = params.settings ?? (await getSettings());
  const now = params.now ?? new Date();
  if (!isWithinHorizon(params.date, now, settings.timezone, settings.horizonDays)) return [];
  const from = startOfZonedDay(params.date, settings.timezone);
  const to = startOfZonedDay(addDays(params.date, 1), settings.timezone);
  // Include the buffer window after the day so late slots see next-day busy blocks.
  const ctxs = await loadDoctorContexts(
    params.doctorIds,
    new Date(from.getTime() - 86_400_000),
    new Date(to.getTime() + 86_400_000),
    params.conn,
    { excludeAppointmentId: params.excludeAppointmentId },
  );
  const merged = new Map<number, SlotOption>();
  for (const doctorId of params.doctorIds) {
    const ctx = ctxs.get(doctorId)!;
    for (const s of slotsForDay(params.date, params.service, settings, ctx, now)) {
      const key = s.start.getTime();
      const existing = merged.get(key);
      if (existing) existing.doctorIds.push(doctorId);
      else merged.set(key, { start: s.start.toISOString(), end: s.end.toISOString(), doctorIds: [doctorId] });
    }
  }
  return [...merged.values()].sort((a, b) => a.start.localeCompare(b.start));
}

/** For a month view: which local days have at least one slot. */
export async function getMonthAvailability(params: {
  service: BookableService;
  doctorIds: string[];
  year: number;
  month: number;
  now?: Date;
}): Promise<{ available: string[]; firstBookable: string | null; lastBookable: string }> {
  const settings = await getSettings();
  const now = params.now ?? new Date();
  const days = monthDays(params.year, params.month);
  const tz = settings.timezone;
  const from = startOfZonedDay(days[0], tz);
  const to = startOfZonedDay(addDays(days[days.length - 1], 1), tz);
  const ctxs = await loadDoctorContexts(params.doctorIds, new Date(from.getTime() - 86_400_000), new Date(to.getTime() + 86_400_000));
  const available: string[] = [];
  for (const day of days) {
    if (!isWithinHorizon(day, now, tz, settings.horizonDays)) continue;
    for (const id of params.doctorIds) {
      if (slotsForDay(day, params.service, settings, ctxs.get(id)!, now).length) {
        available.push(day);
        break;
      }
    }
  }
  const today = zonedDateKey(now, tz);
  return { available, firstBookable: available[0] ?? null, lastBookable: addDays(today, settings.horizonDays) };
}
