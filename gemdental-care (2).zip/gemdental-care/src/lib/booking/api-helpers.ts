import "server-only";
import { eq } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { eligibleDoctors } from "./availability-service";

export function json(data: unknown, status = 200, headers: Record<string, string> = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...headers },
  });
}

/** Resolve a bookable service and the doctor ids to search, from public query parameters. */
export async function resolveServiceAndDoctors(serviceId: string | null, doctor: string | null) {
  if (!serviceId || !/^[0-9a-f-]{36}$/i.test(serviceId)) return null;
  const rows = await db().select().from(schema.services).where(eq(schema.services.id, serviceId));
  const service = rows[0];
  if (!service || !service.published || !service.bookable) return null;
  const eligible = (await eligibleDoctors(service.id)).map((d) => d.id);
  let doctorIds = eligible;
  if (doctor && doctor !== "any") {
    if (!eligible.includes(doctor)) return null;
    doctorIds = [doctor];
  }
  return { service, doctorIds };
}

export const BOOKING_SESSION_MIN_AGE_MS = 2_000; // faster than any human can fill the form
export const BOOKING_SESSION_MAX_AGE_MS = 45 * 60_000;
