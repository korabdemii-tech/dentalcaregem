import "server-only";
import { eq, sql } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { getSettings } from "@/lib/settings";
import { zonedDateKey } from "@/lib/time";
import { audit } from "@/lib/audit";
import { enqueueNotifications } from "@/lib/notifications/queue";
import { getDaySlots } from "./availability-service";
import { PG_EXCLUSION_VIOLATION, pgCode } from "./errors";

type Actor = { id: string; label: string };
type AppointmentStatus = (typeof schema.appointmentStatus.enumValues)[number];

export type ManageResult = { ok: true } | { ok: false; code: "NOT_FOUND" | "INVALID_TRANSITION" | "CONFLICT" | "OUTSIDE_AVAILABILITY" };

/** Allowed status changes. Terminal states can only be reopened by rescheduling. */
const TRANSITIONS: Record<AppointmentStatus, AppointmentStatus[]> = {
  pending: ["confirmed", "cancelled", "reschedule_requested"],
  confirmed: ["cancelled", "completed", "no_show", "reschedule_requested"],
  reschedule_requested: ["confirmed", "cancelled"],
  cancelled: [],
  completed: ["no_show"],
  no_show: ["completed"],
};

export function canTransition(from: AppointmentStatus, to: AppointmentStatus) {
  return TRANSITIONS[from].includes(to);
}

export async function changeStatus(
  appointmentId: string,
  to: AppointmentStatus,
  actor: Actor,
  opts: { reason?: string } = {},
): Promise<ManageResult> {
  return db().transaction(async (tx) => {
    const rows = await tx.select().from(schema.appointments).where(eq(schema.appointments.id, appointmentId)).for("update");
    const a = rows[0];
    if (!a) return { ok: false, code: "NOT_FOUND" } as const;
    if (!canTransition(a.status, to)) return { ok: false, code: "INVALID_TRANSITION" } as const;
    const now = new Date();
    try {
      await tx
        .update(schema.appointments)
        .set({
          status: to,
          updatedAt: now,
          ...(to === "confirmed" ? { confirmedAt: now } : {}),
          ...(to === "cancelled" ? { cancelledAt: now, cancelReason: opts.reason?.slice(0, 500) || null } : {}),
        })
        .where(eq(schema.appointments.id, appointmentId));
    } catch (err) {
      // Re-activating a slot (reschedule_requested → confirmed) can collide.
      if (pgCode(err) === PG_EXCLUSION_VIOLATION) return { ok: false, code: "CONFLICT" } as const;
      throw err;
    }
    if (to === "confirmed") await enqueueNotifications(tx, a.id, "confirmed");
    if (to === "cancelled") await enqueueNotifications(tx, a.id, "cancelled");
    await audit(
      {
        actorId: actor.id,
        actorLabel: actor.label,
        action: `appointment.${to}`,
        entityType: "appointment",
        entityId: a.id,
        details: { reference: a.reference, from: a.status, to },
      },
      tx,
    );
    return { ok: true } as const;
  });
}

/**
 * Move an appointment. Respects the doctor's availability unless the staff
 * member explicitly overrides it; overlaps are always refused by the database.
 */
export async function reschedule(
  appointmentId: string,
  params: { start: Date; doctorId?: string; ignoreSchedule?: boolean; notify?: boolean },
  actor: Actor,
): Promise<ManageResult> {
  const settings = await getSettings();
  try {
    return await db().transaction(async (tx) => {
      const rows = await tx.select().from(schema.appointments).where(eq(schema.appointments.id, appointmentId)).for("update");
      const a = rows[0];
      if (!a) return { ok: false, code: "NOT_FOUND" } as const;
      if (a.status === "cancelled" || a.status === "completed" || a.status === "no_show")
        return { ok: false, code: "INVALID_TRANSITION" } as const;
      const [service] = await tx.select().from(schema.services).where(eq(schema.services.id, a.serviceId));
      const doctorId = params.doctorId ?? a.doctorId;
      await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtextextended(${"doctor:" + doctorId}, 0))`);
      const durationMs = a.endsAt.getTime() - a.startsAt.getTime();
      const bufferMs = a.blockedUntil.getTime() - a.endsAt.getTime();
      if (!params.ignoreSchedule) {
        const date = zonedDateKey(params.start, settings.timezone);
        const slots = await getDaySlots({
          service: { ...service, durationMinutes: Math.round(durationMs / 60_000) },
          doctorIds: [doctorId],
          date,
          settings: { ...settings, minNoticeMinutes: 0 },
          conn: tx,
          excludeAppointmentId: a.id,
        });
        if (!slots.some((s) => s.start === params.start.toISOString())) return { ok: false, code: "OUTSIDE_AVAILABILITY" } as const;
      }
      const endsAt = new Date(params.start.getTime() + durationMs);
      const now = new Date();
      await tx
        .update(schema.appointments)
        .set({
          startsAt: params.start,
          endsAt,
          blockedUntil: new Date(endsAt.getTime() + bufferMs),
          doctorId,
          status: a.status === "reschedule_requested" ? "confirmed" : a.status,
          confirmedAt: a.status === "reschedule_requested" ? now : a.confirmedAt,
          updatedAt: now,
        })
        .where(eq(schema.appointments.id, a.id));
      if (params.notify !== false) await enqueueNotifications(tx, a.id, "rescheduled", { variant: params.start.toISOString(), settings });
      await audit(
        {
          actorId: actor.id,
          actorLabel: actor.label,
          action: "appointment.rescheduled",
          entityType: "appointment",
          entityId: a.id,
          details: {
            reference: a.reference,
            from: a.startsAt.toISOString(),
            to: params.start.toISOString(),
            doctorChanged: doctorId !== a.doctorId,
            override: Boolean(params.ignoreSchedule),
          },
        },
        tx,
      );
      return { ok: true } as const;
    });
  } catch (err) {
    if (pgCode(err) === PG_EXCLUSION_VIOLATION) return { ok: false, code: "CONFLICT" };
    throw err;
  }
}

export async function updateAdminNotes(appointmentId: string, notes: string, actor: Actor) {
  await db()
    .update(schema.appointments)
    .set({ adminNotes: notes.slice(0, 4000) || null, updatedAt: new Date() })
    .where(eq(schema.appointments.id, appointmentId));
  await audit({
    actorId: actor.id,
    actorLabel: actor.label,
    action: "appointment.notes_updated",
    entityType: "appointment",
    entityId: appointmentId,
  });
}
