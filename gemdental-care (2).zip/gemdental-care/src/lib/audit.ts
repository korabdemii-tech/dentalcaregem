import "server-only";
import { db, schema, type DB } from "@/lib/db";

type Tx = Parameters<Parameters<DB["transaction"]>[0]>[0];

export type AuditEntry = {
  actorId?: string | null;
  actorLabel: string;
  action: string;
  entityType: string;
  entityId?: string | null;
  /** Keep personal data out of details: reference IDs and changed field names only. */
  details?: Record<string, unknown>;
};

export async function audit(entry: AuditEntry, tx?: Tx | DB) {
  await (tx ?? db()).insert(schema.auditLogs).values({
    actorId: entry.actorId ?? null,
    actorLabel: entry.actorLabel,
    action: entry.action,
    entityType: entry.entityType,
    entityId: entry.entityId ?? null,
    details: entry.details ?? {},
  });
}
