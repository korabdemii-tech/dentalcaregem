import "server-only";
import { lt } from "drizzle-orm";
import { db, schema } from "@/lib/db";

/** Delete expired dashboard sessions (no Next.js request APIs, safe for scripts). */
export async function pruneExpiredSessions() {
  await db().delete(schema.sessions).where(lt(schema.sessions.expiresAt, new Date()));
}
