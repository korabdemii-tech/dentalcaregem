import "server-only";
import { hash, verify } from "@node-rs/argon2";

// Argon2id with OWASP-recommended parameters (19 MiB, 2 iterations).
const OPTS = { memoryCost: 19456, timeCost: 2, parallelism: 1 } as const;

export function hashPassword(password: string) {
  return hash(password, OPTS);
}

export async function verifyPassword(hashed: string, password: string) {
  try {
    return await verify(hashed, password);
  } catch {
    return false;
  }
}

/** Minimum policy for staff passwords. Returns a translation key or null. */
export function passwordProblem(pw: string): string | null {
  if (pw.length < 12) return "admin.errors.passwordTooShort";
  if (pw.length > 200) return "admin.errors.passwordTooLong";
  if (!/[a-zA-Z]/.test(pw) || !/[^a-zA-Z]/.test(pw)) return "admin.errors.passwordWeak";
  return null;
}
