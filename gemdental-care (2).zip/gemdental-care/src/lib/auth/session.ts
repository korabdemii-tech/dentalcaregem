import "server-only";
import { cache } from "react";
import { cookies, headers } from "next/headers";
import { redirect, forbidden } from "next/navigation";
import { and, eq, gt } from "drizzle-orm";
import { db, schema } from "@/lib/db";
import { env } from "@/lib/env";
import { randomToken, sha256 } from "@/lib/security/token";
import { can, type Permission, type Role } from "./permissions";

export const SESSION_COOKIE = "gd_admin_session";
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
const RENEW_WHEN_LEFT_MS = 6 * 60 * 60 * 1000;

export type AdminUser = { id: string; email: string; name: string; role: Role; locale: string };

/**
 * Database-backed sessions: the browser holds a random 256-bit token in an
 * HttpOnly, SameSite=Lax cookie; the database stores only its SHA-256 hash,
 * so a database leak does not expose usable sessions.
 */
export async function createSession(userId: string) {
  const token = randomToken(32);
  const expiresAt = new Date(Date.now() + SESSION_TTL_MS);
  const ua = (await headers()).get("user-agent")?.slice(0, 200) ?? null;
  await db()
    .insert(schema.sessions)
    .values({ id: sha256(token), userId, expiresAt, userAgent: ua });
  (await cookies()).set(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: env.isProd,
    sameSite: "lax",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession() {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token)
    await db()
      .delete(schema.sessions)
      .where(eq(schema.sessions.id, sha256(token)));
  jar.delete(SESSION_COOKIE);
}

export async function destroyAllSessionsFor(userId: string) {
  await db().delete(schema.sessions).where(eq(schema.sessions.userId, userId));
}

/** Current admin user, or null. Validates the session against the database on every request. */
export const getCurrentAdmin = cache(async (): Promise<AdminUser | null> => {
  const token = (await cookies()).get(SESSION_COOKIE)?.value;
  if (!token || token.length > 100) return null;
  const id = sha256(token);
  const rows = await db()
    .select({ session: schema.sessions, user: schema.adminUsers })
    .from(schema.sessions)
    .innerJoin(schema.adminUsers, eq(schema.adminUsers.id, schema.sessions.userId))
    .where(and(eq(schema.sessions.id, id), gt(schema.sessions.expiresAt, new Date())));
  const row = rows[0];
  if (!row || !row.user.active) return null;
  // Sliding expiry (cookie is refreshed on the next state-changing action).
  if (row.session.expiresAt.getTime() - Date.now() < RENEW_WHEN_LEFT_MS) {
    await db()
      .update(schema.sessions)
      .set({ expiresAt: new Date(Date.now() + SESSION_TTL_MS) })
      .where(eq(schema.sessions.id, id));
  }
  const { id: uid, email, name, role, locale } = row.user;
  return { id: uid, email, name, role, locale };
});

/** Use at the top of every admin page and server action. */
export async function requireUser(permission?: Permission): Promise<AdminUser> {
  const user = await getCurrentAdmin();
  if (!user) redirect("/admin/login");
  if (permission && !can(user.role, permission)) forbidden();
  return user;
}
