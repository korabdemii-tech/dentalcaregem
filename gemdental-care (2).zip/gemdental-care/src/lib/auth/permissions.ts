export type Role = "owner" | "manager" | "staff";

/**
 * Role-based permissions. Enforced on the server in every page and action via
 * requireUser(permission); the UI only hides what the user cannot do.
 */
export const PERMISSIONS = {
  "appointments.view": ["owner", "manager", "staff"],
  "appointments.manage": ["owner", "manager", "staff"],
  "schedule.block": ["owner", "manager", "staff"],
  "patients.contact.view": ["owner", "manager", "staff"],
  "services.manage": ["owner", "manager"],
  "doctors.manage": ["owner", "manager"],
  "content.manage": ["owner", "manager"],
  "notifications.manage": ["owner", "manager"],
  "settings.manage": ["owner", "manager"],
  "users.manage": ["owner"],
  "audit.view": ["owner", "manager"],
  "patients.erase": ["owner"],
} as const satisfies Record<string, readonly Role[]>;

export type Permission = keyof typeof PERMISSIONS;

export function can(role: Role, permission: Permission): boolean {
  return (PERMISSIONS[permission] as readonly Role[]).includes(role);
}
